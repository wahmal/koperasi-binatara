

<!--MODAL-->
<div id="myModal" class="modal hide fade">
    <div class="modal-body">Data Berhasil Tersimpan !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="modalUpdate" class="modal hide fade">
    <div class="modal-body">Data Telah Berhasil di Update !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="terhapus" class="modal hide fade">
    <div class="modal-body">Data Telah Terhapus !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>


<?php include'setting.php'; ?>
<legend id="daftar">Pendaftaran Anggota</legend>
<form action="#" method="post" id="form_anggota" class="form-horizontal">
<div class="form-actions" style="padding-left:0px;padding-bottom:0px;margin-bottom: 0px;margin-left: 0px">
        <table border="0">
            <tr>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="name">Nama :</label>
                      <div class="controls">
                        <input type="hidden" name="id_anggota" id="id_anggota" >
                        <input type="text" name="nama" id="nama">
                      </div>
                    </div>
                </td>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="tgl">Tanggal Masuk :</label>
                      <div class="controls">
                        <div class="input-append date" id="datepicker" data-date="<?php echo date("Y-m-d");?>" data-date-format="yyyy-mm-dd">
                            <span class="add-on"><i class="icon-th"></i></span>
                            <input class="span2" size="16" type="text" id="tgl" name="tgl" placeholder="yyyy-mm-dd" readonly="true">
                        </div>
                      </div>
                    </div>
               </td>
            </tr>
            <tr>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="alamat">Alamat :</label>
                      <div class="controls">
                        <textarea name="alamat" id="alamat"></textarea>
                      </div>
                  </div>  
                </td>
                <td>
                   <div class="control-group">
                      <label class="control-label" for="jk">Jenis Kelamin :</label>
                      <div class="controls">
                        <label class="radio" id="A">
                        <input type="radio" id="jk" class="A" name="jk" value="L" checked> Laki - Laki
                      </label>
                      <label class="radio" id="B">
                        <input type="radio" id="jk"  name="jk" value="P"> Perempuan
                      </label>
                      </div>
                   </div> 
                </td>
            </tr>
            <tr>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="telepon">No. Telepon :</label>
                      <div class="controls">
                        <input type="text" name="telepon" id="telepon">
                      </div>
                  </div>  
                </td>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="pokok">Simpanan Pokok :</label>
                      <div class="controls">
                        <input type="text" name="pokok" id="pokok" readonly="true" value="<?php echo $setting_simpanan_pokok;?>">
                      </div>
                  </div> 
                </td>
            </tr>
        </table>   
    </div>
    <div style="background:#FFF;margin-left: 0px;padding-top: 5px;">
<button type="submit" class="btn btn-success" id="tombol" data-loading-text="Loading...">Save</button>
<button type="reset" class="btn">Reset</button>
    </div>
</form>
<script src="<?php echo site_path ?>bootstrap/datepicker/tanggal.js"></script>    

<!--DATA TABLES-->
<legend>Daftar Anggota</legend>
<style type="text/css" title="currentStyle">
    @import "<?php echo site_path ?>data_tables/media/css/demo_page.css";
    @import "<?php echo site_path ?>data_tables/media/css/demo_table.css";
</style>
<script type="text/javascript" language="javascript" src="<?php echo site_path ?>data_tables/media/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path ?>data_tables/media/js/jquery.dataTables.min.js"></script>
<script src="<?php echo site_path ?>bootstrap/js/validate/jquery.validate.min.js"></script>
<script type="text/javascript">
var $j = jQuery.noConflict();
$j(document).ready(function() {
            var oTable = $j('#example').dataTable( {
                    
                    "bProcessing": true,
                    "bServerSide": true,
                    "bAutoWidth": false,
                    "bDestory": true,
                    "sScrollX": "100%",
                    "sScrollXInner": "120%",
                    "bScrollCollapse": true,
                    "sAjaxSource": "<?php echo site_path ?>anggota/anggota_json.php",
                    "sPaginationType": "full_numbers",
                    "aoColumns": [ 
                        {"sClass": "center"},
                        {"sClass": "left"},
                        {"sClass": "center"},
                        {"sClass": "center"},
                        {"sClass": "left"},
                        {"sClass": "center"},
                        {"sClass": "right"},
                        {"sClass": "center"}
                    ],
                    "aoColumnDefs": [
                     { "bVisible": true, "aTargets": [2] }
                    ]
} );
            
$j('.delbutton').live("click", function() {
        var id = $j(this).attr("id");
        var parent = $j(this).parent();
        if(confirm("Yakin Menghapus Anggota Ini ? Seluruh Data mengenai anggota ini akan ikut terhapus"))
        {
        $j.ajax({
           type: "POST",
           url: "<?php echo site_path ?>anggota/delete_anggota.php",
           data:'id='+ id,
           cache: false,

         success: function()
           {
            oTable.fnDraw();
            $("#terhapus").bind("show", function() {
            $("#terhapus a.btn").click(function(e) {
                console.log("button pressed: "+$(this).html());
                $("#terhapus").modal('hide');
            });
            });
            $("#terhapus").bind("hide", function() {
            $("#terhapus a.btn").unbind();
            });
            $("#terhapus").modal({
            "backdrop"  : "static",
            "keyboard"  : true,
            "show"      : true    
            });
                    
          }
          
          });
          }
	  return false;
});

$j('.editbutton').live("click", function() {
        var id = $j(this).attr("id");
		$j.getJSON ('<?php echo site_path ?>anggota/edit_anggota.php',{id:id}, function (json) {
                $j("#id_anggota").val(json.id_anggota);
                $j("#nama").val(json.nama);
                $j("#tgl").val(json.tgl_daftar);
                $j("#alamat").val(json.alamat);
                $j("#telepon").val(json.no_telp);
                if(json.jk=='P'){
                   $j("#B").html("<input type='radio' id='jk' name='jk' value='P' checked> Perempuan");
               }else{
                   $j("#A").html("<input type='radio' id='jk' name='jk' value='L' checked> Laki - Laki");
               }               
		}); 

        $j("#daftar").html("Edit Anggota");
        $j("#tombol").html("Update");
        return false;
});

$j('#form_anggota').validate({
	    rules: {
	      nama: {
	        minlength: 3,
	        required: true
	      },
	      tgl: {
	        required: true
	      },
	      alamat: {
	      	minlength: 5,
	        required: true
	      },
	      pokok: {
                number:true,
	        required: true
	      },
	      telepon: {
                maxlength:12,
                number:true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
                var InputNama = $j("#nama");
                InputJk = $j("input[name=jk]:checked");
                InputTgl = $j("#tgl");
                InputAlamat = $j("#alamat");
                InputTelepon = $j("#telepon");
                Id=$j("#id_anggota");
                Pokok=$j("#pokok");
                
                var nama = InputNama.attr("value");
                jk  = InputJk.attr("value");
                tgl  = InputTgl.attr("value");
                alamat  = InputAlamat.attr("value");
                telepon  = InputTelepon.attr("value");
                id=Id.attr("value");
                pokok=Pokok.attr("value");
                
                if(id==""){
                    $j.ajax({
                        type: "GET", 
                        url: "<?php echo site_path ?>anggota/simpan_anggota.php", 
                        data: "nama=" + nama + "&jk=" + jk + "&tgl=" + tgl + "&alamat=" + alamat + "&telepon=" + telepon +"&pokok="+pokok,
                        complete: function(data){
                            $j("#id_anggota").val('');
                            $j("#nama").val('');
                            $j("#tgl").val('');
                            $j("#alamat").val('');
                            $j("#telepon").val('');
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                            oTable.fnDraw();
                        }
                    });
                    return false;
                }else{
                    $j.ajax({
                        type: "GET", 
                        url: "<?php echo site_path ?>anggota/update_anggota.php", 
                        data: "nama=" + nama + "&jk=" + jk + "&tgl=" + tgl + "&alamat=" + alamat + "&telepon=" + telepon +"&pokok="+pokok+ "&id=" + id,
                        complete: function(data){
                            $j("#daftar").html("Pendaftaran Anggota");
                            $j("#tombol").html("Save");
                            $j("#id_anggota").val('');
                            $j("#nama").val('');
                            $j("#tgl").val('');
                            $j("#alamat").val('');
                            $j("#telepon").val('');
                            $("#modalUpdate").bind("show", function() {
                            $("#modalUpdate a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#modalUpdate").modal('hide');
                            });
                            });
                            $("#modalUpdate").bind("hide", function() {
                            $("#modalUpdate a.btn").unbind();
                            });
                            $("#modalUpdate").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true   
                            });
                            oTable.fnDraw();
                        }
                    });
                    return false;
                }
    }  
});
    
});
</script>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
			<th>Id</th>
			<th>Nama</th>
			<th>Jenis Kelamin</th>
			<th>Tanggal Masuk</th>
                        <th>Alamat</th>
			<th>No. Telepon</th>
                        <th>Simpanan Pokok</th>
                        <th>Pilihan</th>
		</tr>
	</thead>

</table>