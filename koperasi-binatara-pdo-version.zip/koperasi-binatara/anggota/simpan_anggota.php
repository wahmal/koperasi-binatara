
<?php 
include '../atribut/basic.php';
include '../atribut/kd_transaksi_anggota.php';

$nama=$_GET['nama'];
$tgl=$_GET['tgl'];
$alamat=$_GET['alamat'];
$jk=$_GET['jk'];
$telepone=$_GET['telepon'];
$pokok=$_GET['pokok'];

$snggota=$query->create('anggota',array(null,$nama,$jk,$tgl,$alamat,$telepone,$pokok,$kd_transaksi));
$query->create('jurnal_umum',array(null,$tgl,'Kas',$pokok,null,$kd_transaksi,'','','',''));
$query->create('jurnal_umum',array(null,$tgl,'Simpanan Pokok',null,$pokok,$kd_transaksi,'','','',''));
?>
