<?php
include '../atribut/basic.php';
$nama=$_GET['nama'];
$tgl=$_GET['tgl'];
$alamat=$_GET['alamat'];
$jk=$_GET['jk'];
$telepone=$_GET['telepon'];
$id=$_GET['id'];
$pokok=$_GET['pokok'];

$row=$query->read("anggota","where id_anggota='".$id."'","","obj");
$kd_transaksi=$row[0]->kd_transaksi;

$update=$query->update('anggota',"id_anggota='".$id."'",array('nama',$nama,'tgl_daftar',$tgl,'alamat',$alamat,'jk',$jk,'no_telp',$telepone,'simpanan_pokok',$pokok));
$update_jurnal=$query->update("jurnal_umum","kd_transaksi='".$kd_transaksi."'", array('set tgl',$tgl));

?>
