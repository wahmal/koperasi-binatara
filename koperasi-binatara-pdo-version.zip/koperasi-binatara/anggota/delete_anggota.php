<?php
$id=$_POST['id'];
include '../atribut/basic.php';


//jangka panjang
$jangka_panjang=$query->read('p_jangka_panjang',"where id_anggota='".$id."'","kd_panjang","obj");
$kd_panjang=$jangka_panjang[0]->kd_panjang;


$delete_jurnal1=$query->delete("jurnal_umum","kd_panjang",array($kd_panjang));
$delete_angsuran1=$query->delete("angsuran_jangka_panjang","kd_panjang",array($kd_panjang));
$delete_angsuran1=$query->delete("p_jangka_panjang","kd_panjang",array($kd_panjang));

//jangka pendek
$jangka_pendek=$query->read('p_jangka_pendek',"where id_anggota='".$id."'","kd_pendek","obj");
$kd_pendek=$jangka_pendek[0]->kd_pendek;

$delete_jurnal2=$query->delete("jurnal_umum","kd_pendek",array($kd_pendek));
$delete_angsuran2=$query->delete("angsuran_jangka_pendek","kd_pendek",array($kd_pendek));
$delete_pinjaman2=$query->delete("p_jangka_pendek","kd_pendek",array($kd_pendek));

//elektronik
$elektronik=$query->read('p_elektronik',"where id_anggota='".$id."'","kd_elektronik","obj");
$kd_elektronik=$elektronik[0]->kd_elektronik;

$delete_jurnal3=$query->delete("jurnal_umum","kd_elektronik",array($kd_elektronik));
$delete_angsuran3=$query->delete("angsuran_elektronik","kd_elektronik",array($kd_elektronik));
$delete_pinjaman3=$query->delete("p_elektronik","kd_elektronik",array($kd_elektronik));

//sebrak
$sebrak=$query->read('p_sebrak',"where id_anggota='".$id."'","kd_sebrak","obj");
$kd_sebrak=$sebrak[0]->kd_sebrak;

$delete_jurnal4=$query->delete("jurnal_umum","kd_sebrak",array($kd_sebrak));
$delete_angsuran4=$query->delete("angsuran_sebrak","kd_sebrak",array($kd_sebrak));
$delete_pinjaman4=$query->delete("p_sebrak","kd_sebrak",array($kd_sebrak));

//simpanan wajib
$delete_wajib=$query->delete("simpanan_wajib","id_anggota",array($id));

//simpanan sukarela
$delete_sukarela=$query->delete("simpanan_sukarela","id_anggota",array($id));

//anggota
$anggota=$query->read("anggota","where id_anggota='".$id."'","kd_transaksi","obj");
$kd_transaksi=$anggota[0]->kd_transaksi;

//jurnal
$delete_jurnal=$query->delete("jurnal_umum","kd_transaksi",array($kd_transaksi));
$delete=$query->delete("anggota","id_anggota",array($id));

?>