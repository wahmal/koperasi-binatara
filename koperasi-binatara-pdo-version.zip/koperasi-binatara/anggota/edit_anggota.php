<?php
include '../atribut/basic.php';
	$row =$query->read("anggota","WHERE md5(id_anggota)='".$_GET['id']."'","","array");
	echo json_encode ($row[0]);
	exit;
?>
