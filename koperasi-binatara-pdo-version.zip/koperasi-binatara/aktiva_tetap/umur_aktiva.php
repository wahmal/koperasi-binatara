<select name="jenis" class="span2" id="jenis" >
    <option value="" align="center">-PILIH-</option>
    <?php
    include'../atribut/connect.php';
    
    $jenis=$_GET['jenis'];
    $query=  mysql_query("select * from jenis_aktiva order by kd_jenis")or die (mysql_error());
                            while($result= mysql_fetch_object($query)){
                                if($result->kd_jenis==$query){
                                    echo "<option value='".$result->kd_jenis."' selected>".$result->jenis."</option>";
                                }else{
                                    echo "<option value='".$result->kd_jenis."'>".$result->jenis."</option>";
                                }
                            }
    ?>
</select>