<?php
include '../atribut/connect.php';
$jenis=$_GET['jenis_aktiva'];
$insert=mysql_query("insert into jenis_aktiva values('null','".$jenis."') ")or die (mysql_error());
echo $jenis;
?>
