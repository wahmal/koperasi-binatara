
<!--MODAL-->
<div id="myModal" class="modal hide fade">
    <div class="modal-body">Data Berhasil Tersimpan !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="modalUpdate" class="modal hide fade">
    <div class="modal-body">Data Telah Berhasil di Update !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="terhapus" class="modal hide fade">
    <div class="modal-body">Data Telah Terhapus !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>

<legend id="form">Form Aktiva Tetap</legend>
<form action="#" method="post" id="form_aktiva" class="form-horizontal">
<div class="form-actions" style="padding-left:0px;padding-bottom:0px;margin-bottom: 0px;margin-left: 0px">
        <table border="0">
            <tr>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="nm_aktiva">Nama Aktiva:</label>
                      <div class="controls">
                        <input type="hidden" name="kd_aktiva" id="kd_aktiva" >
                        <input type="text" name="nm_aktiva" id="nm_aktiva">
                      </div>
                    </div>
                </td>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="tgl">Tanggal Pembelian :</label>
                      <div class="controls">
                        <div class="input-append date" id="datepicker" data-date="<?php echo date("Y-m-d");?>" data-date-format="yyyy-mm-dd">
                            <span class="add-on"><i class="icon-th"></i></span>
                            <input class="span2" size="16" type="text" id="tgl" name="tgl" placeholder="yyyy-mm-dd" readonly="true">
                        </div>
                      </div>
                    </div>
               </td>
            </tr>
            <tr>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="harga">Harga Perolehan:</label>
                      <div class="controls">
                        <input type="text" name="harga" id="harga">
                      </div>
                  </div>
                </td>
                <td>
                   <div class="control-group">
                      <label class="control-label" for="name">Jenis Aktiva :</label>
                      <div class="controls" id="umur_aktiva">
                        <select name="jenis" class="span2" id="jenis" >
                            <option value="" align="center">-PILIH-</option>
                            <?php
                            $jenis_aktiva=$query->read("jenis_aktiva","order by kd_jenis","","obj");
                            foreach($jenis_aktiva as $result){
                                echo "<option value='".$result->kd_jenis."'>".$result->jenis."</option>";
                            }
                            ?>
                        </select>
                      </div>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="residu">Nilai Residu :</label>
                      <div class="controls">
                        <input type="text" name="residu" id="residu">
                      </div>
                  </div>  
                </td>
                <td>
                   <div class="control-group">
                      <label class="control-label" for="umur">Umur Ekonomis :</label>
                      <div class="controls">
                        <input type="text" class="span1" name="umur" id="umur" placeholder="Tahun">
                      </div>
                  </div>  
                </td>
            </tr>
        </table>   
    </div>
    <div style="background:#FFF;margin-left: 0px;padding-top: 5px;">
<button type="submit" class="btn btn-success" id="tombol">Save</button>
<button type="reset" class="btn">Reset</button>
    </div>
</form>
<script src="<?php echo site_path; ?>bootstrap/datepicker/tanggal.js"></script>


<!--DATA TABLES-->
<legend>Daftar Aktiva Tetap</legend>
<style type="text/css" title="currentStyle">
    @import "<?php echo site_path; ?>data_tables/media/css/demo_page.css";
    @import "<?php echo site_path; ?>data_tables/media/css/demo_table.css";
</style>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/media/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/media/js/jquery.dataTables.min.js"></script>
<script src="<?php echo site_path; ?>bootstrap/js/validate/jquery.validate.min.js"></script>
<script type="text/javascript" charset="utf-8">
var $j = jQuery.noConflict();
$j(document).ready(function() {
        var oTable = $j('#example').dataTable( {

                "bProcessing": true,
                "bServerSide": true,
                "bAutoWidth": false,
                "bDestory": true,
                "bRetrieve": true,
                "sScrollX": "100%",
                "sScrollXInner": "120%",
                "bScrollCollapse": true,
                "sAjaxSource": "<?php echo site_path; ?>aktiva_tetap/aktiva_tetap_json.php",
                "sPaginationType": "full_numbers",
                "aoColumns": [ 
                    {"sClass": "center"},
                     {"sClass": "center"},
                    {"sClass": "left"},
                    {"sClass": "center"},
                    {"sClass": "left"},
                    {"sClass": "right"},
                    {"sClass": "center"},
                    {"sClass": "right"},
                    {"sClass": "center"},
                ],
                "aoColumnDefs": [
        { "bVisible": false, "aTargets": [1] }
    ]
 } );
   
 
 $j('#form_aktiva').validate({
	    rules: {
	      nm_aktiva: {
	        minlength: 3,
	        required: true
	      },
	      tgl: {
	        required: true
	      },
	      harga: {
	      	number: true,
	        required: true
	      },
	      jenis: {
	        required: true
	      },
	      residu: {
                number:true,
	        required: true
	      },
	      umur: {
                number:true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
                nm_aktiva  = $j("#nm_aktiva").attr("value");
                tgl  = $j("#tgl").attr("value");
                harga  = $j("#harga").attr("value");
                jenis  = $j("#jenis").attr("value");
                residu  = $j("#residu").attr("value");
                kd_aktiva  = $j("#kd_aktiva").attr("value");
                umur  = $j("#umur").attr("value");
                
                if(kd_aktiva==""){
                    $j.ajax({
                        type: "GET", 
                        url: "<?php echo site_path; ?>aktiva_tetap/simpan_aktiva.php", 
                        data: "nm_aktiva=" + nm_aktiva + "&tgl=" + tgl + "&harga=" + harga + "&jenis=" + jenis + "&residu=" + residu +"&umur="+umur,
                        complete: function(data){
                            $j("#kd_aktiva").val('');
                            $j("#nm_aktiva").val('');
                            $j("#tgl").val('');
                            $j("#harga").val('');
                            $j("#jenis").val('');
                            $j("#residu").val('');
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                            oTable.fnDraw();
                        }
                    });
                    return false;
                }else{
                    $j.ajax({
                        type: "GET", 
                        url: "<?php echo site_path; ?>aktiva_tetap/update_aktiva_tetap.php", 
                        data: "kd_aktiva="+kd_aktiva+"&nm_aktiva=" + nm_aktiva + "&tgl=" + tgl + "&harga=" + harga + "&jenis=" + jenis + "&residu=" + residu +"&umur="+umur,
                        complete: function(data){
                            
                            //konfirmasi
                            $("#modalUpdate").bind("show", function() {
                            $("#modalUpdate a.btn").click(function(e) {
                                $j("#kd_aktiva").val('');
                                $j("#nm_aktiva").val('');
                                $j("#tgl").val('');
                                $j("#harga").val('');
                                $j("#jenis").val('');
                                $j("#residu").val('');
                                $j("#umur").val('');
                                $j("#form").html("Form Aktiva Tetap");
                                $j("#tombol").html("Save");
                                console.log("button pressed: "+$(this).html());
                                $("#modalUpdate").modal('hide');
                            });
                            });
                            $("#modalUpdate").bind("hide", function() {
                            $("#modalUpdate a.btn").unbind();
                            });
                            $("#modalUpdate").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true   
                            });
                            oTable.fnDraw();
                        }
                    });
                    return false;
                }
        }  
});
 
$j('.delbutton').live("click", function(e) {
    e.preventDefault();
        var kd_aktiva = $j(this).attr("kd_aktiva");
        var dataString = 'kd_aktiva='+ kd_aktiva ;
        var parent = $j(this).parent();
        if(confirm("Yakin Menghapus Aktiva Ini ? Seluruh Data mengenai aktiva ini akan ikut terhapus"))
        {
        $j.ajax({
           type: "POST",
           url: "<?php echo site_path; ?>aktiva_tetap/delete.php",
           data: dataString,
           cache: false,
           success: function()
           {
                    $("#terhapus").bind("show", function() {
                    $("#terhapus a.btn").click(function(e) {
                        console.log("button pressed: "+$(this).html());
                        $("#terhapus").modal('hide');
                    });
                    });
                    $("#terhapus").bind("hide", function() {
                    $("#terhapus a.btn").unbind();
                    });
                    $("#terhapus").modal({
                    "backdrop"  : "static",
                    "keyboard"  : true,
                    "show"      : true    
                    });
                    oTable.fnDraw();
                    
          }
          
          });
          }
	  return false;
});

$j('.editbutton').live("click", function(e) {
        e.preventDefault();
        var kd_aktiva = $j(this).attr("kd_aktiva");
        var jenis= $j(this).attr("jenis");
        var nm_aktiva = $j(this).attr("nm_aktiva");
        var tgl= $j(this).attr("tgl");
        var harga= $j(this).attr("harga");
        var umur= $j(this).attr("umur");
        var residu= $j(this).attr("residu");
        
        var dataString = 'jenis='+ jenis;
        
        $j.ajax
        ({
        type: "GET",
        url: "<?php echo site_path; ?>aktiva_tetap/jenis_aktiva.php",
        data: dataString,
        cache: false,
        success: function(html)
        {
        $j("#umur_aktiva").html(html);
        } 
        });
        
        $j("#form").html("Edit Aktiva Tetap");
        $j("#tombol").html("Update");
        $j("#kd_aktiva").val(kd_aktiva);
        $j("#tgl").val(tgl);
        $j("#nm_aktiva").val(nm_aktiva);
        $j("#harga").val(harga);
        $j("#umur").val(umur);
        $j("#residu").val(residu);
        return false;
});


});
        
		
</script>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
			<th>Kd Aktiva</th>
                        <th>Kd Jenis</th>
			<th>Jenis</th>
                        <th>Tanggal Perolehen</th>
                        <th>Nama Aktiva</th>
			
			<th>Harga</th>
                        <th>Umur Ekonomis</th>
			<th>Residu</th>
                        <th>Pilihan</th>
		</tr>
	</thead>

</table>