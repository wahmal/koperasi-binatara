var $s = jQuery.noConflict();           
$s(document).ready(function(){
    $s('#input').live("click", function() {
        $("#myModal").bind("show", function() {
        $("#myModal a.close").click(function(e) {
            console.log("button pressed: "+$(this).html());
            $("#myModal").modal('hide');
        });
        });
        $("#myModal").bind("hide", function() {
        $("#myModal a.close").unbind();
        });
        $("#myModal").modal({
        "backdrop"  : "static",
        "keyboard"  : true,
        "show"      : true  
        });
        });
        
    $s('#form_jenis').validate({
	    rules: {
	      jenis_aktiva: {
	        minlength: 3,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
                jenis_aktiva  = $s("#jenis_aktiva").attr("value");        
                    $s.ajax({
                        type: "GET", 
                        url: "aktiva_tetap/simpan_jenis_aktiva.php", 
                        data: "jenis_aktiva=" + jenis_aktiva,
                        complete: function(data){
                            $("#myModal").modal('hide');
                            $s("#jenis_aktiva").val('');
                            $s('#data').load('aktiva_tetap/data_aktiva_tetap.php');
                            $("#simpan").bind("show", function() {
                            $("#simpan a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#simpan").modal('hide');
                            });
                            });
                            $("#simpan").bind("hide", function() {
                            $("#simpan a.btn").unbind();
                            });
                            $("#simpan").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                        }
                    });
                    return false;
                
            }
            });
            
$s('.editbutton').live("click", function() {
        var kd_jenis = $s(this).attr("kd_jenis");
        var jenis= $s(this).attr("jenis");
        
        $s("#kd_jenis").val(kd_jenis);
        $s("#jenis_aktiva_edit").val(jenis);
        $("#myModal_edit").bind("show", function() {
        $("#myModal_edit a.close").click(function(e) {
            console.log("button pressed: "+$(this).html());
            $("#myModal_edit").modal('hide');
        });
        });
        $("#myModal_edit").bind("hide", function() {
        $("#myModal_edit a.close").unbind();
        });
        $("#myModal_edit").modal({
        "backdrop"  : "static",
        "keyboard"  : true,
        "show"      : true  
        });
        return false;
});

$s('#form_jenis_edit').validate({
	    rules: {
	      jenis_aktiva_edit: {
	        minlength: 3,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
                kd_jenis  = $s("#kd_jenis").attr("value");
                jenis_aktiva  = $s("#jenis_aktiva_edit").attr("value");        
                    $s.ajax({
                        type: "GET", 
                        url: "aktiva_tetap/update_jenis_aktiva.php", 
                        data: "jenis_aktiva=" + jenis_aktiva+"&kd_jenis=" + kd_jenis,
                        complete: function(data){
                            $("#myModal_edit").modal('hide');
                            $s("#kd_jenis").val('');
                            $s("#jenis_aktiva_edit").val('');
                            $s('#data').load('aktiva_tetap/data_jenis_aktiva_tetap.php');
                            $("#update").bind("show", function() {
                            $("#update a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#update").modal('hide');
                            });
                            });
                            $("#update").bind("hide", function() {
                            $("#update a.btn").unbind();
                            });
                            $("#update").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                        }
                    });
                    return false;
                
            }
            });

$s('.delbutton').live("click", function() {
        var kd_jenis = $s(this).attr("kd_jenis");
        var dataString = 'kd_jenis='+ kd_jenis ;
        var parent = $s(this).parent();
        if(confirm("Yakin Menghapus Jenis Aktiva Ini ? Seluruh Data mengenai Jenis aktiva ini akan ikut terhapus"))
        {
        $s.ajax({
           type: "POST",
           url: "aktiva_tetap/delete_jenis.php",
           data: dataString,
           cache: false,

           success: function()
           {
               parent.slideUp('slow', function() {$s(this).remove();});
                    $s('#data').load('aktiva_tetap/data_jenis_aktiva_tetap.php');
                    $("#delete").bind("show", function() {
                    $("#delete a.btn").focus();
                    $("#delete a.btn").click(function(e) {
                        console.log("button pressed: "+$(this).html());
                        $("#delete").modal('hide');
                    });
                    });
                    $("#delete").bind("hide", function() {
                    $("#delete a.btn").unbind();
                    });
                    $("#delete").modal({
                    "backdrop"  : "static",
                    "keyboard"  : true,
                    "show"      : true    
                    });
                    
          }
          
          });
          }
	  return false;
});

});