<?php
include '../atribut/connect.php';
$kd_jenis=$_POST['kd_jenis'];


$result=  mysql_query("select a.kd_transaksi as kd_transaksi, a.kd_aktiva as kd_aktiva from aktiva_tetap a join jenis_aktiva b on a.kd_jenis=b.kd_jenis where b.kd_jenis='".$kd_jenis."'")or die(mysql_error());
$cek=  mysql_num_rows($result);
while ($row=  mysql_fetch_object($result)){
    $kd_transaksi=$row->kd_transaksi;
    $kd_aktiva=$row->kd_aktiva;
    $delete1=mysql_query("delete from aktiva_tetap where kd_aktiva='".$kd_aktiva."'")or die(mysql_error());
    $delete2=mysql_query("delete from jurnal_umum where kd_transaksi='".$kd_transaksi."'")or die(mysql_error());
    
}
$delete3=mysql_query("delete from jenis_aktiva where kd_jenis='".$kd_jenis."'")or die(mysql_error());

?>
