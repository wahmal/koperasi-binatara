<?php
include '../atribut/basic.php';
$kd_aktiva=$_POST['kd_aktiva'];



$res=$query->read("aktiva_tetap","where kd_aktiva='".$kd_aktiva."'","","obj");

$kd_transaksi=$res[0]->kd_transaksi;

$query->delete('jurnal_umum','kd_transaksi',array($kd_transaksi));

$query->delete('aktiva_tetap','kd_aktiva',array($kd_aktiva));

?>
