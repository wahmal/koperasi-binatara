<!--modal-->
<div id="simpan" class="modal hide fade">
    <div class="modal-header"><strong>Data Berhasil Tersimpan !!</strong></div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="update" class="modal hide fade">
    <div class="modal-header"><strong>Data Berhasil di Update !!</strong></div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="delete" class="modal hide fade">
    <div class="modal-header"><strong>Data Telah Terhapus !!</strong></div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>

<!--tambah data-->
<button class="btn btn-success" id="input"><i class="icon-plus icon-white"></i> Tambah Jenis</button>
<form action="#" method="post" id="form_jenis" class="form-horizontal">
<div id="myModal" class="modal hide fade">
    <div class="modal-header">
        <strong>Tambah Jenis Aktiva</strong> 
        <a href="#" class="close"><i class="icon-remove"></i></a>
    </div>
    <div class="modal-body">   
        <div class="control-group">
          <label class="control-label" for="jenis_aktiva">Jenis Aktiva :</label>
          <div class="controls">
            <input type="text" name="jenis_aktiva" id="jenis_aktiva">
          </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-success" id="tombol">Save</button>
        <button type="reset" class="btn">Reset</button>
    </div>
</div>
</form>

<!--update data-->
<form action="#" method="post" id="form_jenis_edit" class="form-horizontal">
<div id="myModal_edit" class="modal hide fade">
    <div class="modal-header">
        <strong>Edit Jenis Aktiva</strong> 
        <a href="#" class="close"><i class="icon-remove"></i></a>
    </div>
    <div class="modal-body">   
        <div class="control-group">
          <label class="control-label" for="jenis_aktiva_edit">Jenis Aktiva :</label>
          <div class="controls">
            <input type="hidden" name="kd_jenis" id="kd_jenis">
            <input type="text" name="jenis_aktiva_edit" id="jenis_aktiva_edit">
          </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-success" id="tombol">Update</button>
        <button type="reset" class="btn">Reset</button>
    </div>
</div>
</form>

<script src="bootstrap/js/validate/jquery-1.7.1.min.js"></script>
<script src="bootstrap/js/validate/jquery.validate.min.js"></script>
<script src="aktiva_tetap/jenis_validate.js"></script>

<div id="data">
<?php include 'aktiva_tetap/data_jenis_aktiva_tetap.php';?>
</div>
