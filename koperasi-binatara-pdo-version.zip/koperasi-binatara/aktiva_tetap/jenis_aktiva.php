<select name="jenis" class="span2" id="jenis" >
                            <option value="" align="center">-PILIH-</option>
<?php
include '../atribut/basic.php';
$jenis=$_GET['jenis'];
$res=$query->read("jenis_aktiva","order by kd_jenis","","obj");

foreach ($res as $result) {
    if($jenis==$result->kd_jenis){
    echo "<option value='".$result->kd_jenis."' selected>".$result->jenis."</option>";
}else{
    echo "<option value='".$result->kd_jenis."'>".$result->jenis."</option>";
}
}
?>
</select>