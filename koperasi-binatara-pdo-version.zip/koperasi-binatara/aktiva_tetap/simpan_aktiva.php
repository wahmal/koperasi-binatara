
<?php 
include '../atribut/basic.php';
include '../atribut/kd_transaksi_aktiva_tetap.php';

$nm_aktiva=$_GET['nm_aktiva'];
$tgl=$_GET['tgl'];
$harga=$_GET['harga'];
$jenis=$_GET['jenis'];
$residu=$_GET['residu'];
$umur=$_GET['umur'];


if($query->create("aktiva_tetap",array(null,$jenis,$nm_aktiva,$tgl,$harga,$umur,$residu,$kd_transaksi))){
	$query->create("jurnal_umum",array(null,$tgl,'Aktiva_tetap',$harga,null,$kd_transaksi,'','','',''));
	$query->create("jurnal_umum",array(null,$tgl,'Kas',null,$harga,$kd_transaksi,'','','',''));
}

?>
