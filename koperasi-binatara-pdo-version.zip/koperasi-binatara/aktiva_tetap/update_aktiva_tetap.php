<?php
include '../atribut/basic.php';
$kd_aktiva=$_GET['kd_aktiva'];
$kd_jenis=$_GET['jenis'];
$harga=$_GET['harga'];
$nm_aktiva=$_GET['nm_aktiva'];
$residu=$_GET['residu'];
$tgl=$_GET['tgl'];
$umur=$_GET['umur'];


$res=$query->read("aktiva_tetap","where kd_aktiva='".$kd_aktiva."'",'kd_transaksi');
    $kd_transaksi=$res[0]['kd_transaksi'];



$data=$query->read("jurnal_umum ","where kd_transaksi='".$kd_transaksi."' order by id_jurnal asc","id_jurnal",'obj');



$query->update('aktiva_tetap',"kd_aktiva='".$kd_aktiva."'",array('kd_jenis',$kd_jenis,'nm_aktiva',$nm_aktiva,'tgl_perolehan',$tgl,'hrg_perolehan',$harga,'umur_ekonomis',$umur,'residu',$residu));


foreach($data as $row){
    $id_jurnal[]=$row->id_jurnal;
}


//update jurnal
$query->update('jurnal_umum',"id_jurnal='".$id_jurnal[0]."'",array('tgl',$tgl,'debit',$harga));
$query->update('jurnal_umum',"id_jurnal='".$id_jurnal[1]."'",array('tgl',$tgl,'kredit',$harga));





?>
