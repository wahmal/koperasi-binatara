<?php
include'../atribut/connect.php';
$kd_jenis=$_GET['kd_jenis'];
$jenis=$_GET['jenis_aktiva'];


$query=mysql_query("update jenis_aktiva set jenis='".$jenis."' where kd_jenis='$kd_jenis'")or die (mysql_error());
?>
