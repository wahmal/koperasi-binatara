<!--DATA TABLES-->
<legend>Daftar Jenis Aktiva</legend>
<style type="text/css" title="currentStyle">
    @import "data_tables/media/css/demo_page.css";
    @import "data_tables/media/css/demo_table.css";
</style>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.jeditable.js"></script>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.dataTables.editable.js"></script>
<script type="text/javascript" charset="utf-8">
    var $j = jQuery.noConflict();
    $j(document).ready(function() {
            var oTable = $j('#example').dataTable( {
                    
                    "bProcessing": true,
                    "bServerSide": true,
                    "bAutoWidth": false,
                    "bDestory": true,
                    "bRetrieve": true,
                    "sAjaxSource": "aktiva_tetap/jenis_aktiva_json.php",
                    "sPaginationType": "full_numbers",
                    "aoColumns": [ 
                        {"sClass": "center"},
                        {"sClass": "left"},
                        {"sClass": "center"}
                    ],
                    "aoColumnDefs": [
            { "bVisible": false, "aTargets": [0] }
        ]
            } );
            } );
</script>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
			<th>Kd Jenis</th>
                        <th>Jenis Aktiva</th>
                        <th>Pilihan</th>
		</tr>
	</thead>

</table>