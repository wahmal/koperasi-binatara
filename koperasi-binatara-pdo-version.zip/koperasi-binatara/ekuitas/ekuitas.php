<script src="bootstrap/js/validate/jquery-1.7.1.min.js"></script>
<script src="bootstrap/js/validate/jquery.validate.min.js"></script>
<script src="bootstrap/js/validate/jquery.validate.js"></script>
<div id="data">
<?php
include'setting.php';
?>

<legend id="daftar">Ekuitas</legend>

<!--TAB SETTING-->
<div class="tabbable"> 
  <ul class="nav nav-tabs">
    <li class="active"><a href="#tab1" data-toggle="tab">Modal Penyertaan</a></li>
    <li><a href="#tab2" data-toggle="tab">Modal Sumbangan</a></li>
    <li><a href="#tab3" data-toggle="tab">Modal Cadangan</a></li>
    <li><a href="#tab4" data-toggle="tab">SHU Belum Dibagi</a></li>
  </ul>
  <div class="tab-content">
<?php include'setting/setting_simpanan.php'; ?>
<?php include'setting/setting_pinjaman.php'; ?>
<?php include'setting/setting_pajak.php'; ?>        
<?php include'setting/setting_saldo.php'; ?>

  </div>
</div>



</div>
<!--MODAL-->
<div id="myModal" class="modal hide fade">
    <div class="modal-body">Pengaturan Telah di perbarui !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<!--VALIDATE FORM-->

