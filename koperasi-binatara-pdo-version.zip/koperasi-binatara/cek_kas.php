<?php
require_once "setting.php";
$array1=array();
$array2=array();
$i=$saldo_awal;

$main_query= $query->read("jurnal_umum","order by tgl","distinct(kd_transaksi) as kd_transaksi","obj");

foreach($main_query as $row)
{
    $x=0;
    //cari saldo
    //echo $row->kd_transaksi;
    $result1= $query->read("jurnal_umum","where kd_transaksi='".$row->kd_transaksi."'","sum(debit) as saldo","obj");
    //print_r($result1);
        $saldo=$result1[0]->saldo;

    //looping jurnal
    $result2= $query->read("jurnal_umum","where kd_transaksi='".$row->kd_transaksi."' and ket not like '%Kas%' order by id_jurnal limit 1","","obj");
   // print_r($result2);
    foreach($result2 as $data2){
        
        //DEBET
        $conf=substr($row->kd_transaksi, 0,1);
        if(($conf=='D')||($conf=='E')||($conf=='F')||($conf=='G')||($conf=='L')){
            $mbuh=$i-$saldo;
            $array2[]=$saldo;
            $z=$mbuh;
        //KREDIT
        }else{
            $mbuh=$i+$saldo;
            $array1[]=$saldo;
            $z=$mbuh;
        }

        $response['aaData'][] = $row;
        $i=$z+0;  
        $x++;
    }
            
     
}
?>