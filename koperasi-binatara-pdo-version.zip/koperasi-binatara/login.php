<?php  include "call_bootstrap.php"; ?>


<script type='text/javascript'>  
    var $s = jQuery.noConflict();  
    $s(document).ready(function(){
        $('body').load(function() {
                            $('#user').bind('show', function() {
                            $('user a.btn').click(function(e) {
                                console.log('button pressed: '+$(this).html());
                                $('#user').modal('hide');
                            });
                            });
                            $('#user').bind('hide', function() {
                            $('#user a.btn').unbind();
                            });
                            $('user').modal({
                            'backdrop'  : 'static',
                            'keyboard'  : true,
                            'show'      : true  
                            });
    });
    });
</script>
<body>
    <div id="user" class="modal hide fade">
    <div class="modal-body">Wrong Username!!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="pass" class="modal hide fade">
    <div class="modal-body">Wrong Password!!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="log" class="modal hide fade">
    <div class="modal-body">Username and Password do not Match !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<?php

include "atribut/connect.php";
$username=$_POST['username'];
$password=$_POST['password'];
	
$user=mysql_query("SELECT * FROM admin WHERE username='$username'");
$u=mysql_num_rows($user);
$pass=mysql_query("SELECT * FROM admin WHERE md5(password)='$password'");
$p=mysql_num_rows($pass);
if($u=="") {
    $status=0;
} elseif ($p=="") {
    $status=1;
} else{
    $login=mysql_query("SELECT * FROM admin WHERE md5(password)='$password' and username='$username'");
    $log=mysql_num_rows($login);
    if($log==''){
        $status=2;
    }else{
        $row=mysql_fetch_array($login);
	$user=$row['username'];
	$pass=$row['password'];	
        session_start();
      //  $_SESSION['user']=$user;
      //  $_SESSION['pass']=$pass;
	//header("Location: home.php");
    }
   // session_start();		
}
?>
<input type="hidden" value="<?php echo $status; ?>" id="status" >

</body>