<?php
include '../atribut/basic.php';

$id_pajak_penghasilan=$_GET['id_pajak_penghasilan'];
$pajak_penghasilan=$_GET['pajak_penghasilan'];

$update1=$query->update("pengaturan","id_setting='".$id_pajak_penghasilan."'",array('content',$pajak_penghasilan));
?>
