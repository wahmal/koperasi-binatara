<?php
include '../atribut/connect.php';
$data=array();
$i=0;
$setting=  mysql_query("select content_pembanding from neraca_pembanding where id in (2,36,37,38,39,40,41,42,43,44) order by id asc")or die (mysql_error());
while($row= mysql_fetch_object($setting)){
$data[$i]=$row->content_pembanding;
$i++;

}
$json=array('kas'=>$data[0],'a'=>$data[1],'b'=>$data[2],'c'=>$data[3],'d'=>$data[4],'e'=>$data[5],'f'=>$data[6],'g'=>$data[7],'h'=>$data[8],'i'=>$data[9]);
echo json_encode($json);
?>