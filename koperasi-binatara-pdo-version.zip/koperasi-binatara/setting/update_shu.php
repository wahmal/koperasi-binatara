<?php
include '../atribut/basic.php';
include '../setting.php';
$data=explode(':',$_GET['data']);
for($i=1; $i<=11; $i++){
    if(empty($data[$i])){$data[$i]=0;}
    $update=$query->update("shu_pembanding","id='".$i."'",array("content_pembanding",$data[$i]));    
}
$array=array();
//netto anggota
$array[0]=$data[2]-$data[3];
//laba rugi
//$array[1]=$data[11];
//shu kotor
$array[1]=($data[4]-$data[5])+($data[11]+$array[0]);
//shu koperasi
$array[2]=$array[1]-$data[6];
//shu setelah koperasian
$array[3]=$array[2]-$data[7];
//shu sebelum pos2
$array[4]=$array[3]-$data[8];
//shu sebelum pajak
$array[5]=$array[4]-$data[9];
//shu setelah pajak
$array[6]=$array[5]-$data[10];

$x=12;
for($i=0; $i<=6; $i++){
	$update=$query->update("shu_pembanding","id='".$x."'",array("content_pembanding",$array[$i]));   
$x++;
}
//echo $array[2];
//echo $data[2];
?>
