<?php
include '../atribut/connect.php';
$data=array();
$i=0;
$setting=  mysql_query("select content_pembanding from shu_pembanding where id >='11' and id <='18' order by id asc")or die (mysql_error());
while($row= mysql_fetch_object($setting)){
$data[$i]=$row->content_pembanding;
$i++;

}
$json=array('a'=>$data[0],'b'=>$data[1],'c'=>$data[2],'d'=>$data[3],'e'=>$data[4],'f'=>$data[5],'g'=>$data[6],'h'=>$data[7]);
echo json_encode($json);
?>