<div class="tab-pane" id="tab7">
<style>
#form_shu input{width:150px;height:20px;}
#form_shu select{width:150px;height:30px;font-size: 13px;padding: 0px;margin: 0px;}

</style>
<?php include'setting/data_shu.php'; ?>
<form id="form_shu">
<table CELLSPACING="0" COLS="4" BORDER="0" align="center" width="90%">


	<tr>
		<td colspan=3 HEIGHT="10" align="CENTER"  width="1600"><br></td>
                <td align="RIGHT" ><b><label for="b1"></label>
                    <select id="b1" name="b1"> 
                            <option value="">-PILIH TAHUN-</option>
                            <?php
                            $sekarang=date("Y");
                            for($i=$sekarang-20; $i<$sekarang; $i++ ){
                                if($content_p[0]==$i){
                                    echo "<option value='".$i."' selected>".$i."</option>";
                                }else{
                                    echo "<option value='".$i."'>".$i."</option>";
                                }
                            }
                            ?>
                        </select>
                    </b></td>
        </tr>
	<tr>
		<td HEIGHT="19" align="LEFT" colspan="4"><b>PARTISIPASI ANGGOTA</b></td>

	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" width="30"><br></td>
		<td colspan=2 align="LEFT">Partisipasi Bruto Anggota</td>
                <td align="RIGHT" ><label for="b2"></label><input type="text" name="b2" id="b2" value="<?php echo $content_p[1]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Beban Pokok</td>
		<td  align="RIGHT" ><label for="b3"></label><input type="text" name="b3" id="b3" value="<?php echo $content_p[2]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Partisipasi Neto Anggota</td>
		<td align="RIGHT" >
                    <label for="b4"></label><input type="text" name="b4" id="b4" value="<?php echo $content_p[11]; ?>" readonly>
                </td>
	</tr>
	<tr>
		<td HEIGHT="19" colspan="4"><br></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" colspan="4"><b>PENDAPATAN DARI NON ANGGOTA</b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Penjualan</td>
		<td align="RIGHT" ><label for="b5"></label><input type="text" name="b5" id="b5" value="<?php echo $content_p[3]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Harga Pokok</td>
		<td align="RIGHT" ><label for="b6"></label><input type="text" name="b6" id="b6" value="<?php echo $content_p[4]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >
                    <?php
                        $explode=  explode('-', $content_p[10]);
                        if(empty($explode[0])){
                            $content_p[10]=$explode[1];
                    ?>
                            <input type="radio" style="margin:0px;width: 20;" name="lr" id="lr" value="0" >Laba / 
                            <input type="radio" style="margin:0px;width: 20;" name="lr" id="lr" value="1" checked>Rugi Kotor Dengan Non-Anggota 
                            <?php
                        }else{
                            ?>
                            <input type="radio" style="margin:0px;width: 20;" name="lr" id="lr" value="0" checked>Laba / 
                            <input type="radio" style="margin:0px;width: 20;" name="lr" id="lr" value="1" >Rugi Kotor Dengan Non-Anggota 
                            <?php } ?>
                </td>
		<td  align="RIGHT" ><label for="b7"></label><input type="text" name="b7" id="b7" value="<?php echo $content_p[10]; ?> "></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" width="20"><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Kotor</td>
		<td  align="RIGHT" >
                    <label for="b8"></label><input type="text" name="b8" id="b8" value="<?php echo $content_p[12]; ?>" readonly>
                </td>
	</tr>
	<tr>
		<td HEIGHT="19" align="CENTER" colspan="4"><br></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" colspan="4"><b>BEBAN OPERASI</b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Beban Usaha</td>
		<td  align="RIGHT" ><label for="b9"></label><input type="text" name="b9" id="b9" value="<?php echo $content_p[5]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" ><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Koperasi</td>
		<td align="RIGHT" ><label for="b10"></label><input type="text" name="b10" id="b10" value="<?php echo $content_p[13]; ?>" readonly></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Beban Perkoperasian</td>
		<td  align="RIGHT" ><label for="b11"></label><input type="text" name="b11" id="b11" value="<?php echo $content_p[6]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" ><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Setelah Perkoperasian</td>
		<td align="RIGHT" ><label for="b12"></label><input type="text" name="b12" id="b12" value="<?php echo $content_p[14]; ?>" readonly></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Pendapatan Dan Beban Lain-Lain</td>
		<td  align="RIGHT" >
                    <label for="b13"></label><input type="text" name="b13" id="b13" value="<?php echo $content_p[7]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" ><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Sebelum Pos-Pos Luar Biasa</td>
		<td align="RIGHT" ><label for="b14"></label><input type="text" name="b14" id="b14" value="<?php echo $content_p[15]; ?>" readonly></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Pendapatan Dan Beban Luar Biasa</td>
		<td  align="RIGHT" >
                    <label for="b15"></label><input type="text" name="b15" id="b15" value="<?php echo $content_p[8]; ?>">
                </td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" ><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Sebelum Pajak</td>
		<td align="RIGHT" ><label for="b16"></label><input type="text" name="b16" id="b16" value="<?php echo $content_p[16]; ?>" readonly></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Pajak Penghasilan</td>
               
		<td  align="RIGHT" >
                    <label for="b17"></label><input type="text" name="b17" id="b17" value="<?php echo $content_p[9]; ?>">
                </td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" ><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Setelah Pajak</td>
		<td  align="RIGHT" >
                    <label for="b18"></label><input type="text" name="b18" id="b18" value="<?php echo $content_p[17]; ?>" readonly>
                </td>
	</tr>
</table>
         <hr>
 <button type="submit" class="btn btn-success" id="tombol" >Update</button>
 <button type="reset" class="btn">Reset</button>   
    </form>
</div>

<script>
var $s = jQuery.noConflict();           
$s(document).ready(function(){
    
 $s('#form_shu').validate({
	    rules: {
              b1:{required:true},
	      b2:{number:true},
              b3:{number:true},
              b5:{number:true},
              b6:{number:true},
              b9:{number:true},
              b13:{number:true},
              b15:{number:true},
              b17:{number:true}
	    },
            submitHandler: function() { 
                
                if(confirm("Yakin Melakukan Perubahan ? Seluruh Sistem Akan Terpengaruh.,"))
        {
            var b1 = $s("#b1").attr("value");
            var b2 = $s("#b2").attr("value");
            var b3 = $s("#b3").attr("value");
            var b5 = $s("#b5").attr("value");
            var b6 = $s("#b6").attr("value");
            var b7 = $s("#b7").attr("value");
            var b9 = $s("#b9").attr("value");
            var b11 = $s("#b11").attr("value");
            var b13 = $s("#b13").attr("value");
            var b15 = $s("#b15").attr("value");
            var b17 = $s("#b17").attr("value");
            var lr = $s("input[name=lr]:checked").val();
            if(lr=='1'){var b7='-'+b7;}

                    $s.ajax({
                        type: "GET", 
                        url: "<?php echo site_path ?>setting/update_shu.php", 
                        data: "data=" + "karep:"+b1 +":"+ b2+":"+b3+":"+b5+":"+b6+":"+b9+":"+b11+":"+b13+":"+b15+":"+b17+":"+b7,
                        complete: function(data){
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                           
                          $s.getJSON ('<?php echo site_path ?>setting/shu_json.php',function (json) {
                                $s("#b4").val(json.b);
                                $s("#b8").val(json.c);
                                $s("#b10").val(json.d);
                                $s("#b12").val(json.e);
                                $s("#b14").val(json.f);
                                $s("#b16").val(json.g);
                                $s("#b18").val(json.h);
                            });
                        }
                    });
        }
                    return false;
                }
});
});	
</script>