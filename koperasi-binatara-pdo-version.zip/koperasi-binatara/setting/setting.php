<script src="<?php echo site_path; ?>bootstrap/js/validate/jquery-1.7.1.min.js"></script>
<script src="<?php echo site_path; ?>bootstrap/js/validate/jquery.validate.min.js"></script>

<?php
include'setting.php';
?>

<legend id="daftar">Pengaturan Koperasi</legend>

<!--TAB SETTING-->
<div class="tabbable"> 
  <ul class="nav nav-tabs">
    <li class="active"><a href="#tab1" data-toggle="tab">Tarif Simpanan</a></li>
    <li><a href="#tab2" data-toggle="tab">Tarif Pinjaman</a></li>
    <li><a href="#tab3" data-toggle="tab">Tarif Pajak</a></li>
    <li><a href="#tab4" data-toggle="tab">Saldo Awal</a></li>
    <li><a href="#tab6" data-toggle="tab">Pembanding Neraca</a></li>
    <li><a href="#tab7" data-toggle="tab">Pembanding SHU</a></li>
    <li ><a href="#tab8" data-toggle="tab">Slide Show</a></li>
  </ul>
  <div class="tab-content">
<?php include'setting/setting_simpanan.php'; ?>
<?php include'setting/setting_pinjaman.php'; ?>
<?php include'setting/setting_pajak.php'; ?>        
<?php include'setting/setting_saldo.php'; ?>
<?php include'setting/setting_neraca.php'; ?>
<?php include'setting/setting_shu.php'; ?>
<?php include'setting/setting_carousel.php'; ?>
  </div>
</div>


<!--MODAL-->
<div id="myModal" class="modal hide fade">
    <div class="modal-body">Pengaturan Telah di perbarui !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<!--VALIDATE FORM-->

