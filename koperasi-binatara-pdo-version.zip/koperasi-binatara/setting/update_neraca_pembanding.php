<?php
include '../atribut/basic.php';

$data=explode(':',$_GET['data']);
for($i=1; $i<=35; $i++){
    if(empty($data[$i])){$data[$i]=0;}
	$update=$query->update("neraca_pembanding","id='".$i."'",array('content_pembanding',$data[$i]));    
}

$array=array();

$aktiva_lancar=$data[3]+$data[4]+$data[5]+$data[6]+$data[7]+$data[8]+$data[9]+$data[10];
$inv_jangka_panjang=$data[11]+$data[12];
$aktiva_tetap=$data[13]+$data[14]+$data[15]+$data[16]+$data[17];
$aktiva_lain=$data[18]+$data[19];

$kew_jangka_pendek=$data[20]+$data[21]+$data[22]+$data[23]+$data[24]+$data[25]+$data[26];
$kew_jangka_panjang=$data[27]+$data[28];
$ekuitas=$data[29]+$data[30]+$data[31]+$data[32]+$data[33]+$data[34]+$data[35];

$kas=($data[2]+$kew_jangka_pendek+$kew_jangka_panjang+$ekuitas)-$aktiva_lancar-$inv_jangka_panjang-$aktiva_tetap-$aktiva_lain;
$aktiva_lancar=$kas+$aktiva_lancar;

$array[0]=$aktiva_lancar;
$array[1]=$inv_jangka_panjang;
$array[2]=$aktiva_tetap;
$array[3]=$aktiva_lain;
$array[4]=$aktiva_lancar+$inv_jangka_panjang+$aktiva_tetap+$aktiva_lain;
$array[5]=$kew_jangka_pendek;    
$array[6]=$kew_jangka_panjang;
$array[7]=$ekuitas;
$array[8]=$kew_jangka_pendek+$kew_jangka_panjang+$ekuitas;

$x=36;
for($i=0; $i<=9; $i++){
    if($i==9){
       $update=$query->update("neraca_pembanding","id='2'",array('content_pembanding',$kas));     
    }else{
    	$update=$query->update("neraca_pembanding","id='".$x."'",array('content_pembanding',$array[$i]));
    }
    $x++;
}
?>
