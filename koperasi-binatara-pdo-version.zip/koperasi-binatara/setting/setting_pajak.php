    <div class="tab-pane" id="tab3">
      <!--TAB 2-->
      <form action="#" method="post" id="form_pajak" class="form-horizontal">
        <i class="icon-search icon-chevron-right"></i> <strong>Pajak Penghasilan :</strong>
        <div class="form-actions" style="padding:0px;margin:0px;padding-top: 10px;margin-bottom: 10px;">
        <table border="0">
            <tr>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="pajak_penghasilan">Tarif :</label>
                      <div class="controls">
                        <input class="span1" type="text" name="pajak_penghasilan" id="pajak_penghasilan" value="<?php echo $pajak_penghasilan;?>"> %
                      </div>
                    </div>
                </td>
            </tr>
        </table>
        </div>
        <div style="background:#FFF;margin-left: 0px;padding-top: 5px;">
        <button type="submit" class="btn btn-success" id="tombol" >Update</button>
        <button type="reset" class="btn">Reset</button>
        </div>
      </form>
            
    </div>
<script>
var $s = jQuery.noConflict();           
$s(document).ready(function(){
   
$s('#form_pajak').validate({
	    rules: {
	      pajak_penghasilan: {
	        number:true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
               //content
                var pajak_penghasilan = $s("#pajak_penghasilan").attr("value");
                
                //id
                id_pajak_penghasilan="<?php echo $id_pajak_penghasilan;?>";
                
                if(confirm("Yakin Melakukan Perubahan ? Seluruh Sistem Akan Terpengaruh.,"))
        {
                    $s.ajax({
                        type: "GET", 
                        url: "<?php echo site_path; ?>setting/update_pajak.php", 
                        data: "id_pajak_penghasilan=" + id_pajak_penghasilan + "&pajak_penghasilan=" + pajak_penghasilan ,
                        complete: function(data){
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                        }
                    });
        }
                    return false;
                }
});
});
</script>