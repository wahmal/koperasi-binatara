    <div class="tab-pane" id="tab4">
      <!--TAB 2-->
      <form action="#" method="post" id="form_saldo" class="form-horizontal">
        <i class="icon-search icon-chevron-right"></i> <strong>Saldo Kas Awal :</strong>
        <div class="form-actions" style="padding:0px;margin:0px;padding-top: 10px;margin-bottom: 10px;">
        <table border="0">
            <tr>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="saldo_awal">Saldo :</label>
                      <div class="controls">
                        <input type="text" name="saldo_awal" id="saldo_awal" value="<?php echo $saldo_awal;?>">
                      </div>
                    </div>
                </td>
            </tr>
        </table>
        </div>
        <div style="background:#FFF;margin-left: 0px;padding-top: 5px;">
        <button type="submit" class="btn btn-success" id="tombol" >Update</button>
        <button type="reset" class="btn">Reset</button>
        </div>
      </form>
            
    </div>
<script>
var $s = jQuery.noConflict();           
$s(document).ready(function(){
   
$s('#form_saldo').validate({
	    rules: {
	      saldo_awal: {
	        number:true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
               //content
                var saldo_awal = $s("#saldo_awal").attr("value");
                
                //id
                id_saldo_awal="<?php echo $id_saldo_awal;?>";
                
                if(confirm("Yakin Melakukan Perubahan ? Seluruh Sistem Akan Terpengaruh.,"))
        {
                    $s.ajax({
                        type: "GET", 
                        url: "<?php echo site_path; ?>setting/update_saldo.php", 
                        data: "id_saldo_awal=" + id_saldo_awal + "&saldo_awal=" + saldo_awal ,
                        complete: function(data){
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                        }
                    });
        }
                    return false;
                }
});
});
</script>