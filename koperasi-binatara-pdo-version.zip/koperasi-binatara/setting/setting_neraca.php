<div class="tab-pane" id="tab6">
<!--TAB 1-->
<form action="#" method="post" id="form_neraca">
<?php include'setting/data_neraca.php'; ?>

    <style>
        #form_neraca input{width:150px;height:20px;}
        #form_neraca select{width:150px;height:30px;font-size:13px;}
    </style>
<table CELLSPACING="0" COLS="10" BORDER="0"width="95%" align="center">
	<tr>
		<td style="border-bottom: 3px solid #000000" HEIGHT="22"  colspan="10">&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="23" width="2%" >&nbsp;</td>
		<td  width="2%">&nbsp;</td>
		<td  width="30%">&nbsp;</td>
		<td  width="10%">&nbsp;</td>
		<td  width="1%">&nbsp;</td>
		<td width="1%" style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  width="2%">&nbsp;</td>
		<td width="2%" >&nbsp;</td>
		<td width="30%" >&nbsp;</td>
		<td  width="10%">&nbsp;</td>
	</tr>
	<tr>
		<td colspan=3 HEIGHT="19"  ><b>AKTIVA</b></td>
                <td align="right" > 
                    <label for="year1"></label>
                        <select name="year1" id="year1">
                            <option value="">-PILIH TAHUN-</option>
                            <?php
                            $sekarang=date("Y");
                            for($i=$sekarang-20; $i<$sekarang; $i++ ){
                                if($content_p[0]==$i){
                                    echo "<option value='".$i."' selected>".$i."</option>";
                                }else{
                                    echo "<option value='".$i."'>".$i."</option>";
                                }
                            }
                            ?>
                        </select>
                    </td>
		<td align="CENTER" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="CENTER" >&nbsp;</td>
		<td colspan=3  ><b>KEWAJIBAN DAN EKUITAS</b></td>
		<td align="right" >
                    <label for="year2"></label>
                        <select name="year2" id="year2">
                            <option value="">-PILIH TAHUN-</option>
                            <?php
                            for($i=$sekarang-20; $i<$sekarang; $i++ ){
                                if($content_p[0]==$i){
                                    echo "<option value='".$i."' selected>".$i."</option>";
                                }else{
                                    echo "<option value='".$i."'>".$i."</option>";
                                }
                            }
                            ?>
                        </select>
                    </td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="CENTER" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td colspan=3 HEIGHT="19"  >AKTIVA LANCAR</td>
		<td  >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="CENTER" >&nbsp;</td>
		<td colspan=3  >KEWAJIBAN JANGKA PENDEK</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Kas dan Bank</td>
		<td align="RIGHT" ><label for="1"></label><input type="text" name="1" value="<?php echo $content_p[1]; ?>" id="1" readonly></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Usaha</td>
		<td align="RIGHT" ><label for="19"></label><input type="text" name="19" value="<?php echo $content_p[19]; ?>" id="19"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Investasi Jangka Pendek</td>
		<td align="RIGHT" ><label for="2"></label><input type="text" name="2" value="<?php echo $content_p[2]; ?>" id="2"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Bank</td>
		<td align="RIGHT" ><label for="20"></label><input type="text" name="20" value="<?php echo $content_p[20]; ?>" id="20"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Usaha</td>
		<td align="RIGHT" ><label for="3"></label><input type="text"name="3" value="<?php echo $content_p[3]; ?>" id="3"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Pajak</td>
		<td align="RIGHT" ><label for="21"></label><input name="21" type="text" value="<?php echo $content_p[21]; ?>" id="21"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Pinjaman Anggota</td>
		<td align="RIGHT" ><label for="4"></label><input name="4" type="text" value="<?php echo $content_p[4]; ?>" id="4"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Simpanan Anggota</td>
		<td align="RIGHT" ><label for="22"></label><input name="22" type="text" value="<?php echo $content_p[22]; ?>" id="22"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Pinjaman Non-Anggota</td>
		<td align="RIGHT" ><label for="5"></label><input name="5" type="text" value="<?php echo $content_p[5]; ?>" id="5"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Dana Bagian SHU</td>
		<td align="RIGHT" ><label for="23"></label><input type="text" name="23" value="<?php echo $content_p[23]; ?>" id="23"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Lain-Lain</td>
		<td align="RIGHT" ><label for="6"></label><input name="6" type="text" value="<?php echo $content_p[6]; ?>" id="6"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Jangka Panjang Akan Jatuh Tempo</td>
		<td align="RIGHT" ><label for="24"></label><input name="24" type="text" value="<?php echo $content_p[24]; ?>" id="24"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Peny. Piutang Tak Tertagih</td>
		<td align="RIGHT" ><label for="7"></label><input name="7" type="text" value="<?php echo $content_p[7]; ?>" id="7"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Biaya Harus Dibayar</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="25"></label><input name="25" type="text" value="<?php echo $content_p[25]; ?>" id="25"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Persediaan</td>
		<td align="RIGHT" ><label for="8"></label><input name="8" type="text" value="<?php echo $content_p[8]; ?>" id="8"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Kewajiban jangka Pendek</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b><label for="40"></label><input name="40" type="text" value="<?php echo $content_p[40]; ?>" id="40" readonly></b></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Pendapatan Akan Diterima</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="9"></label><input name="9" type="text" value="<?php echo $content_p[9]; ?>" id="9"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Aktiva Lancar</td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b>
                        <label for="35"></label><input name="35" type="text" value="<?php echo $content_p[35]; ?>" id="35" readonly>
                    </b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  colspan="4">KEWAJIBAN JANGKA PANJANG</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Bank</td>
		<td align="RIGHT" ><label for="26"></label><input name="26" type="text" value="<?php echo $content_p[26]; ?>" id="26"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  colspan="5">INVESTASI JANGKA PANJANG</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Jangka Panjang Lainnya</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="27"></label><input name="27" type="text" value="<?php echo $content_p[27]; ?>" id="27"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Penyertaan Pada Koperasi</td>
		<td align="RIGHT" ><label for="10"></label><input name="10" type="text" value="<?php echo $content_p[10]; ?>" id="10"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Kewajiban Jangka Panjang</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b>
                        <label for="41"></label><input name="41" type="text" value="<?php echo $content_p[41]; ?>" id="41" readonly></b></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Penyertaan Pada Non-Koperasi</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="11"></label><input name="11" type="text" value="<?php echo $content_p[11]; ?>" id="11"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Investasi Jangka Panjang</td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b><label for="36"></label><input name="36" type="text" value="<?php echo $content_p[36]; ?>" id="36" readonly></b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  colspan="4">EKUITAS</td>
	</tr>
	<tr>
		<td HEIGHT="19" align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Simpanan Wajib</td>
		<td align="RIGHT" ><label for="28"></label><input name="28" type="text" value="<?php echo $content_p[28]; ?>" id="28"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  colspan="5">AKTIVA TETAP</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Simpanan Pokok</td>
		<td align="RIGHT" ><label for="29"></label><input name="29" type="text" value="<?php echo $content_p[29]; ?>" id="29"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Tanah/Hak Atas Tanah</td>
		<td align="RIGHT" ><label for="12"></label><input name="12" type="text" value="<?php echo $content_p[12]; ?>" id="12"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Modal Penyetaraan Partisipasi Anggota</td>
		<td align="RIGHT" ><label for="30"></label><input name="30" type="text" value="<?php echo $content_p[30]; ?>" id="30"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Bangunan</td>
		<td align="RIGHT" ><label for="13"></label><input name="13" type="text" value="<?php echo $content_p[13]; ?>" id="13"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Modal Penyertaan</td>
		<td align="RIGHT" ><label for="31"></label><input name="31" type="text" value="<?php echo $content_p[31]; ?>" id="31"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Mesin</td>
		<td align="RIGHT" ><label for="14"></label><input name="14" type="text" value="<?php echo $content_p[14]; ?>" id="14"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Modal Sumbangan</td>
		<td align="RIGHT" ><label for="32"></label><input name="32" type="text" value="<?php echo $content_p[32]; ?>" id="32"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Inventaris</td>
		<td align="RIGHT" ><label for="15"></label><input name="15" type="text" value="<?php echo $content_p[15]; ?>" id="15"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Cadangan</td>
		<td align="RIGHT" ><label for="33"></label><input name="33" type="text" value="<?php echo $content_p[33]; ?>" id="33"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Akumulasi Penyusutan</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="16"></label><input name="16" type="text" value="<?php echo $content_p[16]; ?>" id="16"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >SHU Belum Dibagi</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="34"></label><input name="34" type="text" value="<?php echo $content_p[34]; ?>" id="34"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Jumlah Aktiva Tetap</td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b><label for="37"></label><input name="37" type="text" value="<?php echo $content_p[37]; ?>" id="37" readonly></b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Ekuitas</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b><label for="42"></label><input name="42" type="text" value="<?php echo $content_p[42]; ?>" id="42" readonly></b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  colspan="5">AKTIVA LAIN-LAIN</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Aktiva tetap Dalam Konstruksi</td>
		<td align="RIGHT" ><label for="17"></label><input name="17" type="text" value="<?php echo $content_p[17]; ?>" id="17"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Beban Ditangguhkan</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="18"></label><input name="18" type="text" value="<?php echo $content_p[18]; ?>" id="18"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Aktiva Lain-Lain</td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b><label for="38"></label><input type="text" name="38" value="<?php echo $content_p[38]; ?>" id="38" readonly></b></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19" align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td colspan=3 HEIGHT="19"  ><b>JUMLAH AKTIVA</b></td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b><label for=39""></label><input name=39"" type="text" value="<?php echo $content_p[39]; ?>" id="39" readonly></b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td colspan=3  ><b>JUMLAH KEWAJIBAN &amp; EKUITAS</b></td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b><label for="43"></label><input name="43" type="text" value="<?php echo $content_p[43]; ?>" id="43" readonly></b></td>
	</tr>
</table>
    <hr>
 <button type="submit" class="btn btn-success" id="tombol" >Update</button>
 <button type="reset" class="btn">Reset</button>   
</form>
</div>
<script>
var $s = jQuery.noConflict();           
$s(document).ready(function(){
    
    $s('#year1').change(function(){
        var date = $s("#year1").val(); 
        $s("#year2 option[value='"+date+"']").attr("selected", "selected");  
    });
    $s('#year2').change(function(){
         var date = $s("#year2").val();
        $s("#year1 option[value='"+date+"']").attr("selected", "selected");  
    });
    
 $s('#form_neraca').validate({
	    rules: {
              year1:{required:true},
	      1:{number:true},
              2:{number:true},
              3:{number:true},
              4:{number:true},
              5:{number:true},
              6:{number:true},
              7:{number:true},
              8:{number:true},
              9:{number:true},
              10:{number:true},
              12:{number:true},
              13:{number:true},
              14:{number:true},
              15:{number:true},
              16:{number:true},
              17:{number:true},
              18:{number:true},
              19:{number:true},
              20:{number:true},
              21:{number:true},
              22:{number:true},
              23:{number:true},
              24:{number:true},
              25:{number:true},
              26:{number:true},
              27:{number:true},
              28:{number:true},
              29:{number:true},
              31:{number:true},
              32:{number:true},
              33:{number:true},
              34:{number:true},
              35:{number:true},
              36:{number:true},
              37:{number:true},
              38:{number:true},
              39:{number:true}
	    },
            submitHandler: function() { 
                
                if(confirm("Yakin Melakukan Perubahan ? Seluruh Sistem Akan Terpengaruh.,"))
        {
            var year = $s("#year1").attr("value");
            var a1 = '';
            var a2 = $s("#2").attr("value");
            var a3 = $s("#3").attr("value");
            var a4 = $s("#4").attr("value");
            var a5 = $s("#5").attr("value");
            var a6 = $s("#6").attr("value");
            var a7 = $s("#7").attr("value");
            var a8 = $s("#8").attr("value");
            var a9 = $s("#9").attr("value");
            var a10 = $s("#10").attr("value");
            var a11 = $s("#11").attr("value");
            var a12 = $s("#12").attr("value");
            var a13 = $s("#13").attr("value");
            var a14 = $s("#14").attr("value");
            var a15 = $s("#15").attr("value");
            var a16 = $s("#16").attr("value");
            var a17 = $s("#17").attr("value");
            var a18 = $s("#18").attr("value");
            var a19 = $s("#19").attr("value");
            var a20 = $s("#20").attr("value");
            var a21 = $s("#21").attr("value");
            var a22 = $s("#22").attr("value");
            var a23 = $s("#23").attr("value");
            var a24 = $s("#24").attr("value");
            var a25 = $s("#25").attr("value");
            var a26 = $s("#26").attr("value");
            var a27 = $s("#27").attr("value");
            var a28 = $s("#28").attr("value");
            var a29 = $s("#29").attr("value");
            var a30 = $s("#30").attr("value");
            var a31 = $s("#31").attr("value");
            var a32 = $s("#32").attr("value");
            var a33 = $s("#33").attr("value");
            var a34 = $s("#34").attr("value");
                    $s.ajax({
                        type: "GET", 
                        url: "<?php echo site_path; ?>setting/update_neraca_pembanding.php", 
                        data: "data=" + "karep:"+year+":"+a1 +":"+ a2+":"+a3+":"+a4+":"+a5+":"+a6+":"+a7+":"+a8+":"+a9+":"+a10+":"+a11+":"+a12+":"+a13+":"+a14+":"+a15+":"+a16+":"+a17+":"+a18+":"+a19+":"+a20
                        +":"+a21+":"+a22+":"+a23+":"+a24+":"+a25+":"+a26+":"+a27+":"+a28+":"+a29+":"+a30+":"+a31+":"+a32+":"+a33+":"+a34,
                        complete: function(data){
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                            
                            $s.getJSON ('<?php echo site_path ?>setting/neraca_json.php',function (json) {
                                $s("#1").val(json.kas);
                                $s("#35").val(json.a);
                                $s("#36").val(json.b);
                                $s("#37").val(json.c);
                                $s("#38").val(json.d);
                                $s("#39").val(json.e);
                                $s("#40").val(json.f);
                                $s("#41").val(json.g);
                                $s("#42").val(json.h);
                                $s("#43").val(json.i);
                            });
                        }
                    });
        }
                    return false;
                }
});
});	
</script>