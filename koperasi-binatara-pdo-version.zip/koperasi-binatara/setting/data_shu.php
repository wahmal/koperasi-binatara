<?php
$content=array();
$content_p=array();
$sql=$query->read("shu_pembanding","order by id asc",'','obj');
foreach($sql as $row){
    $content[]=$row->content;
    $content_p[]=$row->content_pembanding;
}
?>
