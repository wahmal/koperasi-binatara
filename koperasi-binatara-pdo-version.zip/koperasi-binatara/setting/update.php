<?php
include '../atribut/connect.php';

$id_simpanan_pokok=$_GET['id_simpanan_pokok'];
$simpanan_pokok=$_GET['simpanan_pokok'];
$id_simpanan_wajib=$_GET['id_simpanan_wajib'];
$simpanan_wajib=$_GET['simpanan_wajib'];
//jangka panjang
$id_jangka_panjang=$_GET['id_jangka_panjang'];
$jangka_panjang=$_GET['jangka_panjang'];
$id_cicilan_jangka_panjang=$_GET['id_cicilan_jangka_panjang'];
$cicilan_jangka_panjang=$_GET['cicilan_jangka_panjang'];
$id_bunga_jangka_panjang=$_GET['id_bunga_jangka_panjang'];
$bunga_jangka_panjang=$_GET['bunga_jangka_panjang'];
//jangka pendek
$id_jangka_pendek=$_GET['id_jangka_pendek'];
$jangka_pendek=$_GET['jangka_pendek'];
$id_cicilan_jangka_pendek=$_GET['id_cicilan_jangka_pendek'];
$cicilan_jangka_pendek=$_GET['cicilan_jangka_pendek'];
$id_bunga_jangka_pendek=$_GET['id_bunga_jangka_pendek'];
$bunga_jangka_pendek=$_GET['bunga_jangka_pendek'];
//elektronik
$id_elektronik=$_GET['id_elektronik'];
$elektronik=$_GET['elektronik'];
$id_cicilan_elektronik=$_GET['id_cicilan_elektronik'];
$cicilan_elektronik=$_GET['cicilan_elektronik'];
$id_bunga_elektronik=$_GET['id_bunga_elektronik'];
$bunga_elektronik=$_GET['bunga_elektronik'];
//sabrek
$id_sebrak=$_GET['id_sebrak'];
$sebrak=$_GET['sebrak'];
$id_cicilan_sebrak=$_GET['id_cicilan_sebrak'];
$cicilan_sebrak=$_GET['cicilan_sebrak'];
$id_bunga_sebrak=$_GET['id_bunga_sebrak'];
$bunga_sebrak=$_GET['bunga_sebrak'];

$update1=mysql_query("update pengaturan set content='".$simpanan_pokok."' where id_setting='".$id_simpanan_pokok."'")or die (mysql_error());
$update2=mysql_query("update pengaturan set content='".$simpanan_wajib."' where id_setting='".$id_simpanan_wajib."'")or die (mysql_error());
//jangka panjang
$update3=mysql_query("update pengaturan set content='".$jangka_panjang."' where id_setting='".$id_jangka_panjang."'")or die (mysql_error());
$update4=mysql_query("update pengaturan set content='".$cicilan_jangka_panjang."' where id_setting='".$id_cicilan_jangka_panjang."'")or die (mysql_error());
$update5=mysql_query("update pengaturan set content='".$bunga_jangka_panjang."' where id_setting='".$id_bunga_jangka_panjang."'")or die (mysql_error());
//jangka pendek
$update6=mysql_query("update pengaturan set content='".$jangka_pendek."' where id_setting='".$id_jangka_pendek."'")or die (mysql_error());
$update7=mysql_query("update pengaturan set content='".$cicilan_jangka_pendek."' where id_setting='".$id_cicilan_jangka_pendek."'")or die (mysql_error());
$update8=mysql_query("update pengaturan set content='".$bunga_jangka_pendek."' where id_setting='".$id_bunga_jangka_pendek."'")or die (mysql_error());
//elektronik
$update9=mysql_query("update pengaturan set content='".$elektronik."' where id_setting='".$id_elektronik."'")or die (mysql_error());
$update10=mysql_query("update pengaturan set content='".$cicilan_elektronik."' where id_setting='".$id_cicilan_elektronik."'")or die (mysql_error());
$update11=mysql_query("update pengaturan set content='".$bunga_elektronik."' where id_setting='".$id_bunga_elektronik."'")or die (mysql_error());
//sebrak
$update12=mysql_query("update pengaturan set content='".$sebrak."' where id_setting='".$id_sebrak."'")or die (mysql_error());
$update13=mysql_query("update pengaturan set content='".$cicilan_sebrak."' where id_setting='".$id_cicilan_sebrak."'")or die (mysql_error());
$update14=mysql_query("update pengaturan set content='".$bunga_sebrak."' where id_setting='".$id_bunga_sebrak."'")or die (mysql_error());
?>
