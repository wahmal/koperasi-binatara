<?php

include '../atribut/basic.php';
$id_simpanan_pokok=$_GET['id_simpanan_pokok'];
$simpanan_pokok=$_GET['simpanan_pokok'];
$id_simpanan_wajib=$_GET['id_simpanan_wajib'];
$simpanan_wajib=$_GET['simpanan_wajib'];

$update1=$query->update("pengaturan","id_setting='".$id_simpanan_pokok."'",array('content',$simpanan_pokok));
$update2=$query->update("pengaturan","id_setting='".$id_simpanan_wajib."'",array('content',$simpanan_wajib));

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
