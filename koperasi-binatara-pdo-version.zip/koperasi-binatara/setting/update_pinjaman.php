<?php
include '../atribut/basic.php';


//jangka panjang
$id_jangka_panjang=$_GET['id_jangka_panjang'];
$jangka_panjang=$_GET['jangka_panjang'];
$id_cicilan_jangka_panjang=$_GET['id_cicilan_jangka_panjang'];
$cicilan_jangka_panjang=$_GET['cicilan_jangka_panjang'];
$id_bunga_jangka_panjang=$_GET['id_bunga_jangka_panjang'];
$bunga_jangka_panjang=$_GET['bunga_jangka_panjang'];
//jangka pendek
$id_jangka_pendek=$_GET['id_jangka_pendek'];
$jangka_pendek=$_GET['jangka_pendek'];
$id_cicilan_jangka_pendek=$_GET['id_cicilan_jangka_pendek'];
$cicilan_jangka_pendek=$_GET['cicilan_jangka_pendek'];
$id_bunga_jangka_pendek=$_GET['id_bunga_jangka_pendek'];
$bunga_jangka_pendek=$_GET['bunga_jangka_pendek'];
//elektronik
$id_elektronik=$_GET['id_elektronik'];
$elektronik=$_GET['elektronik'];
$id_cicilan_elektronik=$_GET['id_cicilan_elektronik'];
$cicilan_elektronik=$_GET['cicilan_elektronik'];
$id_bunga_elektronik=$_GET['id_bunga_elektronik'];
$bunga_elektronik=$_GET['bunga_elektronik'];
//sabrek
$id_sebrak=$_GET['id_sebrak'];
$sebrak=$_GET['sebrak'];
$id_cicilan_sebrak=$_GET['id_cicilan_sebrak'];
$cicilan_sebrak=$_GET['cicilan_sebrak'];
$id_bunga_sebrak=$_GET['id_bunga_sebrak'];
$bunga_sebrak=$_GET['bunga_sebrak'];

//jangka panjang
$update3=$query->update("pengaturan","id_setting='".$id_jangka_panjang."'",array('content',$jangka_panjang));
$update4=$query->update("pengaturan","id_setting='".$id_cicilan_jangka_panjang."'",array('content',$cicilan_jangka_panjang));
$update5=$query->update("pengaturan","id_setting='".$id_bunga_jangka_panjang."'",array('content',$bunga_jangka_panjang));
//jangka pendek
$update6=$query->update("pengaturan","id_setting='".$id_jangka_pendek."'",array('content',$jangka_pendek));
$update7=$query->update("pengaturan","id_setting='".$id_cicilan_jangka_pendek."'",array('content',$cicilan_jangka_pendek));
$update8=$query->update("pengaturan","id_setting='".$id_bunga_jangka_pendek."'",array('content',$bunga_jangka_pendek));
//elektronik
$update9=$query->update("pengaturan","id_setting='".$id_elektronik."'",array('content',$elektronik));
$update10=$query->update("pengaturan","id_setting='".$id_cicilan_elektronik."'",array('content',$cicilan_elektronik));
$update11=$query->update("pengaturan","id_setting='".$id_bunga_elektronik."'",array('content',$bunga_elektronik));
//sebrak
$update12=$query->update("pengaturan","id_setting='".$id_sebrak."'",array('content',$sebrak));
$update13=$query->update("pengaturan","id_setting='".$id_cicilan_sebrak."'",array('content',$cicilan_sebrak));
$update14=$query->update("pengaturan","id_setting='".$id_bunga_sebrak."'",array('content',$bunga_sebrak));
?>
