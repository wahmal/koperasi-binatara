<?php session_start();?>
<?php include '../atribut/basic.php'; 
    $edit=$query->read("carousel","where id_img='".$_POST['id_img']."'");
    $img = $edit[0]['img'];
    @unlink('../img/'.$img);
    @unlink('../img/thumb/'.$img);
    $delete=$query->delete("carousel","id_img",array($_POST['id_img']));
?>