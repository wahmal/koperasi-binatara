    <div class="tab-pane active" id="tab1">
        <!--TAB 1-->
        <form action="#" method="post" id="form_simpanan" class="form-horizontal">
        <i class="icon-search icon-chevron-right"></i> <strong>Simpanan :</strong>
        <div class="form-actions" style="padding:0px;margin:0px;padding-top: 10px;margin-bottom: 10px;">
        <table border="0">
            <tr>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="simpanan_pokok">Pokok :</label>
                      <div class="controls">
                        <input type="text" name="simpanan_pokok" id="simpanan_pokok" value="<?php echo $setting_simpanan_pokok;?>">
                      </div>
                    </div>
                </td>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="simpanan_wajib">Wajib :</label>
                      <div class="controls">
                        <input type="text" name="simpanan_wajib" id="simpanan_wajib" value="<?php echo $setting_simpanan_wajib;?>">
                      </div>
                    </div>
               </td>
            </tr>
        </table>   
        </div>
        <div style="background:#FFF;margin-left: 0px;padding-top: 5px;">
        <button type="submit" class="btn btn-success" id="tombol" >Update</button>
        <button type="reset" class="btn">Reset</button>
        </div>
        </form>
    </div>

<script>
var $s = jQuery.noConflict();           
$s(document).ready(function(){
          
$s('#form_simpanan').validate({
	    rules: {
	      simpanan_pokok: {
	        number:true,
	        required: true
	      },
	      simpanan_wajib: {
                number:true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
               //content
                var simpanan_pokok = $s("#simpanan_pokok").attr("value");
                simpanan_wajib  = $s("#simpanan_wajib").attr("value");
               
                //id
                id_simpanan_pokok="<?php echo $id_setting_simpanan_pokok;?>";
                id_simpanan_wajib="<?php echo $id_setting_simpanan_wajib;?>";
 
                if(confirm("Yakin Melakukan Perubahan ? Seluruh Sistem Akan Terpengaruh.,"))
        {
                    $s.ajax({
                        type: "GET", 
                        url: "<?php echo site_path; ?>setting/update_simpanan.php", 
                        data: "id_simpanan_pokok=" + id_simpanan_pokok + "&simpanan_pokok=" + simpanan_pokok + 
                            "&id_simpanan_wajib=" + id_simpanan_wajib + "&simpanan_wajib=" + simpanan_wajib,
                        complete: function(data){
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                        }
                    });
        }
                    return false;
                }
});



});	
</script>