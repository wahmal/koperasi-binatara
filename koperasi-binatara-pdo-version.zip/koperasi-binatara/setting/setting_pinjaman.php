 <div class="tab-pane" id="tab2">
<!--TAB 1-->
<form action="#" method="post" id="form_pinjaman" class="form-horizontal">
<i class="icon-search icon-chevron-right"></i> <strong>Pinjaman Jangka Panjang :</strong>
        <div class="form-actions" style="padding:0px;margin:0px;padding-top: 10px;margin-bottom: 10px;">
        <table border="0" >
            <tr>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="jangka_panjang" >Pinjaman Max :</label>
                      <div class="controls" style="padding-left:0px;">
                        <input type="text" name="jangka_panjang" id="jangka_panjang" value="<?php echo $jangka_panjang;?>">
                      </div>
                    </div>
                </td>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="cicilan_jangka_panjang">Cicilan Max :</label>
                      <div class="controls">
                        <input type="text" class="input-small" name="cicilan_jangka_panjang" id="cicilan_jangka_panjang" value="<?php echo $cicilan_jangka_panjang;?>">
                      </div>
                    </div>  
               </td>
            </tr>
            <tr>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="bunga_jangka_panjang">Bunga :</label>
                      <div class="controls">
                        <input type="text" class="input-small" name="bunga_jangka_panjang" id="bunga_jangka_panjang" value="<?php echo $bunga_jangka_panjang;?>"> %
                      </div>
                    </div>  
               </td>
               <td>&nbsp;</td>
            </tr>
        </table>
        </div>
        <i class="icon-search icon-chevron-right"></i> <strong>Pinjaman Jangka Pendek :</strong>
        <div class="form-actions" style="padding:0px;margin:0px;padding-top: 10px;margin-bottom: 10px;">
        <table border="0">
            <tr>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="jangka_pendek">Jangka Pendek Max :</label>
                      <div class="controls">
                        <input type="text" name="jangka_pendek" id="jangka_pendek" value="<?php echo $jangka_pendek;?>">
                      </div>
                    </div>
                </td>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="cicilan_jangka_pendek">Cicilan Max :</label>
                      <div class="controls">
                        <input type="text" class="input-small" name="cicilan_jangka_pendek" id="cicilan_jangka_pendek" value="<?php echo $cicilan_jangka_pendek;?>">
                      </div>
                    </div>  
               </td>
            </tr>
            <tr>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="bunga_jangka_pendek">Bunga :</label>
                      <div class="controls">
                        <input type="text" class="input-small" name="bunga_jangka_pendek" id="bunga_jangka_pendek" value="<?php echo $bunga_jangka_pendek;?>"> %
                      </div>
                    </div>  
               </td>
               <td>&nbsp;</td>
            </tr>
        </table>
        </div>           
        <i class="icon-search icon-chevron-right"></i> <strong>Pinjaman Elektronik :</strong>
        <div class="form-actions" style="padding:0px;margin:0px;padding-top: 10px;margin-bottom: 10px;">
        <table border="0">           
            <tr>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="elektronik">Elektronik Max :</label>
                      <div class="controls">
                        <input type="text" name="elektronik" id="elektronik" value="<?php echo $elektronik;?>">
                      </div>
                    </div>  
               </td>
                <td>
                   <div class="control-group">
                      <label class="control-label" for="cicilan_elektronik">Cicilan Max :</label>
                      <div class="controls">
                        <input type="text" class="input-small" name="cicilan_elektronik" id="cicilan_elektronik" value="<?php echo $cicilan_elektronik;?>">
                      </div>
                    </div> 
                </td>
            </tr>
            <tr>
                <td>
                 <div class="control-group">
                      <label class="control-label" for="bunga_elektronik">Bunga :</label>
                      <div class="controls">
                        <input type="text" class="input-small" name="bunga_elektronik" id="bunga_elektronik" value="<?php echo $bunga_elektronik;?>"> %
                      </div>
                    </div>   
               </td>
               <td>&nbsp;</td>
            </tr>
        </table>   
        </div>
        <i class="icon-search icon-chevron-right"></i> <strong>Pinjaman Sebrak :</strong>
        <div class="form-actions" style="padding:0px;margin:0px;padding-top: 10px;margin-bottom: 10px;">
        <table border="0">           
            <tr>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="sebrak">Sebrak Max :</label>
                      <div class="controls">
                        <input type="text" name="sebrak" id="sebrak" value="<?php echo $sebrak;?>">
                      </div>
                    </div>
               </td>
                <td>
                   <div class="control-group">
                      <label class="control-label" for="cicilan_sebrak">Cicilan Max :</label>
                      <div class="controls">
                        <input type="text" class="input-small" name="cicilan_sebrak" id="cicilan_sebrak" value="<?php echo $cicilan_sebrak;?>">
                      </div>
                    </div> 
                </td>
            </tr>
            <tr>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="bunga_sebrak">Bunga :</label>
                      <div class="controls">
                        <input type="text" class="input-small" name="bunga_sebrak" id="bunga_sebrak" value="<?php echo $bunga_sebrak;?>"> %
                      </div>
                    </div> 
               </td>
               <td>&nbsp;</td>
            </tr>
        </table>   
        </div>
        <div style="background:#FFF;margin-left: 0px;padding-top: 5px;">
        <button type="submit" class="btn btn-success" id="tombol" >Update</button>
        <button type="reset" class="btn">Reset</button>
        </div>
        </form>
    </div>
<script>
var $s = jQuery.noConflict();           
$s(document).ready(function(){
          
$s('#form_pinjaman').validate({
	    rules: {
	      jangka_panjang: {
                number:true,
	        required: true
	      },
	      cicilan_jangka_panjang: {
                number:true,
	        required: true
	      },
	      bunga_jangka_panjang: {
                number:true,
	        required: true
	      },
	      jangka_pendek: {
                number:true,
	        required: true
	      },
	      cicilan_jangka_pendek: {
                number:true,
	        required: true
	      },
	      bunga_jangka_pendek: {
                number:true,
	        required: true
	      },
	      elektronik: {
                number:true,
	        required: true
	      },
	      cicilan_elektronik: {
                number:true,
	        required: true
	      },
	      bunga_elektronik: {
                number:true,
	        required: true
	      },
	      sebrak: {
                number:true,
	        required: true
	      },
	      cicilan_sebrak: {
                number:true,
	        required: true
	      },
	      bunga_sebrak: {
                number:true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
                //jangka panjang
                jangka_panjang  = $s("#jangka_panjang").attr("value");
                cicilan_jangka_panjang= $s("#cicilan_jangka_panjang").attr("value");
                bunga_jangka_panjang= $s("#bunga_jangka_panjang").attr("value");
                //jangka pendek
                jangka_pendek  = $s("#jangka_pendek").attr("value");
                cicilan_jangka_pendek= $s("#cicilan_jangka_pendek").attr("value");
                bunga_jangka_pendek= $s("#bunga_jangka_pendek").attr("value");
                //elektronik
                elektronik  = $s("#elektronik").attr("value");
                cicilan_elektronik= $s("#cicilan_elektronik").attr("value");
                bunga_elektronik= $s("#bunga_elektronik").attr("value");
                //sebrak
                sebrak  = $s("#sebrak").attr("value");
                cicilan_sebrak= $s("#cicilan_sebrak").attr("value");
                bunga_sebrak= $s("#bunga_sebrak").attr("value");
                
                id_jangka_panjang="<?php echo $id_jangka_panjang;?>";
                id_cicilan_jangka_panjang="<?php echo $id_cicilan_jangka_panjang;?>";
                id_bunga_jangka_panjang="<?php echo $id_bunga_jangka_panjang;?>";
                //jangka pendek
                id_jangka_pendek="<?php echo $id_jangka_pendek;?>";
                id_cicilan_jangka_pendek="<?php echo $id_cicilan_jangka_pendek;?>";
                id_bunga_jangka_pendek="<?php echo $id_bunga_jangka_pendek;?>";
                //elektronik
                id_elektronik="<?php echo $id_elektronik;?>";
                id_cicilan_elektronik="<?php echo $id_cicilan_elektronik;?>";
                id_bunga_elektronik="<?php echo $id_bunga_elektronik;?>";
                //sebrak
                id_sebrak="<?php echo $id_sebrak;?>";
                id_cicilan_sebrak="<?php echo $id_cicilan_sebrak;?>";
                id_bunga_sebrak="<?php echo $id_bunga_sebrak;?>";
                
                if(confirm("Yakin Melakukan Perubahan ? Seluruh Sistem Akan Terpengaruh.,"))
        {
                    $s.ajax({
                        type: "GET", 
                        url: "<?php echo site_path; ?>setting/update_pinjaman.php", 
                        data: "id_jangka_panjang=" + id_jangka_panjang +"&jangka_panjang="+jangka_panjang+
                            "&id_cicilan_jangka_panjang=" + id_cicilan_jangka_panjang +"&cicilan_jangka_panjang="+cicilan_jangka_panjang+
                            "&id_bunga_jangka_panjang=" + id_bunga_jangka_panjang +"&bunga_jangka_panjang="+bunga_jangka_panjang+
                            //jangka pendek
                            "&id_jangka_pendek=" + id_jangka_pendek + "&jangka_pendek=" + jangka_pendek +
                            "&id_cicilan_jangka_pendek=" + id_cicilan_jangka_pendek + "&cicilan_jangka_pendek=" + cicilan_jangka_pendek +
                            "&id_bunga_jangka_pendek=" + id_bunga_jangka_pendek + "&bunga_jangka_pendek=" + bunga_jangka_pendek +
                            //elektronik
                            "&id_elektronik=" + id_elektronik + "&elektronik=" + elektronik +
                            "&id_cicilan_elektronik=" + id_cicilan_elektronik + "&cicilan_elektronik=" + cicilan_elektronik +
                            "&id_bunga_elektronik=" + id_bunga_elektronik + "&bunga_elektronik=" + bunga_elektronik +
                            //sebrak
                            "&id_sebrak=" + id_sebrak + "&sebrak=" + sebrak +
                            "&id_cicilan_sebrak=" + id_cicilan_sebrak + "&cicilan_sebrak=" + cicilan_sebrak +
                            "&id_bunga_sebrak=" + id_bunga_sebrak + "&bunga_sebrak=" + bunga_sebrak ,
                        complete: function(data){
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                        }
                    });
        }
                    return false;
                }
});



});	
</script>