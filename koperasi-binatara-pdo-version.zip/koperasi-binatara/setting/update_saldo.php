<?php
include '../atribut/basic.php';

$id_saldo_awal=$_GET['id_saldo_awal'];
$saldo_awal=$_GET['saldo_awal'];

$update1=$query->update("pengaturan","id_setting='".$id_saldo_awal."'",array('content',$saldo_awal));
?>
