<style type="text/css" title="currentStyle">
    @import "<?php echo site_path ?>data_tables/media/css/demo_page.css";
    @import "<?php echo site_path ?>data_tables/media/css/demo_table.css";
    @import "<?php echo site_path ?>assets/css/colorbox.css";
</style>
<script type="text/javascript" language="javascript" src="<?php echo site_path ?>data_tables/media/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path ?>assets/js/jquery.colorbox-min.js"></script>
<div class="tab-pane" id="tab8">
<a href="<?php echo site_path ?>setting/form_carousel.php" id="input_carousel" class="btn btn-success"><i class="icon-plus icon-white"></i> Tambah Slideshow</a> <br/><br/> 
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
			<th>Gambar</th>
			<th>Keterangan</th>
                        <th>Urutan</th>
                        <th>Pilihan</th>
		</tr>
	</thead>

</table>
<script>
$s(document).ready(function() {
    var oTable = $j('#example').dataTable( {
        "bFilter":false,
        "bLengthChange": false,
            "bProcessing": true,
            "bServerSide": true,
            "bAutoWidth": false,
            "bDestory": true,
            "sAjaxSource": "<?php echo site_path ?>setting/carousel_json.php",
            "sPaginationType": "full_numbers",
            "aoColumns": [ 
                {"sClass": "center"},
                {"sClass": "left"},
                {"sClass": "center"},
                {"sClass": "center"}
            ]
    });
    $s("#input_carousel").colorbox({iframe:true, fixed:true,width:700, height:400, onClosed:function(){oTable.fnDraw(false);}});  
    function iframe(target){$s(target).colorbox({iframe:true, fixed:true,width:700, height:400, onClosed:function(){oTable.fnDraw(false);}});}
    $s('#edit_carousel').live('click',function(e){
        e.preventDefault();
        iframe(this);
    });
    $s('#delete_carousel').live('click',function(){
        if(confirm('Yakin menghapus data ini ?')){
               $.ajax({
                url   :"<?php echo site_path;?>setting/delete_carousel.php",
                type  :'POST',
                data  : {id_img:$s(this).attr('kd')},
                success: function(){
                    oTable.fnDraw(false);
                }
             });
             }
             return false;      
    });
});
</script>
</div>