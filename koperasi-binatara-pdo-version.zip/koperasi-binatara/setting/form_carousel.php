<?php session_start();?>
<?php include '../atribut/basic.php'; ?>
<?php include '../login/session.php'; ?>
<?php include '../call_bootstrap.php'; ?>


<html>
    <head>
        <link href='<?php echo site_path ?>atribut/images/simbol.png' rel='shortcut icon' type='image/x-icon'/>
        <title>Binatara</title>
        <script>
        function logout(){
            if(confirm("Anda Yakin ingin Keluar ?")){
                return true;
            }else{
                return false;
            }
        }
        </script>
        <style>
        label.valid {
        width: 24px;
        height: 24px;
        background: url("<?php echo site_path ?>bootstrap/img/valid.png") center center no-repeat;
        display: inline-block;
        text-indent: -9999px;
            }
        label.error {
        color: red;
        padding: 0px;
        margin: 0px;
        }
        </style>
</head>
<body>
<?php

function make_thumb($src, $dest, $desired_width) {

	/* read the source image */
	$source_image = imagecreatefromjpeg($src);
	$width = imagesx($source_image);
	$height = imagesy($source_image);
	
	/* find the "desired height" of this thumbnail, relative to the desired width  */
	$desired_height = floor($height * ($desired_width / $width));
	
	/* create a new, "virtual" image */
	$virtual_image = imagecreatetruecolor($desired_width, $desired_height);
	
	/* copy source image at a resized size */
	imagecopyresampled($virtual_image, $source_image, 0, 0, 0, 0, $desired_width, $desired_height, $width, $height);
	
	/* create the physical thumbnail image to its destination */
	imagejpeg($virtual_image, $dest);
}


    if(isset($_POST['tombol'])){
        //UPDATE
                 if(!empty($_POST['id_img'])){
                    if($_FILES["file"]["error"] > 0){

                        $update=  $query->update("carousel","id_img='".$_POST['id_img']."'",array("ket",$_POST['ket'],"order_id",$_POST['urutan']));

                        echo  '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button><h4>Data telah diperbaharui !</h4></div>';
                    }else{

                        $edit=$query->read("carousel","where id_img='".$_POST['id_img']."'","img");
                        $row_img = $edit[0]['img'];
                        
                        if(move_uploaded_file($_FILES["file"]["tmp_name"],"../img/" . $_FILES["file"]["name"])){
                            make_thumb('../img/'.$_FILES["file"]["name"], '../img/'.$_FILES["file"]["name"], 500);
                            make_thumb('../img/'.$_FILES["file"]["name"], '../img/thumb/'.$_FILES["file"]["name"], 100);

                            $sql=  $query->update("carousel","id_img='".$_POST['id_img']."'",array("img",$_FILES["file"]["name"],"ket",$_POST['ket'],"order_id",$_POST['urutan']));


                            if($sql){
                                @unlink('../img/'.$row_img);
                                @unlink('../img/thumb/'.$row_img);
                                 echo  '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button><h4>Data telah diperbaharui !</h4></div>';
                            }
                        }
                    }
                 

                 //tambah baru   
                } else{      
                    if ($_FILES["file"]["type"] == "image/jpeg" || $_FILES["file"]["type"] == "image/jpg" && ($_FILES["file"]["size"] < 20000) )
                      {
                      if ($_FILES["file"]["error"] > 0)
                        {
                        echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>
                                <h4>Upload Failed !</h4>
                              Upload Failed: ' . $_FILES["file"]["error"].'</div>' ;
                        }
                      elseif (file_exists("../img/" . $_FILES["file"]["name"]))
                          {
                            echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <h4>Upload Failed !</h4>
                                  File sudah ada</div>' ;
                            }
                        else
                          {
                                if(move_uploaded_file($_FILES["file"]["tmp_name"],"../img/" . $_FILES["file"]["name"])){
                                    make_thumb('../img/'.$_FILES["file"]["name"], '../img/'.$_FILES["file"]["name"], 500);
                                    make_thumb('../img/'.$_FILES["file"]["name"], '../img/thumb/'.$_FILES["file"]["name"], 100);
                                    $sql=  $query->create("carousel",array(null,$_FILES["file"]["name"],$_POST['ket'],$_POST['urutan']));
                                    if($sql){
                                         echo  '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button><h4>Upload Complete !</h4></div>';
                                    }
                                }

                          }
                      }
                    else
                      {
                      echo  '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>
                                <h4>Invalid File !</h4></div>';
                      }
                }
    }
    
 if(isset($_GET['kd'])){
    $id=$_GET['kd'];

    $edit=$query->read("carousel","where id_img='".$id."'");
    foreach ($edit as $row) {
        $id_img=$_GET['kd'];
        $img=$row['img'];
        $ket=$row['ket'];
        $urutan=$row['order_id'];
      }
}else{
    $id_img='';
    $img='';
    $ket='';
    $urutan='';
}


?>
<div class="container">
<form action="#" method="post" id="form_carousel" class="form-horizontal" enctype="multipart/form-data">
    <legend>Form Slideshow</legend>
    <div class="form-actions" style="padding:0px;margin:0px;padding-top: 10px;margin-bottom: 10px;">
        <?php if(!empty($img)){ ?>
                <div class="control-group">
                  <label class="control-label">Gambar Sebelum :</label>
                  <div class="controls">
                    <img src="../img/thumb/<?php echo $img; ?>">
                  </div>
                </div>          
        <?php } ?>
                <div class="control-group">
                  <label class="control-label" for="file">Image (500 x 300) :</label>
                  <div class="controls">
                    <input type="hidden" name="id_img" value="<?php echo $id_img; ?>">  
                    <input type="file" name="file" id="file" >
                  </div>
                </div>

                <div class="control-group">
                  <label class="control-label" for="simpanan_wajib">Keterangan :</label>
                  <div class="controls">
                    <textarea name="ket" id="ket"><?php echo $ket; ?></textarea>
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label" for="urutan">Urutan :</label>
                  <div class="controls">
                    <input type="text" name="urutan" id="urutan" value="<?php echo $urutan;?>">
                  </div>
                </div>        

    </div>
    <div style="background:#FFF;margin-left: 0px;padding-top: 5px;">
    <button type="submit" class="btn btn-success" name="tombol" >Save</button>
    <button type="reset" class="btn">Reset</button>
    </div>
</form>
</div>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>assets/js/jquery-1.7.1.min.js"></script>
<script src="<?php echo site_path; ?>bootstrap/js/validate/jquery.validate.min.js"></script>
<script>
    var $j = jQuery.noConflict();
    $j('#form_carousel').validate({
        rules: {file: {urutan: {required: true
    },number:true}},
	    highlight: function(label) {$(label).closest('.control-group').addClass('error');},
	    success: function(label) {label.text('OK!').addClass('valid').closest('.control-group').addClass('success');},
    });
</script>
</body>
</html>