-- phpMyAdmin SQL Dump
-- version 4.4.15.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 25, 2016 at 12:20 PM
-- Server version: 5.6.28
-- PHP Version: 5.5.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `koperasi_simpan_pinjam`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_user` int(11) NOT NULL,
  `username` varchar(35) NOT NULL,
  `password` varchar(35) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_user`, `username`, `password`) VALUES
(1, 'wahyu', '32c9e71e866ecdbc93e497482aa6779f');

-- --------------------------------------------------------

--
-- Table structure for table `aktiva_tetap`
--

CREATE TABLE IF NOT EXISTS `aktiva_tetap` (
  `kd_aktiva` int(11) NOT NULL,
  `kd_jenis` int(11) NOT NULL,
  `nm_aktiva` varchar(255) NOT NULL,
  `tgl_perolehan` date NOT NULL,
  `hrg_perolehan` int(11) NOT NULL,
  `umur_ekonomis` int(11) NOT NULL,
  `residu` int(11) NOT NULL,
  `kd_transaksi` char(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `anggota`
--

CREATE TABLE IF NOT EXISTS `anggota` (
  `id_anggota` int(11) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `jk` char(1) NOT NULL DEFAULT 'L',
  `tgl_daftar` date NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `no_telp` char(12) NOT NULL,
  `simpanan_pokok` int(11) NOT NULL,
  `kd_transaksi` char(8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `angsuran_elektronik`
--

CREATE TABLE IF NOT EXISTS `angsuran_elektronik` (
  `kd_angsuran` int(11) NOT NULL,
  `kd_elektronik` int(11) NOT NULL,
  `tgl_angsuran` date NOT NULL,
  `besar_angsuran` int(11) NOT NULL,
  `bunga` int(11) NOT NULL,
  `kd_transaksi` char(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `angsuran_jangka_panjang`
--

CREATE TABLE IF NOT EXISTS `angsuran_jangka_panjang` (
  `kd_angsuran` int(11) NOT NULL,
  `kd_panjang` int(11) NOT NULL,
  `tgl_angsuran` date NOT NULL,
  `besar_angsuran` int(11) NOT NULL,
  `bunga` int(11) NOT NULL,
  `kd_transaksi` char(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `angsuran_jangka_pendek`
--

CREATE TABLE IF NOT EXISTS `angsuran_jangka_pendek` (
  `kd_angsuran` int(11) NOT NULL,
  `kd_pendek` int(11) NOT NULL,
  `tgl_angsuran` date NOT NULL,
  `besar_angsuran` int(11) NOT NULL,
  `bunga` int(11) NOT NULL DEFAULT '0',
  `kd_transaksi` char(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `angsuran_sebrak`
--

CREATE TABLE IF NOT EXISTS `angsuran_sebrak` (
  `kd_angsuran` int(11) NOT NULL,
  `kd_sebrak` int(11) NOT NULL,
  `tgl_angsuran` date NOT NULL,
  `besar_angsuran` int(11) NOT NULL,
  `bunga` int(11) NOT NULL,
  `kd_transaksi` char(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `carousel`
--

CREATE TABLE IF NOT EXISTS `carousel` (
  `id_img` int(11) NOT NULL,
  `img` text NOT NULL,
  `ket` text NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carousel`
--

INSERT INTO `carousel` (`id_img`, `img`, `ket`, `order_id`) VALUES
(1, 'Desert.jpg', 'biji', 10),
(2, 'Chrysanthemum.jpg', 'awawa', 3),
(5, 'Penguins.jpg', 'pinguin', 3);

-- --------------------------------------------------------

--
-- Table structure for table `jenis_aktiva`
--

CREATE TABLE IF NOT EXISTS `jenis_aktiva` (
  `kd_jenis` int(11) NOT NULL,
  `jenis` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_aktiva`
--

INSERT INTO `jenis_aktiva` (`kd_jenis`, `jenis`) VALUES
(1, 'Mesin'),
(2, 'Bangunan'),
(3, 'Inventaris'),
(4, 'Tanah / Hak Atas Tanah');

-- --------------------------------------------------------

--
-- Table structure for table `jurnal_umum`
--

CREATE TABLE IF NOT EXISTS `jurnal_umum` (
  `id_jurnal` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `ket` varchar(255) NOT NULL,
  `debit` int(11) DEFAULT NULL,
  `kredit` int(11) DEFAULT NULL,
  `kd_transaksi` char(8) NOT NULL,
  `kd_panjang` int(11) NOT NULL DEFAULT '0',
  `kd_pendek` int(11) NOT NULL DEFAULT '0',
  `kd_elektronik` int(11) NOT NULL DEFAULT '0',
  `kd_sebrak` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `neraca_pembanding`
--

CREATE TABLE IF NOT EXISTS `neraca_pembanding` (
  `id` int(11) NOT NULL,
  `fungsi` varchar(255) NOT NULL,
  `content` varchar(255) DEFAULT '0',
  `content_pembanding` varchar(255) DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `neraca_pembanding`
--

INSERT INTO `neraca_pembanding` (`id`, `fungsi`, `content`, `content_pembanding`) VALUES
(1, 'tanggal', '', '1996'),
(2, 'kas dan bank', '', '5050000'),
(3, 'investasi jangka pendek', '500000', '0'),
(4, 'piutang usaha', '0', '0'),
(5, 'piutang pinjaman anggota', '', '3200000'),
(6, 'piutang pinjaman non anggota', '2300000', '0'),
(7, 'piutang lain-lain', '0', '0'),
(8, 'peny. piutang gtak tertagih', '0', '0'),
(9, 'persediaan', '0', '0'),
(10, 'pendapatan akan diterima', '0', '0'),
(11, 'penyertaan pada koperasi', '0', '100000'),
(12, 'penyertaan pada non koperasi', '0', '100000'),
(13, 'hak atas tanah', '', '0'),
(14, 'bangunan', '', '0'),
(15, 'mesin', '', '3400000'),
(16, 'inventaris', '', '500000'),
(17, 'akumulasi penyusutan', '', '200000'),
(18, 'aktiva dalam konstruksi', '0', '0'),
(19, 'beban ditangguhkan', '0', '0'),
(20, 'hutang usaha', '0', '2000000'),
(21, 'hutang bank', '0', '0'),
(22, 'hutang pajak', '0', '0'),
(23, 'hutang simpanan anggota', '', '5000000'),
(24, 'hutang dana bgaian shu', '0', '0'),
(25, 'hutang kangka panjang jatuh tempo', '0', '0'),
(26, 'biaya harus dibayar', '0', '0'),
(27, 'hutang bank panjang', '4500000', '0'),
(28, 'hutang jangka panjang lainnya', '0', '0'),
(29, 'simpanan wajib', '', '4000000'),
(30, 'simpanan pokok', '', '800000'),
(31, 'modal penyetaraan partisipasi anggota', '0', '750000'),
(32, 'modal penyertaan', '1200000', '0'),
(33, 'modal sumbangan', '0', '0'),
(34, 'cadangan', '0', '0'),
(35, 'shu belum dibagi', '0', '0'),
(36, 'JUMLAH AKTIVA LANCAR', '', '8250000'),
(37, 'JUMLAH INVESTASI JANGKA PANJANG', '', '200000'),
(38, 'JUMLAH AKTIVA TETAP', '', '4100000'),
(39, 'JUMLAH AKTIVA LAIN-LAIN', '', '0'),
(40, 'JUMLAH AKTIVA', '', '12550000'),
(41, 'JUMLAH KEWAJIBAN JANGKA PENDEK', '', '7000000'),
(42, 'JUMLAH KEWAJIBAN JANGKA PANJANG', '', '0'),
(43, 'JUMLAH EKUITAS', '', '5550000'),
(44, 'JUMLAH KEWAJIBAN DAN EKUITAS', '', '12550000');

-- --------------------------------------------------------

--
-- Table structure for table `pengaturan`
--

CREATE TABLE IF NOT EXISTS `pengaturan` (
  `id_setting` int(11) NOT NULL,
  `fungsi` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengaturan`
--

INSERT INTO `pengaturan` (`id_setting`, `fungsi`, `content`) VALUES
(0, '', ''),
(1, 'Simpanan Pokok', '100000'),
(2, 'Simpanan Wajib', '10000'),
(3, 'Jangka Panjang', '10000000'),
(4, 'Cicilan Jangka Panjang', '48'),
(5, 'Bunga Jangka Panjang', '1.15'),
(6, 'Jangka Pendek ', '2500000'),
(7, 'Cicilan Jangka Pendek', '10'),
(8, 'Bunga Jangka Pendek', '1.5'),
(9, 'Elektronik', '1000000'),
(10, 'Cicilan Elektronik', '10'),
(11, 'Bunga Elektronik', '1.5'),
(12, 'Sebrak', '500000'),
(13, 'Cicilan Sebrak', '1'),
(14, 'Bunga Sebrak', '1.5'),
(15, 'saldo awal', '1000000'),
(16, 'tarif_pajak', '26'),
(17, 'cicilan hutang jangka pendek', '12');

-- --------------------------------------------------------

--
-- Table structure for table `p_elektronik`
--

CREATE TABLE IF NOT EXISTS `p_elektronik` (
  `kd_elektronik` int(11) NOT NULL,
  `id_anggota` int(11) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `cicilan` int(11) NOT NULL,
  `besar_pinjaman` int(11) NOT NULL,
  `kd_transaksi` char(8) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `p_jangka_panjang`
--

CREATE TABLE IF NOT EXISTS `p_jangka_panjang` (
  `kd_panjang` int(11) NOT NULL,
  `id_anggota` int(11) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `cicilan` int(11) NOT NULL,
  `besar_pinjaman` int(11) NOT NULL,
  `kd_transaksi` char(8) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `p_jangka_pendek`
--

CREATE TABLE IF NOT EXISTS `p_jangka_pendek` (
  `kd_pendek` int(11) NOT NULL,
  `id_anggota` int(11) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `cicilan` int(11) NOT NULL,
  `besar_pinjaman` int(11) NOT NULL,
  `kd_transaksi` char(8) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `p_sebrak`
--

CREATE TABLE IF NOT EXISTS `p_sebrak` (
  `kd_sebrak` int(11) NOT NULL,
  `id_anggota` int(11) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `cicilan` int(11) NOT NULL,
  `besar_pinjaman` int(11) NOT NULL,
  `kd_transaksi` char(8) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `shu_pembanding`
--

CREATE TABLE IF NOT EXISTS `shu_pembanding` (
  `id` int(11) NOT NULL,
  `fungsi` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `content_pembanding` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shu_pembanding`
--

INSERT INTO `shu_pembanding` (`id`, `fungsi`, `content`, `content_pembanding`) VALUES
(1, 'tanggal', '', '1996'),
(2, 'bruto anggota', '', '3500000'),
(3, 'beban pokok', '', '23000'),
(4, 'Penjualan', '35700001', '3450000'),
(5, 'Harga Pokok', '5000001', '3000000'),
(6, 'beban usaha', '100001', '20000'),
(7, 'beban perkoperasian', '2000001', '15000'),
(8, 'pendapatan dan beban lain0lain', '300001', '120000'),
(9, 'pendapatan dan beban luar biasa', '1', '22222'),
(10, 'shu sebelum pajak', '-2000001', '35000'),
(11, 'Laba Rugi kotor', '-200000', '3477000'),
(12, 'Netto Anggota', '', '3477000'),
(13, 'sisa hasil usaha kotor', '', '7404000'),
(14, 'sisa hasil usaha  koperasi', '', '7384000'),
(15, 'shu setelah perkoperasian', '', '7369000'),
(16, 'shu sebelum pos2 luar biasa', '', '7249000'),
(17, 'pajak penghasilan', '', '7226778'),
(18, 'shu setelah pajak', '', '7191778');

-- --------------------------------------------------------

--
-- Table structure for table `simpanan_sukarela`
--

CREATE TABLE IF NOT EXISTS `simpanan_sukarela` (
  `kd_sukarela` int(11) NOT NULL,
  `id_anggota` int(11) NOT NULL,
  `tgl_byr` date NOT NULL,
  `besar_simpanan` int(11) NOT NULL,
  `kd_transaksi` char(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `simpanan_wajib`
--

CREATE TABLE IF NOT EXISTS `simpanan_wajib` (
  `kd_wajib` int(11) NOT NULL,
  `id_anggota` int(11) NOT NULL,
  `tgl_byr` date NOT NULL,
  `besar_simpanan` int(11) NOT NULL,
  `kd_transaksi` char(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `aktiva_tetap`
--
ALTER TABLE `aktiva_tetap`
  ADD PRIMARY KEY (`kd_aktiva`),
  ADD KEY `kd_jenis` (`kd_jenis`);

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id_anggota`);

--
-- Indexes for table `angsuran_elektronik`
--
ALTER TABLE `angsuran_elektronik`
  ADD PRIMARY KEY (`kd_angsuran`),
  ADD KEY `kd_elektronik` (`kd_elektronik`);

--
-- Indexes for table `angsuran_jangka_panjang`
--
ALTER TABLE `angsuran_jangka_panjang`
  ADD PRIMARY KEY (`kd_angsuran`),
  ADD KEY `kd_panjang` (`kd_panjang`);

--
-- Indexes for table `angsuran_jangka_pendek`
--
ALTER TABLE `angsuran_jangka_pendek`
  ADD PRIMARY KEY (`kd_angsuran`),
  ADD KEY `kd_pendek` (`kd_pendek`);

--
-- Indexes for table `angsuran_sebrak`
--
ALTER TABLE `angsuran_sebrak`
  ADD PRIMARY KEY (`kd_angsuran`),
  ADD KEY `kd_sebrak` (`kd_sebrak`);

--
-- Indexes for table `carousel`
--
ALTER TABLE `carousel`
  ADD PRIMARY KEY (`id_img`);

--
-- Indexes for table `jenis_aktiva`
--
ALTER TABLE `jenis_aktiva`
  ADD PRIMARY KEY (`kd_jenis`);

--
-- Indexes for table `jurnal_umum`
--
ALTER TABLE `jurnal_umum`
  ADD PRIMARY KEY (`id_jurnal`);

--
-- Indexes for table `neraca_pembanding`
--
ALTER TABLE `neraca_pembanding`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengaturan`
--
ALTER TABLE `pengaturan`
  ADD PRIMARY KEY (`id_setting`);

--
-- Indexes for table `p_elektronik`
--
ALTER TABLE `p_elektronik`
  ADD PRIMARY KEY (`kd_elektronik`);

--
-- Indexes for table `p_jangka_panjang`
--
ALTER TABLE `p_jangka_panjang`
  ADD PRIMARY KEY (`kd_panjang`);

--
-- Indexes for table `p_jangka_pendek`
--
ALTER TABLE `p_jangka_pendek`
  ADD PRIMARY KEY (`kd_pendek`);

--
-- Indexes for table `p_sebrak`
--
ALTER TABLE `p_sebrak`
  ADD PRIMARY KEY (`kd_sebrak`);

--
-- Indexes for table `shu_pembanding`
--
ALTER TABLE `shu_pembanding`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `simpanan_sukarela`
--
ALTER TABLE `simpanan_sukarela`
  ADD PRIMARY KEY (`kd_sukarela`);

--
-- Indexes for table `simpanan_wajib`
--
ALTER TABLE `simpanan_wajib`
  ADD PRIMARY KEY (`kd_wajib`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `aktiva_tetap`
--
ALTER TABLE `aktiva_tetap`
  MODIFY `kd_aktiva` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `anggota`
--
ALTER TABLE `anggota`
  MODIFY `id_anggota` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `angsuran_elektronik`
--
ALTER TABLE `angsuran_elektronik`
  MODIFY `kd_angsuran` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `angsuran_jangka_panjang`
--
ALTER TABLE `angsuran_jangka_panjang`
  MODIFY `kd_angsuran` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `angsuran_jangka_pendek`
--
ALTER TABLE `angsuran_jangka_pendek`
  MODIFY `kd_angsuran` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `angsuran_sebrak`
--
ALTER TABLE `angsuran_sebrak`
  MODIFY `kd_angsuran` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `carousel`
--
ALTER TABLE `carousel`
  MODIFY `id_img` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `jenis_aktiva`
--
ALTER TABLE `jenis_aktiva`
  MODIFY `kd_jenis` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `jurnal_umum`
--
ALTER TABLE `jurnal_umum`
  MODIFY `id_jurnal` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `neraca_pembanding`
--
ALTER TABLE `neraca_pembanding`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `p_elektronik`
--
ALTER TABLE `p_elektronik`
  MODIFY `kd_elektronik` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `p_jangka_panjang`
--
ALTER TABLE `p_jangka_panjang`
  MODIFY `kd_panjang` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `p_jangka_pendek`
--
ALTER TABLE `p_jangka_pendek`
  MODIFY `kd_pendek` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `p_sebrak`
--
ALTER TABLE `p_sebrak`
  MODIFY `kd_sebrak` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `shu_pembanding`
--
ALTER TABLE `shu_pembanding`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `simpanan_sukarela`
--
ALTER TABLE `simpanan_sukarela`
  MODIFY `kd_sukarela` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `simpanan_wajib`
--
ALTER TABLE `simpanan_wajib`
  MODIFY `kd_wajib` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `aktiva_tetap`
--
ALTER TABLE `aktiva_tetap`
  ADD CONSTRAINT `aktiva_tetap_ibfk_1` FOREIGN KEY (`kd_jenis`) REFERENCES `jenis_aktiva` (`kd_jenis`);

--
-- Constraints for table `angsuran_elektronik`
--
ALTER TABLE `angsuran_elektronik`
  ADD CONSTRAINT `angsuran_elektronik_ibfk_1` FOREIGN KEY (`kd_elektronik`) REFERENCES `p_elektronik` (`kd_elektronik`);

--
-- Constraints for table `angsuran_jangka_panjang`
--
ALTER TABLE `angsuran_jangka_panjang`
  ADD CONSTRAINT `angsuran_jangka_panjang_ibfk_1` FOREIGN KEY (`kd_panjang`) REFERENCES `p_jangka_panjang` (`kd_panjang`);

--
-- Constraints for table `angsuran_sebrak`
--
ALTER TABLE `angsuran_sebrak`
  ADD CONSTRAINT `angsuran_sebrak_ibfk_1` FOREIGN KEY (`kd_sebrak`) REFERENCES `p_sebrak` (`kd_sebrak`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
