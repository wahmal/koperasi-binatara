<?php

	$kode=$query->read('jurnal_umum',"where kd_transaksi like 'A%' ORDER BY kd_transaksi DESC");
	if (empty($kode)) {
		$kd_transaksi= "A0000001";
	} else {
		$kd_transaksi=$kode[0]['kd_transaksi'];
		$kd_transaksi=substr($kd_transaksi,2,8);
		$kd_transaksi=$kd_transaksi + 10000001;
		$kd_transaksi=substr($kd_transaksi,1,8);
		$kd_transaksi="A".$kd_transaksi;
	}
       // echo $kd_transaksi;
?>