<?php

	$row=$query->random("select kd_transaksi from jurnal_umum where kd_transaksi like 'B%' ORDER bY kd_transaksi desc",true);
	if (empty($row)) {
		$kd_transaksi= "B0000001";
	} else {
		$kd_transaksi=$row[0]['kd_transaksi'];
		$kd_transaksi=substr($kd_transaksi,2,8);
		$kd_transaksi=$kd_transaksi + 10000001;
		$kd_transaksi=substr($kd_transaksi,1,8);
		$kd_transaksi="B".$kd_transaksi;
	}
        echo $kd_transaksi;
?>