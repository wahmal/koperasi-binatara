<?php
class Basic{

public function __construct(){
  $this->db = new PDO('mysql:host=localhost;dbname=koperasi_binatara','root','1234');
}

//random
function random($query,$result=false,$type='array') {
  
  $query = $this->db->query($sql);
  if($result){
    $arrResult=array();
    if(!empty($query)){
      if($type=='array'){
        while($data = $query->fetch(PDO::FETCH_ASSOC)){
            array_push($arrResult, $data);
        }
      }
      if($type=='obj'){
        while($data = $query->fetch(PDO::FETCH_OBJ)){
            array_push($arrResult, $data);
        }
      }
    }
    return $arrResult;
  }else{
    if($query){
      return true;
    }else{
      return false;
    }
  }
}

//read
function read($table, $where = "", $fieldName = "",$type="array") {
  $arrResult = array();
  $fieldStr = "";
  if (empty($fieldName) ) {
    $fieldStr = "*  ";
  }
  elseif (is_array($fieldName) ){
    foreach ($fieldName as $field) {
      $fieldStr .= $field.", ";
    }
  }
  else {  
      $fieldStr .= $fieldName.", ";
  }
  $fields = substr($fieldStr, 0, -2);

//echo
  $sql = "SELECT ".$fields." FROM ".$table." ".$where;
  //echo $sql.'<br>';
  $query = $this->db->query($sql);


 // if(!empty($query)){
    if($type=='array'){
      while($data = $query->fetch(PDO::FETCH_ASSOC)){
          array_push($arrResult, $data);
      }
    }
    if($type=='obj'){
      while($data = $query->fetch(PDO::FETCH_OBJ)){
          array_push($arrResult, $data);
      }
    }
 // }
  return $arrResult;
}

//create
function create($table, $data) {
  $values = "";
  if (is_array($data) ){
    for ($i = 0; $i < count($data); $i++){
      $values .= "'". $data[$i] ."', ";
    }
  }
  else {
    $numargs = func_num_args();
    for ($i = 1; $i < $numargs; $i++){
      $values .= "'". func_get_arg($i) ."', ";
    }
  }
  $values = substr($values, 0, -2);
  $sql  = "INSERT INTO `". $table ."` VALUES (".$values.")";  
  $query = $this->db->query($sql);
  if(!$query){
    return false;
  }else{
    return true;
  }
}

//update
function update($table, $where, $data) {
  $set = "";
  if (is_array($data)){
    for ($i=0; $i<count($data); $i=$i+2){
      $j=$i+1;
      $set  .= "`".$data[$i]."`='". $data[$j] ."', ";
    }
  }
  else {  
    $numargs= (func_num_args()-1);
    for ($i=2; $i<$numargs; $i = $i+2){
      $j=$i+1;
      $set  .= "`".func_get_arg($i)."`='". func_get_arg($j) ."', ";
    }
  }
  $set  = substr($set, 0, -2);
  $sql  = "UPDATE `$table` SET $set WHERE $where";

  $query = $this->db->query($sql); 
  if(!$query){
    return false;
  }else{
    return true;
  }
}

//delete
function delete($table, $id_name, $data){
  //echo $data."<BR>";
  if (is_array($data)){
    if(count($data)==1){
      $data="'".$data[0]."'";
    }else{
      $data=implode("','", $data);
    }
  }else{
    $data="'".$data."'";
  }

  $sql = "DELETE FROM `$table` 
          WHERE `$id_name` IN (". $data .")";
         // echo $sql.'<br>';
  $query = $this->db->query($sql);
  if(!$query){
    return false;
  }else{
    return true;
  }
}

}


$query = new Basic();

//config
date_default_timezone_set('Asia/Makassar');

define('site_path', "http://localhost/koperasi_binatara/"); 

?>