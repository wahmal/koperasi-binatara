<?php
$conn=array('host'		=> 'localhost',
'database'	=> 'koperasi_binatara',
'user'		=> 'root',
'passwd'		=> '1234');

define('site_path', "http://localhost/koperasi_binatara/"); 
?>