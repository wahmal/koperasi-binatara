<?php

	$query_kode=mysql_query("SELECT kd_transaksi FROM jurnal_umum where kd_transaksi like 'J%' order by kd_transaksi DESC") or die (mysql_error());
	$cek=mysql_num_rows($query_kode);
	$row=mysql_fetch_array($query_kode);
	if (empty($cek)) {
		$kd_transaksi= "J0000001";
	} else {
		$kd_transaksi=$row['kd_transaksi'];
		$kd_transaksi=substr($kd_transaksi,2,8);
		$kd_transaksi=$kd_transaksi + 10000001;
		$kd_transaksi=substr($kd_transaksi,1,8);
		$kd_transaksi="J".$kd_transaksi;
	}
?>