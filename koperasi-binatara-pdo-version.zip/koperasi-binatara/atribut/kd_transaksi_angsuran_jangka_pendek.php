<?php

	$row_kode=$query->read("jurnal_umum","where kd_transaksi like 'H%' order by kd_transaksi DESC","kd_transaksi");
	if (empty($row)) {
		$kd_transaksi= "H0000001";
	} else {
		$kd_transaksi=$row[0]['kd_transaksi'];
		$kd_transaksi=substr($kd_transaksi,2,8);
		$kd_transaksi=$kd_transaksi + 10000001;
		$kd_transaksi=substr($kd_transaksi,1,8);
		$kd_transaksi="H".$kd_transaksi;
	}
?>