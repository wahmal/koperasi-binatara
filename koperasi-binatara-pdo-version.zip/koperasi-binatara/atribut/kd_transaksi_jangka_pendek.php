<?php

	$query_kode=$query->read("jurnal_umum","where kd_transaksi like 'D%' ORDER BY kd_transaksi DESC","kd_transaksi");
	$row=$query_kode[0];
	if (empty($row)) {
		$kd_transaksi= "D0000001";
	} else {
		$kd_transaksi=$row['kd_transaksi'];
		$kd_transaksi=substr($kd_transaksi,2,8);
		$kd_transaksi=$kd_transaksi + 10000001;
		$kd_transaksi=substr($kd_transaksi,1,8);
		$kd_transaksi="D".$kd_transaksi;
	}
      //  echo $kd_transaksi;
?>