<?php
include'../atribut/basic.php';
$explode=explode('&',$_GET['id']);
$id_anggota=$explode[0];

//cek iuran
$wajib=  $query->random("select date_add(tgl_byr, interval 1 month) as month from simpanan_wajib where id_anggota='".$id_anggota."'",true,'obj');
if(!empty($wajib)){
    foreach($wajib as $data){
        $month=$data->month;
    }
    $nama_anggota=  $query->read("anggota","where id_anggota='".$id_anggota."'",'nama','obj' );
     foreach($nama_anggota as $data){
         $nama=$data->nama;
     }
    
}else{
   
    $anggota=  $query->read("anggota","where id_anggota='".$id_anggota."'","nama, date_add(tgl_daftar, interval 1 month) as month",'obj');
        foreach($anggota as $data){
             $month=$data->month;
             $nama=$data->nama;
        }
}

  

 function compare_two_date($date_1,$date_2) {
    if ($date_2 > $date_1) {
    return false;
    } else {
    return true;
    }
 }
 
$data=explode('-',$month);
$data[1]=$data[1]+1;
$month=  implode('-', $data);
$now=date('Y-m-d');
$banding=  compare_two_date($month, $now);
if($banding==TRUE){
    $class='ok'; $selisih='';
}else{
    $class='fail'; 
    $selisih=date_diff(date_create($now),date_create($month));
    $selisih=$selisih->format('%R%a Hari');
}
$paket=array('nama'=>$nama,'tanggal'=>$month,'status'=>$class,'selisih'=>$selisih);
die(json_encode($paket));
?>
