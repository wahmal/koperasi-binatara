
<?php 
include '../atribut/basic.php';
include '../atribut/kd_transaksi_simpan_wajib.php';

$id_anggota=$_GET['id_anggota'];
$tgl=$_GET['tgl'];
$byr=$_GET['byr'];

if($query->create("simpanan_wajib",array(null,$id_anggota,$tgl,$byr,$kd_transaksi))){
	$query->create("jurnal_umum",array(null,$tgl,'Kas',$byr,null,$kd_transaksi,'','','',''));
	$query->create("jurnal_umum",array(null,$tgl,'Simpanan Wajib',null,$byr,$kd_transaksi,'','','',''));
}

?>
