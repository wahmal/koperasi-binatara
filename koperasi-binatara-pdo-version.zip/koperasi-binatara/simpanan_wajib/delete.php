<?php
$id=$_GET['id'];
include '../atribut/basic.php';

$row=$query->read("simpanan_wajib","where kd_wajib='".$id."'",'','obj');
$kd_transaksi=$row[0]->kd_transaksi;

echo $kd_transaksi;

if($query->delete("jurnal_umum","kd_transaksi",array($kd_transaksi))){
	$query->delete("simpanan_wajib","kd_wajib",array($id));
}

?>