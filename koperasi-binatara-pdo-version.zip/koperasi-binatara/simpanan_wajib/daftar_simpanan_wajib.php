<style type="text/css" title="currentStyle">
    @import "<?php echo site_path ?>data_tables/media/css/demo_page.css";
    @import "<?php echo site_path ?>data_tables/media/css/demo_table.css";
    @import "<?php echo site_path ?>data_tables/table_tools/media/css/TableTools.css";
</style>
<script type="text/javascript" language="javascript" src="<?php echo site_path ?>data_tables/media/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path ?>data_tables/table_tools/media/js/TableTools.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path ?>data_tables/table_tools/media/js/TableTools.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path ?>data_tables/table_tools/media/js/ZeroClipboard.js"></script>

<script type="text/javascript" charset="utf-8">
    var $j = jQuery.noConflict();
    $j(document).ready(function() {
            var oTable = $j('#example').dataTable( {
                    
                    "bProcessing": true,
                    "bServerSide": true,
                    "bAutoWidth": false,
                    "bDestroy" : true,
                    "bSort": true,
                    "sScrollX": "100%",
                    "sScrollXInner": "100%",
                    "bScrollCollapse": false,
                    "sAjaxSource": "<?php echo site_path ?>simpanan_wajib/daftar_simpanan_wajib_json.php",
                    "sPaginationType": "full_numbers",
                    "aoColumns": [ 
                        {"sClass": "center"},
                        {"sClass": "left"},
                        {"sClass": "center"},
                        {"sClass": "right"}
                    ],
                    "sDom": 'T<"clear"><"H"lfr>t<"F"ip>',
                    "oTableTools": {
			"sSwfPath": "<?php echo site_path ?>data_tables/table_tools/media/swf/copy_csv_xls_pdf.swf",
                        "aButtons": [
				"xls",
				{
					"sExtends": "pdf",
					"sPdfOrientation": "landscape",
					"sPdfMessage": "Daftar Simpanan Wajib"
				},
				"print" ]
                    }
     
            } );
            } );
</script>
<legend>Daftar Simpanan Wajib</legend>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
                        <th>Kd Anggota</th>
			<th>Nama</th>
			<th>Tanggal Bayar</th>
                        <th>Simpanan_Wajib</th>
		</tr>
	</thead>
        <?php
        $result= $query->read("simpanan_wajib","","sum(besar_simpanan) as besar_simpanan","obj");
            $total_simpanan=$result[0]->besar_simpanan;
        
        ?>
        <tfoot>
            <tr><td colspan="3" class="center"><strong>TOTAL</strong></td><td class="right"><strong><?php echo 'Rp '.number_format($total_simpanan,0,'.','.'); ?></strong></td></tr>
        </tfoot>

</table>