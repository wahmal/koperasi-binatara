<?php
include '../atribut/basic.php';
$id_anggota=$_GET['id_anggota'];
$tgl=$_GET['tgl'];
$byr=$_GET['byr'];
$kd_pendek=$_GET['kd_pendek'];
$cicilan=$_GET['cicilan'];


//echo $id_anggota;
$res=$query->read("p_jangka_pendek","where id_anggota='".$id_anggota."'","kd_transaksi","obj" );
foreach ($res as $row1) {
    $kd_transaksi=$row1->kd_transaksi;
}

$array=array();
$query1=$query->read("jurnal_umum","where kd_transaksi='".$kd_transaksi."' order by id_jurnal asc","id_jurnal","obj");
foreach ($query1 as $row2) {
    $array[]=$row2->id_jurnal;
}

$update2=$query->update("jurnal_umum","id_jurnal='".$array[0]."'",array('tgl',$tgl,'debit',$byr));
$update3=$query->update("jurnal_umum","id_jurnal='".$array[1]."'",array('tgl',$tgl,'kredit',$byr));
$update=$query->update("p_jangka_pendek","md5(kd_pendek)='".$kd_pendek."'",array('tgl_pinjam',$tgl,'besar_pinjaman',$byr,'cicilan',$cicilan));

?>
