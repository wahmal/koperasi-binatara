<?php
$id=$_POST['id'];
include '../atribut/basic.php';


$res=$query->read("p_jangka_pendek","where kd_pendek='".$id."'","kd_transaksi","obj");
foreach ($res as $row) {
    $kd_transaksi=$row->kd_transaksi;
}

$res2=$query->read("angsuran_jangka_pendek","where kd_pendek='".$id."' limit 1","kd_transaksi","obj");
foreach ($res2 as $row1) {
    $kd_transaksi1=$row1->kd_transaksi;
}

$delete=$query->delete("jurnal_umum","kd_transaksi",array($kd_transaksi));
$delete1=$query->delete("jurnal_umum","kd_transaksi",array($kd_transaksi1));
$delete2=$query->delete("angsuran_jangka_pendek","kd_pendek",array($id));
$delete3=$query->delete("p_jangka_pendek","kd_pendek",array($id));




?>