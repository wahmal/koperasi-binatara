<?php
$id=$_GET['id'];
include '../atribut/basic.php';


$query1=$query->read("angsuran_jangka_pendek","where kd_angsuran='".$id."' limit 1","kd_transaksi, kd_pendek","obj");
foreach ($query1 as $row1) {
    $kd_transaksi1=$row1->kd_transaksi;
    $id_pinjaman=$row1->kd_pendek;
}

$delete1=$query->delete("jurnal_umum","kd_transaksi",array($kd_transaksi1));
$delete2=$query->delete("angsuran_jangka_pendek","kd_angsuran",array($id));

    $result= $query->read("p_jangka_pendek","where kd_pendek='".$id_pinjaman."'","besar_pinjaman","obj");
        foreach ($result as $row) {

                $cek_lunas=$query->read("angsuran_jangka_pendek","where kd_pendek='".$id_pinjaman."'","sum(besar_angsuran) as total_angsuran","obj");
                foreach ($cek_lunas as $row1) {
                        if($row->besar_pinjaman==$row1->total_angsuran){
                            $data=array('cek'=>'TRUE');
                            echo json_encode($data);
                        }else{
                            $data=array('cek'=>'FALSE');
                            echo json_encode($data);                       
                            }
                }
        }


?>