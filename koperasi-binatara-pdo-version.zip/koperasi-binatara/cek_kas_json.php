<?php
include "cek_kas.php";
$pinjam=$_GET['pinjam'];
if($pinjam>$i){
    echo json_encode(array('kas'=>'1'));
}else{
    echo json_encode(array('kas'=>'0'));
}
?>
