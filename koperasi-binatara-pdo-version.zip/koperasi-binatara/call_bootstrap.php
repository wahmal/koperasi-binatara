

    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/jquery.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/google-code-prettify/prettify.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-transition.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-alert.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-modal.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-dropdown.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-scrollspy.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-tab.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-tooltip.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-popover.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-button.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-collapse.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-carousel.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-typeahead.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/bootstrap-affix.js"></script>
    <script src="<?php echo site_path ?>bootstrap/docs/assets/js/application.js"></script>
    

    <link rel="stylesheet" type="text/css" href="<?php echo site_path ?>bootstrap/docs/assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo site_path ?>bootstrap/docs/assets/css/bootstrap-responsive.css">
    <link rel="stylesheet" type="text/css" href="<?php echo site_path ?>bootstrap/docs/assets/css/docs.css">

    
      <!--DATEPICKER-->
    <script src="<?php echo site_path ?>bootstrap/datepicker/js/bootstrap-datepicker.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo site_path ?>bootstrap/datepicker/css/datepicker.css"> 
    