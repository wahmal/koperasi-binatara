<?php 
include '../atribut/basic.php';
include '../atribut/kd_sebrak.php';
$id_anggota=$_GET['id_anggota'];
$tgl=$_GET['tgl'];
$byr=$_GET['byr'];
$cicilan=$_GET['cicilan'];

$insert1=$query->create("p_sebrak",array(null,$id_anggota,$tgl,$cicilan,$byr,$kd_transaksi));
$insert2=$query->create("jurnal_umum",array(null,$tgl,'Pinjaman Sebrak',$byr,null,$kd_transaksi,'','','',''));
$insert3=$query->create("jurnal_umum",array(null,$tgl,'Kas',null,$byr,$kd_transaksi,'','','',''));

?>
