<?php include 'setting.php'; ?>

<!--DATEPICKER-->
<script src="<?php echo site_path;?>bootstrap/datepicker/js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo site_path;?>bootstrap/datepicker/css/datepicker.css">
<!--DATA TABLES CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo site_path;?>data_tables/media/css/demo_table.css">
<link rel="stylesheet" type="text/css" href="<?php echo site_path;?>data_tables/media/css/demo_page.css">


<!--MODAL-->
<div id="myModal" class="modal hide fade">
    <div class="modal-body">Data Berhasil Tersimpan !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="modalUpdate" class="modal hide fade">
    <div class="modal-body">Data Telah Berhasil di Update !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="terhapus" class="modal hide fade">
    <div class="modal-body">Data Telah Terhapus !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>



<legend id="form">Form Peminjaman</legend>
<form action="#" method="post" id="form_sebrak" class="form-horizontal">
<div class="form-actions" style="padding-left:0px;padding-bottom:0px;margin-bottom: 0px;margin-left: 0px">
        <table border="0">
            <tr>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="name">Nama / Id Anggota :</label>
                      <div class="controls">
                        <input type="hidden" id="kd_sebrak" value="<?php echo $kd_sebrak; ?>">
                        <select name="id_anggota" id="id_anggota" >
                            <option value="" align="center">-PILIH-</option>
                            <?php
                            $anggota= $query->read("anggota","order by nama asc","id_anggota, nama","obj");
                            foreach ($anggota as $data) {
                                $cek= $query->read("p_sebrak","where id_anggota='".$data->id_anggota."'","","obj");


                                        if($data->id_anggota==$id_anggota){
                                            if(!empty($cek)){
                                                echo"<option value='$data->id_anggota&nama=$data->nama' class='nunggak' selected>$data->nama - $data->id_anggota</option>";
                                            }else{
                                                echo"<option value='$data->id_anggota&nama=$data->nama' selected>$data->nama - $data->id_anggota</option>";
                                            }
                                        }else{
                                            if(!empty($cek)){
                                                echo"<option value='$data->id_anggota&nama=$data->nama'class='nunggak'>$data->nama - $data->id_anggota</option>";
                                            }else{
                                                    echo"<option value='$data->id_anggota&nama=$data->nama'>$data->nama - $data->id_anggota</option>";
                                            }                                     
                                        }
                            }
                            ?>
                        </select>
                      </div>
                    </div>
                </td>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="tgl">Tanggal Pinjam :</label>
                      <div class="controls">
                        <div class="input-append date" id="datepicker" data-date="<?php echo date("Y-m-d");?>" data-date-format="yyyy-mm-dd">
                            <span class="add-on"><i class="icon-th"></i></span>
                            <input class="span2" size="16" type="text" id="tgl" name="tgl" placeholder="yyyy-mm-dd" readonly="true" value="">
                        </div>
                      </div>
                    </div>
               </td>
            </tr>
            <tr>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="telepon">Besar Pinjaman :</label>
                      <div class="controls">
                        <input type="text" name="byr" id="byr" value="">
                      </div>
                  </div>  
                </td>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="telepon">Jumlah Cicilan :</label>
                      <div class="controls" id="cicil">
                        <select name="cicilan" id="cicilan" class="input-small">
                            <option value="" align="center">-PILIH-</option>
                            <?php
                            for($i=1;$i<=$cicilan_sebrak;$i++){
                                if($i==$cicilan){
                                    echo"<option value=".$i." selected>".$i." x</option>";    
                                }else{
                                    echo"<option value=".$i.">".$i." x</option>";
                                } 
                            }
                            ?>
                        </select>
                      </div>
                    </div>
                </td>
            </tr>
        </table>   
    </div>
    <div style="background:#FFF;margin-left: 0px;padding-top: 5px;">
<button type="submit" class="btn btn-success" data-loading-text="Loading..." id="tombol">Save</button>
<button type="reset" class="btn">Reset</button>
    </div>
</form>
<script>
$("#datepicker").datepicker();    
</script>
<input type="hidden" id="paket">

<legend>Pinjaman Sebrak - <span class="nama"></span></legend>

<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>assets/js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/media/js/jquery.dataTables.min.js"></script>
<script src="<?php echo site_path; ?>bootstrap/js/validate/jquery.validate.min.js"></script>
<script type="text/javascript" charset="utf-8">
    var $j = jQuery.noConflict();
    $j(document).ready(function() {
            var oTable = $j('#example').dataTable( {
                    
                    "bProcessing": true,
                    "bServerSide": true,
                    "bAutoWidth": false,
                    "bDestroy" : true,
                    "bRetrieve" : true,
                    "sScrollX": "100%",
                    "sScrollXInner": "120%",
                    "bScrollCollapse": true,
                    "sAjaxSource": "<?php echo site_path; ?>sebrak/pinjaman_json.php?",
                    "sPaginationType": "full_numbers",
                    "aoColumns": [ 
                        {"sClass": "center"},
                        {"sClass": "center"},
                        {"sClass": "center"},
                        {"sClass": "right"},
                        {"sClass": "right"},
                        {"sClass": "center"},
                        {"sClass": "center"}
                    ],
                    "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
                    "fnServerData": function ( sSource, aoData, fnCallback ) {
			/* Add some extra data to the sender */
			aoData.push( { "name": "id_anggota", "value": $j("#paket").val() } );
			$j.getJSON( sSource, aoData, function (json) { 
				/* Do whatever additional processing you want on the callback, then tell DataTables */
				fnCallback(json)
			} )}
            } );
          
$j('#byr').blur(function(){
            var pinjam=$j(this).val();
            $j.getJSON ('<?php echo site_path ?>cek_kas_json.php',{pinjam:pinjam}, function (json) {
                if(json.kas=='1'){alert('Kas tidak mencukupi !');$j('#byr').focus();return false;}
        }); 
});
$j("#id_anggota").change(function(){ 
    $j("#form").html("Form Peminjaman");
    $j("#tombol").html("Save");
    $j('#kd_sebrak').val('');
    $j('#tgl').val('');
    $j('#byr').val('');
    $j("#cicilan option[value='']").attr("selected", "selected");
    var id_anggota = $j("#id_anggota").val(); 
        $j.getJSON ('<?php echo site_path ?>sebrak/data_pinjaman.php',{id:id_anggota,fungsi:'data_anggota'}, function (json) {
            $j("#paket").val(id_anggota);
            $j(".nama").html(json.nama);
            oTable.fnDraw();
        }); 
}); 
 
        
$j('.delbutton').live("click", function() {
        var id = $j(this).attr("id");
        var dataString = 'id='+ id ;
        var parent = $j(this).parent();
        if(confirm("Yakin Pinjaman Ini ? Data angsuran akan ikut terhapus..,"))
        {
        $j.ajax({
           type: "POST",
           url: "<?php echo site_path;?>sebrak/delete.php",
           data: dataString,
           cache: false,
           success: function()
           {
                    $("#terhapus").bind("show", function() {
                    $("#terhapus a.btn").click(function(e) {
                        console.log("button pressed: "+$(this).html());
                        $("#terhapus").modal('hide');
                    });
                    });
                    $("#terhapus").bind("hide", function() {
                    $("#terhapus a.btn").unbind();
                    });
                    $("#terhapus").modal({
                    "backdrop"  : "static",
                    "keyboard"  : true,
                    "show"      : true    
                    });
                    oTable.fnDraw();
                    
          }
          
          });
          }
	  return false;
});
    
$j('.editbutton').live("click", function() {
         kd_pinjam = $j(this).attr("kd_pinjam");
         besar_pinjaman= $j(this).attr("besar_pinjaman");
        
         tgl_pinjam= $j(this).attr("tgl_pinjam");
         cicilan= $j(this).attr("cicilan");
        var dataString = 'cicil='+ cicilan;
       
        $j("#cicilan option[value='" + cicilan + "']").attr("selected", "selected");
        $j("#form").html("Edit Peminjaman");
        $j("#tombol").html("Update");
        $j("#byr").val(besar_pinjaman);
        $j("#tgl").val(tgl_pinjam);
        $j("#kd_sebrak").val(kd_pinjam);
        
        return false;
});

$j('#form_sebrak').validate({
	    rules: {
	      id_anggota: {
	        required: true
	      },
	      tgl: {
	        required: true
	      },
	      byr: {
                max:<?php echo $sebrak ;?>,
                number:true,
	        required: true
	      },
	      cicilan: {
                number:true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
                var id_anggota = $j("#id_anggota").attr("value");
                tgl  = $j("#tgl").attr("value");
                byr  = $j("#byr").attr("value");
                kd_sebrak  =$j("#kd_sebrak").attr("value");
                cicilan  =$j("#cicilan").attr("value");
                if(kd_sebrak==""){
                    $j.ajax({
                        type: "GET", 
                        url: "<?php echo site_path;?>sebrak/simpan.php", 
                        data: "id_anggota=" + id_anggota + "&byr=" + byr + "&tgl=" + tgl+ "&cicilan=" + cicilan,
                        complete: function(data){
                            //$j("#id_pinjaman").val('');
                            $j("#tgl").val('');
                            $j("#byr").val('');
                            $j("#kd_sebrak").val('');
                            $j("#cicilan").val('');
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                            oTable.fnDraw();
                        }
                    });
                    return false;
                }else{
                    $j.ajax({
                        type: "GET", 
                        url: "<?php echo site_path;?>sebrak/update.php", 
                        data: "id_anggota=" + id_anggota + "&byr=" + byr + "&tgl=" + tgl + "&kd_sebrak=" + kd_sebrak + "&cicilan=" + cicilan,
                        complete: function(data){
                            //$j("#id_pinjaman").val('');
                            $j("#tgl").val('');
                            $j("#byr").val('');
                            $j("#kd_sebrak").val('');
                            $j("#cicilan").val('');
                            //konfirmasi
                            $("#modalUpdate").bind("show", function() {
                            $("#modalUpdate a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#modalUpdate").modal('hide');
                            });
                            });
                            $("#modalUpdate").bind("hide", function() {
                            $("#modalUpdate a.btn").unbind();
                            });
                            $("#modalUpdate").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true   
                            });
                            oTable.fnDraw();
                        }
                    });
                    return false;
                }
    }  
});

});
</script>
<script>
    function falsebutton(){
        alert("Tidak dapat mengubah data !! pinjaman sudah diangsur");
        return false;
    }
</script>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
			<th>Kode Pinjam</th>
			<th>Tanggal Pinjam</th>
                        <th>Cicilan</th>
                        <th>Besar Pinjam</th>
                        <th>Total Angsuran</th>
                        <th>Status</th>
                        <th>Pilihan</th>
		</tr>
	</thead>

</table>