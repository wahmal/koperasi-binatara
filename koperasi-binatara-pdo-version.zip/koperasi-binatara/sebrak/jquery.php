<script>
var $s = jQuery.noConflict();           
$s(document).ready(function(){
    
        var htmlobjek; 
	  $s("#id_anggota").change(function(){ 
	    var id_anggota = $s("#id_anggota").val(); 
	    $s.ajax({ 
	        url: "sebrak/data_pinjaman.php", 
	        data: "id_anggota="+id_anggota, 
	        cache: false, 
	        success: function(msg){ 
                    $s("#tgl").val('');
                    $s("#byr").val('');
                    $s("#kd_sebrak").val('');
                    $s("#cicilan").val('');
	            $s("#data").html(msg); 
	        } 
	    }); 
	  }); 
 
        
$s('.delbutton').live("click", function() {
        var id = $s(this).attr("id");
        var dataString = 'id='+ id ;
        var parent = $s(this).parent();
        if(confirm("Yakin Pinjaman Ini ? Data angsuran akan ikut terhapus..,"))
        {
        $s.ajax({
           type: "POST",
           url: "sebrak/delete.php",
           data: dataString,
           cache: false,

           beforeSend: function()
           {
           parent.animate({'backgroundColor':'#fb6c6c'},300).animate({ opacity: 0.35 }, "slow");
           }, 
           success: function()
           {
               parent.slideUp('slow', function() {$s(this).remove();});
                    $("#terhapus").bind("show", function() {
                    $("#terhapus a.btn").click(function(e) {
                        console.log("button pressed: "+$(this).html());
                        $("#terhapus").modal('hide');
                    });
                    });
                    $("#terhapus").bind("hide", function() {
                    $("#terhapus a.btn").unbind();
                    });
                    $("#terhapus").modal({
                    "backdrop"  : "static",
                    "keyboard"  : true,
                    "show"      : true    
                    });
                    
                    var id_anggota = $s("#id_anggota").val(); 
                    $s.ajax({ 
                        url: "sebrak/data_pinjaman.php", 
                        data: "id_anggota="+id_anggota, 
                        cache: false, 
                        success: function(msg){ 
                            $("#data").html(msg); 
                        } 
                    }); 
                    
          }
          
          });
          }
	  return false;
});
    
$s('.editbutton').live("click", function() {
        var kd_pinjam = $s(this).attr("kd_pinjam");
        var besar_pinjaman= $s(this).attr("besar_pinjaman");
        
        var tgl_pinjam= $s(this).attr("tgl_pinjam");
        var cicilan= $s(this).attr("cicilan");
        var dataString = 'cicil='+ cicilan;
        
        $s.ajax
        ({
        type: "GET",
        url: "sebrak/cicilan.php",
        data: dataString,
        cache: false,
        success: function(html)
        {
        $s("#cicil").html(html);
        } 
        });
        
        $s("#form").html("Edit Peminjaman");
        $s("#tombol").html("Update");
        $s("#byr").val(besar_pinjaman);
        $s("#tgl").val(tgl_pinjam);
        $s("#kd_sebrak").val(kd_pinjam);
        
       // $s("#cicilan").val(cicilan);
        return false;
});

$s('#form_sebrak').validate({
	    rules: {
	      id_anggota: {
	        required: true
	      },
	      tgl: {
	        required: true
	      },
	      byr: {
                max:<?php echo $sebrak ;?>,
                number:true,
	        required: true
	      },
	      cicilan: {
                number:true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
                var id_anggota = $s("#id_anggota").attr("value");
                tgl  = $s("#tgl").attr("value");
                byr  = $s("#byr").attr("value");
                kd_sebrak  =$s("#kd_sebrak").attr("value");
                cicilan  =$s("#cicilan").attr("value");
                if(kd_sebrak==""){
                    $s.ajax({
                        type: "GET", 
                        url: "sebrak/simpan.php", 
                        data: "id_anggota=" + id_anggota + "&byr=" + byr + "&tgl=" + tgl+ "&cicilan=" + cicilan,
                        complete: function(data){
                            //$s("#id_pinjaman").val('');
                            $s("#tgl").val('');
                            $s("#byr").val('');
                            $s("#kd_sebrak").val('');
                            $s("#cicilan").val('');
                            $s('#data').load('sebrak/data_pinjaman.php');
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                            var id_anggota = $s("#id_anggota").val(); 
                            $s.ajax({ 
                                url: "sebrak/data_pinjaman.php", 
                                data: "id_anggota="+id_anggota, 
                                cache: false, 
                                success: function(msg){ 
                                    $("#data").html(msg); 
                                } 
                            }); 
                        }
                    });
                    return false;
                }else{
                    $s.ajax({
                        type: "GET", 
                        url: "sebrak/update.php", 
                        data: "id_anggota=" + id_anggota + "&byr=" + byr + "&tgl=" + tgl + "&kd_sebrak=" + kd_sebrak + "&cicilan=" + cicilan,
                        complete: function(data){
                            //$s("#id_pinjaman").val('');
                            $s("#tgl").val('');
                            $s("#byr").val('');
                            $s("#kd_sebrak").val('');
                            $s("#cicilan").val('');
                            $s('#data').load('sebrak/data_pinjaman.php');
                            //konfirmasi
                            $("#modalUpdate").bind("show", function() {
                            $("#modalUpdate a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#modalUpdate").modal('hide');
                            });
                            });
                            $("#modalUpdate").bind("hide", function() {
                            $("#modalUpdate a.btn").unbind();
                            });
                            $("#modalUpdate").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true   
                            });
                            var id_anggota = $s("#id_anggota").val();  
                            $s.ajax({ 
                                url: "sebrak/data_pinjaman.php", 
                                data: "id_anggota="+id_anggota, 
                                cache: false, 
                                success: function(msg){ 
                                    $("#data").html(msg); 
                                } 
                            }); 
                        }
                    });
                    return false;
                }
    }  
});
});	
</script>