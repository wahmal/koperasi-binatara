<?php
/*
 * Script:    DataTables server-side script for PHP and MySQL
 * Copyright: 2012 - John Becker, Beckersoft, Inc.
 * Copyright: 2010 - Allan Jardine
 * License:   GPL v2 or BSD (3-point)
 */
include('../atribut/datatables_setting.php');
  
class TableData {
 
    private $_db;
    protected $con;

    public function __construct() {

        global $conn;
        $this->con =& $conn;
        try {
            $this->_db = new PDO('mysql:host='.$this->con['host'].';dbname='.$this->con['database'], $this->con['user'], $this->con['passwd'], array(PDO::ATTR_PERSISTENT => true));
        } catch (PDOException $e) {
            error_log("Failed to connect to database: ".$e->getMessage());
        }       
        
    }
    public function read($table, $where = "", $fieldName = "",$type="array") {
          $arrResult = array();
          $fieldStr = "";
          if (empty($fieldName) ) {
            $fieldStr = "*  ";
          }
          elseif (is_array($fieldName) ){
            foreach ($fieldName as $field) {
              $fieldStr .= $field.", ";
            }
          }
          else {  
              $fieldStr .= $fieldName.", ";
          }
          $fields = substr($fieldStr, 0, -2);

        //echo
          $sql = "SELECT ".$fields." FROM ".$table." ".$where;
          //echo $sql;
          $query = $this->_db->query($sql);

          if($type=='array'){
            while($data = $query->fetch(PDO::FETCH_ASSOC)){
                array_push($arrResult, $data);
            }
          }
          if($type=='obj'){
            while($data = $query->fetch(PDO::FETCH_OBJ)){
                array_push($arrResult, $data);
            }
          }
          return $arrResult;
    }
    public function get($table, $index_column, $columns, $alias, $join=null) {
        // Paging
        $sLimit = "";
        if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' ) {
            $sLimit = "LIMIT ".intval( $_GET['iDisplayStart'] ).", ".intval( $_GET['iDisplayLength'] );
        }
        
        // Ordering
        $sOrder = "";
        if ( isset( $_GET['iSortCol_0'] ) ) {
            $sOrder = "ORDER BY  ";
            for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ ) {
                if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" ) {
                    $sortDir = (strcasecmp($_GET['sSortDir_'.$i], 'ASC') == 0) ? 'ASC' : 'DESC';
                    $sOrder .= "".$columns[ intval( $_GET['iSortCol_'.$i] ) ]." ". $sortDir .", ";
                }
            }
            
            $sOrder = substr_replace( $sOrder, "", -2 );
            if ( $sOrder == "ORDER BY" ) {
                $sOrder = "";
            }
        }
        
        /* 
         * Filtering
         * NOTE this does not match the built-in DataTables filtering which does it
         * word by word on any field. It's possible to do here, but concerned about efficiency
         * on very large tables, and MySQL's regex functionality is very limited
         */
        $sWhere = "";
        if ( isset($_GET['sSearch']) && $_GET['sSearch'] != "" ) {
            $sWhere = "WHERE (";
            for ( $i=0 ; $i<count($columns) ; $i++ ) {
                if ( isset($_GET['bSearchable_'.$i]) && $_GET['bSearchable_'.$i] == "true" ) {
                    $sWhere .= "`".$columns[$i]."` LIKE :search OR ";
                }
            }
            $sWhere = substr_replace( $sWhere, "", -3 );
            $sWhere .= ')';
        }
        
        // Individual column filtering
        for ( $i=0 ; $i<count($columns) ; $i++ ) {
            if ( isset($_GET['bSearchable_'.$i]) && $_GET['bSearchable_'.$i] == "true" && $_GET['sSearch_'.$i] != '' ) {
                if ( $sWhere == "" ) {
                    $sWhere = "WHERE ";
                }
                else {
                    $sWhere .= " AND ";
                }
                $sWhere .= "`".$columns[$i]."` LIKE :search".$i." ";
            }
        }
        
        // SQL queries get data to display
        $sQuery = "SELECT SQL_CALC_FOUND_ROWS ".str_replace(" , ", " ", implode(", ", $columns))." FROM ".$table." ".$join." ".$sWhere." ".$sOrder." ".$sLimit;

        //echo $sQuery;
        $statement = $this->_db->prepare($sQuery);
        
        // Bind parameters
        if ( isset($_GET['sSearch']) && $_GET['sSearch'] != "" ) {
            $statement->bindValue(':search', '%'.$_GET['sSearch'].'%', PDO::PARAM_STR);
        }
        for ( $i=0 ; $i<count($columns) ; $i++ ) {
            if ( isset($_GET['bSearchable_'.$i]) && $_GET['bSearchable_'.$i] == "true" && $_GET['sSearch_'.$i] != '' ) {
                $statement->bindValue(':search'.$i, '%'.$_GET['sSearch_'.$i].'%', PDO::PARAM_STR);
            }
        }
        $statement->execute();
        $rResult = $statement->fetchAll();
        
        $iFilteredTotal = current($this->_db->query('SELECT FOUND_ROWS()')->fetch());
        
        // Get total number of rows in table
        $sQuery = "SELECT COUNT(".$index_column.") FROM ".$table."";
        //echo $sQuery;
        $iTotal = current($this->_db->query($sQuery)->fetch());
        
        // Output
        $output = array(
            "sEcho" => intval($_GET['sEcho']),
            "iTotalRecords" => $iTotal,
            "iTotalDisplayRecords" => $iFilteredTotal,
            "aaData" => array()
        );
        
        // Return array of values
        //get config
        $setting=  $this->read("pengaturan","where id_setting='5'","","obj");
        $bunga_jangka_panjang=$setting[0]->content;

        $columns=$alias;
        $i=0;
        $x=1;
        foreach($rResult as $aRow) {
            $row[0]=$aRow[0];
            $row[1]=$aRow[1];
            $pinjaman=$aRow[2];
            $angsuran=$aRow[3];
            $row[4]=$bunga_jangka_panjang." %";
            $total_angsuran=$aRow[3]+$i;
            $saldo_pinjaman=$aRow[2]-$total_angsuran;
            $row[2]='Rp '.number_format($pinjaman,0,'.','.');
            $row[3]='Rp '.number_format($aRow[3],0,'.','.');
            $row[5]='Rp '.number_format($total_angsuran,0,'.','.');
            $row[6]='Rp '.number_format($saldo_pinjaman,0,'.','.');
            $row[7]="Angsuran ke-".$x;
            $row[]="<a href='#' class='delete_angsuran' id='".$aRow[0]."'><i class='icon-remove'></i></a>";
            
            $i=$angsuran+$i;
            $x++;
    
            $output['aaData'][] = $row;
        }
        
        echo json_encode( $output );
    }
}
header('Pragma: no-cache');
header('Cache-Control: no-store, no-cache, must-revalidate');
// Create instance of TableData class
$table_data = new TableData();
// Get the data



 if(isset($_GET['id_pinjaman'])){
    $joins = "JOIN p_jangka_panjang b ON a.kd_panjang = b.kd_panjang where md5(a.kd_panjang)='".$_GET['id_pinjaman']."'";
 }else{
    $joins = "JOIN p_jangka_panjang b ON a.kd_panjang = b.kd_panjang";
 } 



$table_data->get(
    'angsuran_jangka_panjang a', 
    'a.kd_angsuran', 
    array("a.kd_angsuran","a.tgl_angsuran","b.besar_pinjaman","a.besar_angsuran"),
    array("kd_angsuran","tgl_angsuran","besar_pinjaman","besar_angsuran"),
    $joins
    );

//KHUSUS QUERY JOIN ` gw hapus
/*
 * Alternatively, you may want to use the same class for several differnt tables for different pages.
 * By adding something similar to the following to your .htaccess file you can control this a little more...
 *
 * RewriteRule ^pagename/data/?$ data.php?_page=PAGENAME [L,NC,QSA]
 *
 
switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        if (isset($_REQUEST['_page'])) {
            if($_REQUEST['_page'] === 'PAGENAME') {
                $table_data->get('table_name', 'index_column', array('column1', 'column2', 'columnN'));
            }
        }
        break;
    default:
        header('HTTP/1.1 400 Bad Request');
}
*/
?>