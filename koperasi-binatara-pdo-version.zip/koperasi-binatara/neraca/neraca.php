<?php include'neraca/hitung_neraca.php'; ?>
<?php
$neraca_p=array();
$i=0;
$res=$query->read("neraca_pembanding","order by id asc","content_pembanding","obj");
foreach($res as $row){
$neraca_p[$i]=$row->content_pembanding;
$i++;
}
?>
<table CELLSPACING="0" COLS="10" BORDER="0"width="100%" >
	<tr>
		<td colspan=14 HEIGHT="19" align="CENTER" ><b>KOPERASI BINTARA</b></td>
		</tr>
	<tr>
		<td colspan=14 HEIGHT="19" align="CENTER" ><b>NERACA</b></td>
		</tr>
	<tr>
		<td colspan=14 HEIGHT="22" align="CENTER" ><b>31 Desember <?php echo $neraca_p[0];?> dan <?php echo date("Y");?></b></td>
		</tr>
	<tr>
		<td style="border-bottom: 3px solid #000000" HEIGHT="22"  colspan="14">&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="23" width="2%" >&nbsp;</td>
		<td  width="2%">&nbsp;</td>
		<td  width="24%">&nbsp;</td>
		<td  width="10%">&nbsp;</td>
		<td  width="1%">&nbsp;</td>
                <td  width="10%">&nbsp;</td>
		<td  width="1%">&nbsp;</td>
		<td width="1%" style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  width="2%">&nbsp;</td>
		<td width="2%" >&nbsp;</td>
		<td width="24%" >&nbsp;</td>
		<td  width="10%">&nbsp;</td>
                <td  width="1%">&nbsp;</td>
		<td  width="10%">&nbsp;</td>
	</tr>
	<tr>
		<td colspan=3 HEIGHT="19"  ><b>AKTIVA</b></td>
		<td align="CENTER" ><b><?php echo $neraca_p[0]; ?></b></td>
		<td align="CENTER" >&nbsp;</td>
                <td align="CENTER" ><b><?php echo date('Y'); ?></b></td>
		<td align="CENTER" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="CENTER" >&nbsp;</td>
		<td colspan=3  ><b>KEWAJIBAN DAN EKUITAS</b></td>
		<td align="CENTER" ><b><?php echo $neraca_p[0]; ?></b></td>
                <td align="CENTER" >&nbsp;</td>
                <td align="CENTER" ><b><?php echo date('Y'); ?></b></td>
	</tr>
	<tr>
		<td HEIGHT="19" colspan="6" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="CENTER" >&nbsp;</td>
		<td colspan="6" >&nbsp;</td>
	</tr>
	<tr>
		<td colspan=3 HEIGHT="19"  >AKTIVA LANCAR</td>
		<td  align="center">Rp</td>
		<td align="CENTER" ></td>
                <td align="center">Rp</td><td></td>
		<td style="border-left: 3px solid #000000" align="CENTER" ></td>
		<td colspan=3  >KEWAJIBAN JANGKA PENDEK</td>
		<td  align="center">Rp</td>
                <td></td><td align="center">Rp</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Kas dan Bank</td>
		<td align="RIGHT" ><?php echo number_format($neraca_p[1],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
                <td align="RIGHT"><?php echo number_format($kas_bank,0,'.','.');?></td>
                <td></td>           
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Usaha</td>
		<td align="RIGHT" ><?php echo number_format($neraca_p[19],0,'.','.');?></td>
                <td></td>
                <td align="RIGHT"><?php echo number_format($content[12],0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Investasi Jangka Pendek</td>
		<td align="RIGHT" ><?php echo number_format($neraca_p[2],0,'.','.');?></td>
		<td></td>
                <td align="RIGHT" ><?php echo number_format($content[1],0,'.','.');?></td>
		<td></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td></td>
		<td colspan=2  >Hutang Bank</td>
		<td align="RIGHT" ><?php echo number_format($neraca_p[20],0,'.','.');?></td>
                <td></td>
		<td align="RIGHT" ><?php echo number_format($content[13],0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Usaha</td>
		<td align="RIGHT" ><?php echo number_format($neraca_p[3],0,'.','.');?></td>
		<td></td>
                <td align="RIGHT" ><?php echo number_format($content[2],0,'.','.');?></td>
		<td></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Pajak</td>
		<td align="RIGHT" ><?php echo number_format($neraca_p[21],0,'.','.');?></td>
                <td></td>
		<td align="RIGHT" ><?php echo number_format($content[14],0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Pinjaman Anggota</td>
		<td align="RIGHT" ><?php echo number_format($neraca_p[4],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
                <td align="RIGHT" ><?php echo number_format($total_piutang,0,'.','.');?></td>
		<td></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Simpanan Anggota</td>
		<td align="RIGHT" ><?php echo number_format($neraca_p[22],0,'.','.');?></td>
                <td></td>
		<td align="RIGHT" ><?php echo number_format($total_sukarela,0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Pinjaman Non-Anggota</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[5],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td align="RIGHT" ><?php echo number_format($content[3],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Dana Bagian SHU</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[23],0,'.','.');?></td>
                <td></td>
		<td align="RIGHT" ><?php echo number_format($content[15],0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Lain-Lain</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[6],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td align="RIGHT" ><?php echo number_format($content[4],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Jangka Panjang Akan Jatuh Tempo</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[24],0,'.','.');?></td>
                <td></td>
		<td align="RIGHT" ><?php echo number_format($content[16],0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Peny. Piutang Tak Tertagih</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[7],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td align="RIGHT" ><?php echo number_format($content[5],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Biaya Harus Dibayar</td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" ><?php echo number_format($neraca_p[25],0,'.','.');?></td>
                <td></td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" >
                    <?php echo number_format($content[17],0,'.','.');?>
                </td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Persediaan</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[8],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td align="RIGHT" ><?php echo number_format($content[6],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Kewajiban jangka Pendek</td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo number_format($neraca_p[26],0,'.','.');?></b></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo number_format($total_kew_pendek,0,'.','.');?></b></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Pendapatan Akan Diterima</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><?php echo number_format($neraca_p[9],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" ><?php echo number_format($content[7],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td align="CENTER" colspan="6">&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Aktiva Lancar</td>
                <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo number_format($neraca_p[35],0,'.','.');?></b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo number_format($total_aktiva_lancar,0,'.','.');?></b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  colspan="6">KEWAJIBAN JANGKA PANJANG</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  colspan="6">&nbsp;</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Bank</td>
                <td align="right"><?php echo number_format($neraca_p[20],0,'.','.');?></td><td></td>
		<td align="RIGHT" ><?php echo number_format($content[18],0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  colspan="7">INVESTASI JANGKA PANJANG</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Jangka Panjang Lainnya</td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" ><?php echo number_format($neraca_p[27],0,'.','.');?></td>
                <td></td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><?php echo number_format($content[19],0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Penyertaan Pada Koperasi</td>
		<td align="RIGHT" ><?php echo number_format($neraca_p[10],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
                <td align="RIGHT" ><?php echo number_format($content[8],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Kewajiban Jangka Panjang</td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo number_format($neraca_p[36],0,'.','.');?></b></td>
                <td></td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo number_format($total_kew_panjang,0,'.','.');?></b></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Penyertaan Pada Non-Koperasi</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" >
                    <?php echo number_format($neraca_p[11],0,'.','.');?>
                </td>
		<td align="RIGHT" >&nbsp;</td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" >
                    <?php echo number_format($content[9],0,'.','.');?>
                </td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td align="CENTER" colspan="6">&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Investasi Jangka Panjang</td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b>
                        <?php echo number_format($neraca_p[21],0,'.','.');?>
                    </b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
                <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b>
                        <?php echo number_format($total_inv_jangka_panjang,0,'.','.');?>
                    </b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  colspan="6">EKUITAS</td>
	</tr>
	<tr>
		<td HEIGHT="19" align="CENTER" >&nbsp;</td>
		<td align="CENTER" colspan="6" >&nbsp;</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Simpanan Wajib</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[28],0,'.','.');?></td>
                <td></td>
		<td align="RIGHT" ><?php echo number_format($total_wajib,0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  colspan="7">AKTIVA TETAP</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Simpanan Pokok</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[29],0,'.','.');?></td>
                <td></td>
		<td align="RIGHT" ><?php echo number_format($total_pokok,0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Tanah/Hak Atas Tanah</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[12],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td align="RIGHT" ><?php echo number_format($aktiva_tanah,0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Modal Penyetaraan Partisipasi Anggota</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[30],0,'.','.');?></td>
                <td></td>
		<td align="RIGHT" ><?php echo number_format($content[20],0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Bangunan</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[13],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td align="RIGHT" ><?php echo number_format($aktiva_bangunan,0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Modal Penyertaan</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[31],0,'.','.');?></td>
                <td></td>
		<td align="RIGHT" ><?php echo number_format($modal_penyertaan,0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Mesin</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[14],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td align="RIGHT" ><?php echo number_format($aktiva_mesin,0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Modal Sumbangan</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[32],0,'.','.');?></td>
                <td></td>
		<td align="RIGHT" ><?php echo number_format($content[22],0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Inventaris</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[15],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td align="RIGHT" ><?php echo number_format($aktiva_inventaris,0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Cadangan</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[33],0,'.','.');?></td>
                <td></td>
		<td align="RIGHT" ><?php echo number_format($content[23],0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Akumulasi Penyusutan</td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" ><?php echo number_format($neraca_p[16],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><?php echo number_format($penyusutan,0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >SHU Belum Dibagi</td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" ><?php echo number_format($neraca_p[34],0,'.','.');?></td>
                <td></td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><?php echo number_format($content[24],0,'.','.');?></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Jumlah Aktiva Tetap</td>
                <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo number_format($neraca_p[37],0,'.','.');?></b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo number_format($total_aktiva_tetap,0,'.','.');?></b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Ekuitas</td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" ><b>
                        <?php echo number_format($neraca_p[42],0,'.','.');?>
                    </b></td>
                <td></td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b>
                        <?php echo number_format($total_ekuitas,0,'.','.');?>
                    </b></td>
	</tr>
	<tr>
		<td HEIGHT="19" colspan="7" align="CENTER" >&nbsp;</td>
		<td style="border-left: 3px solid #000000"  colspan="7">&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  colspan="7">AKTIVA LAIN-LAIN</td>
		<td style="border-left: 3px solid #000000"  colspan="7">&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Aktiva tetap Dalam Konstruksi</td>
                <td align="RIGHT" ><?php echo number_format($neraca_p[17],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td align="RIGHT" ><?php echo number_format($content[10],0,'.','.');?></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" colspan="7" >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Beban Ditangguhkan</td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" >
                    <?php echo number_format($neraca_p[18],0,'.','.');?>
                </td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" >
                    <?php echo number_format($content[11],0,'.','.');?>
                </td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" colspan="7">&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Aktiva Lain-Lain</td>
                <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" >
                    <b> <?php echo number_format($neraca_p[35],0,'.','.');?></b>
                </td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" >
                <b><?php echo number_format($total_aktiva_lain,0,'.','.');?></b></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" colspan="7">&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19" align="CENTER" colspan="7">&nbsp;</td>
		<td style="border-left: 3px solid #000000"  colspan="7">&nbsp;</td>
	</tr>
	<tr>
		<td colspan=3 HEIGHT="19"  ><b>JUMLAH AKTIVA</b></td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo number_format($neraca_p[39],0,'.','.');?></b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo number_format($total_aktiva,0,'.','.');?></b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td colspan=3  ><b>JUMLAH KEWAJIBAN &amp; EKUITAS</b></td>
                <td style="border-bottom: 1px solid #000000" align="RIGHT" ><b>
                        <?php echo number_format($neraca_p[43],0,'.','.');?>
                    </b></td>
                <td></td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b>
                         <?php echo number_format($total_kew_ekuitas,0,'.','.');?>
                    </b></td>
	</tr>
</table>
