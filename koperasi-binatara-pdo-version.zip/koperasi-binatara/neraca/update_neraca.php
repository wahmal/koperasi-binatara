<?php
include '../atribut/basic.php';

$data=explode(':',$_GET['data']);

for($i=1; $i<=24; $i++){
    if(empty($data[$i])){$data[$i]=0;}
}

$id=array(3,4,6,7,8,9,10,11,12,18,19,20,21,22,24,25,26,27,28,31,32,33,34,35);

$i=1;
foreach ($id as $val) {

	$query->update('neraca_pembanding',"id='".$val."'",array('content',$data[$i]));
	$i++;
}

/*
$update=mysql_query("update neraca_pembanding set content='".$data[1]."' where id='3'")or die (mysql_error());    
$update=mysql_query("update neraca_pembanding set content='".$data[2]."' where id='4'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[3]."' where id='6'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[4]."' where id='7'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[5]."' where id='8'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[6]."' where id='9'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[7]."' where id='10'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[8]."' where id='11'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[9]."' where id='12'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[10]."' where id='18'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[11]."' where id='19'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[12]."' where id='20'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[13]."' where id='21'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[14]."' where id='22'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[15]."' where id='24'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[16]."' where id='25'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[17]."' where id='26'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[18]."' where id='27'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[19]."' where id='28'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[20]."' where id='31'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[21]."' where id='32'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[22]."' where id='33'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[23]."' where id='34'")or die (mysql_error());  
$update=mysql_query("update neraca_pembanding set content='".$data[24]."' where id='35'")or die (mysql_error());  */
?>
