<?php
//error_reporting(0);
include 'setting.php';
//DATA NERACA LAIN_LAIN
$i=1;
$sql= $query->read("neraca_pembanding","where id in (3,4,6,7,8,9,10,11,12,18,19,20,21,22,24,25,26,27,28,31,32,33,34,35)","content","obj");
foreach ($sql as $row) {
    $content[$i]=$row->content;
    $i++;
}


//AKTIVA TETAP 

//MESIN
$mesin=array();
$depresiasi_mesin=array();
$aktiva=$query->read("aktiva_tetap","WHERE kd_jenis='1' order by tgl_perolehan asc","hrg_perolehan, residu, umur_ekonomis, datediff(now(),tgl_perolehan) as pemakaian","obj");
foreach ($aktiva as $row) {
    $mesin[]=$row->hrg_perolehan;
    $nilai_ekonomis=$row->hrg_perolehan-$row->residu;
    $depresiasi_per_hari=$nilai_ekonomis/($row->umur_ekonomis*365);
    $depresiasi_mesin[]=$depresiasi_per_hari*$row->pemakaian;
}

//BANGUNAN
$bangunan=array();
$depresiasi_bangunan=array();
$aktiva=$query->read("aktiva_tetap","WHERE kd_jenis='2' order by tgl_perolehan asc","hrg_perolehan, residu, umur_ekonomis, datediff(now(),tgl_perolehan) as pemakaian","obj");
foreach ($aktiva as $row) {
    $bangunan[]=$row->hrg_perolehan;
    $nilai_ekonomis=$row->hrg_perolehan-$row->residu;
    $depresiasi_per_hari=$nilai_ekonomis/($row->umur_ekonomis*365);
    $depresiasi_bangunan[]=$depresiasi_per_hari*$row->pemakaian;
}

//INVENTARIS
$inventaris=array();
$depresiasi_inventaris=array();
$aktiva=$query->read("aktiva_tetap","WHERE kd_jenis='3' order by tgl_perolehan asc","hrg_perolehan, residu, umur_ekonomis, datediff(now(),tgl_perolehan) as pemakaian","obj");
foreach ($aktiva as $row) {
    $inventaris[]=$row->hrg_perolehan;
    $nilai_ekonomis=$row->hrg_perolehan-$row->residu;
    $depresiasi_per_hari=$nilai_ekonomis/($row->umur_ekonomis*365);
    $depresiasi_inventaris[]=$depresiasi_per_hari*$row->pemakaian;
}
//TANAH
$tanah=array();
$depresiasi_tanah=array();
$aktiva=$query->read("aktiva_tetap","WHERE kd_jenis='4' order by tgl_perolehan asc","hrg_perolehan, residu, umur_ekonomis, datediff(now(),tgl_perolehan) as pemakaian","obj");
foreach ($aktiva as $row) {
    $tanah[]=$row->hrg_perolehan;
    $nilai_ekonomis=$row->hrg_perolehan-$row->residu;
    $depresiasi_per_hari=$nilai_ekonomis/($row->umur_ekonomis*365);
    $depresiasi_tanah[]=$depresiasi_per_hari*$row->pemakaian;
}

//AKUMULASI PENYUSUTAN
$penyusutan=array_sum($depresiasi_mesin)+array_sum($depresiasi_bangunan)+array_sum($depresiasi_inventaris)+array_sum($depresiasi_tanah);
//JENIS AKTIVA
$aktiva_mesin=array_sum($mesin)-array_sum($depresiasi_mesin);
$aktiva_bangunan=array_sum($bangunan)-  array_sum($depresiasi_bangunan);
$aktiva_inventaris=array_sum($inventaris)-  array_sum($depresiasi_inventaris);
$aktiva_tanah=array_sum($tanah)-array_sum($depresiasi_tanah);
//TOTAL AKTIVA TETAP
$total_aktiva_tetap=$aktiva_bangunan+$aktiva_inventaris+$aktiva_mesin+$aktiva_tanah+$penyusutan;
$total_aktiva_lain=$content[10]+$content[11];



//TOTAL SIMPANAN POKOK
$result1=  $query->read("anggota","","sum(simpanan_pokok) as simpanan_pokok","obj");
foreach ($result1 as $row) {
    $total_pokok=$row->simpanan_pokok;
}
//TOTAL SIMPANAN WAJIB                    
$result2=  $query->read("simpanan_wajib","","sum(besar_simpanan) as besar_simpanan","obj");
foreach ($result2 as $row) {
    $total_wajib=$row->besar_simpanan;
}
//TOTAL SIMPANAN SUKARELA
$result3=  $query->read("simpanan_sukarela","","sum(besar_simpanan) as besar_simpanan","obj");
foreach ($result3 as $row) {
    $total_sukarela=$row->besar_simpanan;
}
//TOTAL SIMPANAN
$total_simpanan=$total_pokok+$total_wajib+$total_sukarela;

$angsuran=array();
$bunga=array();
//jangka panjang
$angsuran1=  $query->read("angsuran_jangka_panjang","","sum(besar_angsuran) as angsuran, sum(bunga) as bunga","obj");
foreach ($angsuran1 as $result1) {
        $bunga[]=$result1->bunga;
        $angsuran[]=$result1->angsuran;
}
//jangka pendek
$angsuran2=  $query->read("angsuran_jangka_pendek","","sum(besar_angsuran) as angsuran, sum(bunga) as bunga","obj");
foreach ($angsuran2 as $result2) { 
        $bunga[]=$result2->bunga;
        $angsuran[]=$result2->angsuran;
} 
//elektronik
$angsuran3=  $query->read("angsuran_elektronik","","sum(besar_angsuran) as angsuran, sum(bunga) as bunga","obj");
foreach ($angsuran3 as $result3) {
        $bunga[]=$result3->bunga;
        $angsuran[]=$result3->angsuran;
}
//sebrak
$angsuran4=  $query->read("angsuran_sebrak","","sum(besar_angsuran) as angsuran, sum(bunga) as bunga","obj");
foreach ($angsuran4 as $result4) {       
        $bunga[]=$result4->bunga;
        $angsuran[]=$result4->angsuran;
}
//TOTAL BUNGA
$total_bunga=array_sum($bunga);
//TOTAL ANGSURAN
$total_angsuran=array_sum($angsuran);

$piutang=array();
    //jangka panjang
    $piutang1=  $query->read("p_jangka_panjang","","sum(besar_pinjaman) as pinjaman","obj");
    foreach ($piutang1 as $row1) { 
         $piutang[]=$row1->pinjaman;
     }
     //jangka pendek
     $piutang2=  $query->read("p_jangka_pendek","","sum(besar_pinjaman) as pinjaman","obj");
     foreach ($piutang2 as $row2) {
         $piutang[]=$row2->pinjaman;
     }
     //elektronik
     $piutang3=  $query->read("p_elektronik","","sum(besar_pinjaman) as pinjaman","obj");
     foreach ($piutang3 as $row3) {
         $piutang[]=$row3->pinjaman;
     }
     //sebrak
     $piutang4=  $query->read("p_sebrak","","sum(besar_pinjaman) as pinjaman","obj");
     foreach ($piutang4 as $row4) {
        $piutang[]=$row4->pinjaman;
     }
//TOTAL HUTANG
$total_hutang=$content[12]+$content[13]+$content[14]+$content[15]+$content[16]+$content[17]+$content[18]+$content[19]+$content[20]+$content[21]+$content[22]+$content[23]+$content[24];
//TOTAL PINJAMAN
$total_pinjaman=  array_sum($piutang);
//TOTAL PIUTANG
$total_piutang=$total_pinjaman-$total_angsuran;
//KAS dan BANK
$kas_bank=($total_simpanan+$total_bunga+$saldo_awal+$total_hutang+$total_angsuran)-$total_aktiva_tetap-$total_pinjaman-$content[1]-$content[2]-$content[3]-$content[4]-$content[5]-$content[6]-$content[7]-$content[8]-$content[9]-$content[10]-$content[11];
//TOTAL AKTIVA LANCAR
$total_aktiva_lancar=$kas_bank+$total_piutang+$content[1]+$content[2]+$content[3]+$content[4]+$content[5]+$content[6]+$content[7];
//TOTAL INVESTASI JANGKA PANJANG
$total_inv_jangka_panjang=$content[8]+$content[9];
//TOTAL AKTIVA KESELURUHAN
$total_aktiva=$total_inv_jangka_panjang+$total_aktiva_tetap+$total_aktiva_lancar+$total_aktiva_lain;

//MODAL PENYERTAAN
$modal_penyertaan=$saldo_awal+$content[21];
//TOTAL KEWAJIBAN JANGKA PENDEK
$total_kew_pendek=$content[12]+$content[13]+$content[14]+$content[15]+$content[16]+$content[17]+$total_sukarela;
//TOTAL KEWAJIBAN JANGKA PANJANG
$total_kew_panjang=$content[18]+$content[19];
//TOTAL EKUITAS
$total_ekuitas=$modal_penyertaan+$content[20]+$content[22]+$content[23]+$content[24]+$total_wajib+$total_pokok;
//TOTAL KEWAJIBAN DAN EKUITAS
$total_kew_ekuitas=$total_kew_pendek+$total_kew_panjang+$total_ekuitas;
?>