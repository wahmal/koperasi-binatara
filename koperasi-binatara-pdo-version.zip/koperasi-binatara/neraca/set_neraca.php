<?php
$content=array();
$i=1;
$sql=$query->read("neraca_pembanding","order by id asc","","obj");  
foreach ($sql as $row) {
        $content[$i]=$row->content;
        $i++;    
}
?>
<script src="<?php echo site_path; ?>bootstrap/js/validate/jquery-1.7.1.min.js"></script>
<script src="<?php echo site_path; ?>bootstrap/js/validate/jquery.validate.min.js"></script>
<!--MODAL-->
<div id="myModal" class="modal hide fade">
    <div class="modal-body">Data Telah di perbarui !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<!--TAB 1-->
<form action="#" method="post" id="form_neraca">
    <style>
        #form_neraca input{width:150px;height:20px;}
    </style>
<table CELLSPACING="0" COLS="10" BORDER="0"width="95%" align="center">
	<tr>
		<td style="border-bottom: 3px solid #000000" HEIGHT="30"  colspan="10" align="justify"><h4>Neraca Lain - Lain</h4></td>
	</tr>
	<tr>
		<td HEIGHT="23" width="2%" >&nbsp;</td>
		<td  width="2%">&nbsp;</td>
		<td  width="30%">&nbsp;</td>
		<td  width="10%">&nbsp;</td>
		<td  width="1%">&nbsp;</td>
		<td width="1%" style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  width="2%">&nbsp;</td>
		<td width="2%" >&nbsp;</td>
		<td width="30%" >&nbsp;</td>
		<td  width="10%">&nbsp;</td>
	</tr>
	
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="CENTER" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td colspan=3 HEIGHT="19"  >AKTIVA LANCAR</td>
		<td  >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="CENTER" >&nbsp;</td>
		<td colspan=3  >KEWAJIBAN JANGKA PENDEK</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Kas dan Bank</td>
		<td align="RIGHT" >-</td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Usaha</td>
		<td align="RIGHT" ><label for="12"></label><input type="text" name="12" value="<?php echo $content[20]; ?>" id="12"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Investasi Jangka Pendek</td>
		<td align="RIGHT" ><label for="1"></label><input type="text" name="1" value="<?php echo $content[3]; ?>" id="1"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Bank</td>
		<td align="RIGHT" ><label for="13"></label><input type="text" name="13" value="<?php echo $content[21]; ?>" id="13"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Usaha</td>
		<td align="RIGHT" ><label for="2"></label><input type="text"name="2" value="<?php echo $content[4]; ?>" id="2"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Pajak</td>
		<td align="RIGHT" ><label for="14"></label><input name="14" type="text" value="<?php echo $content[22]; ?>" id="14"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Pinjaman Anggota</td>
		<td align="RIGHT" ><label for="4">-</td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Simpanan Anggota</td>
		<td align="RIGHT" >-</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Pinjaman Non-Anggota</td>
		<td align="RIGHT" ><label for="3"></label><input name="3" type="text" value="<?php echo $content[6]; ?>" id="3"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Dana Bagian SHU</td>
		<td align="RIGHT" ><label for="15"></label><input type="text" name="15" value="<?php echo $content[24]; ?>" id="15"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Piutang Lain-Lain</td>
		<td align="RIGHT" ><label for="4"></label><input name="4" type="text" value="<?php echo $content[7]; ?>" id="4"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Jangka Panjang Akan Jatuh Tempo</td>
		<td align="RIGHT" ><label for="16"></label><input name="16" type="text" value="<?php echo $content[25]; ?>" id="16"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Peny. Piutang Tak Tertagih</td>
		<td align="RIGHT" ><label for="5"></label><input name="5" type="text" value="<?php echo $content[8]; ?>" id="5"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Biaya Harus Dibayar</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" >
                    <label for="17"></label><input name="17" type="text" value="<?php echo $content[26]; ?>" id="17"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Persediaan</td>
		<td align="RIGHT" ><label for="6"></label><input name="6" type="text" value="<?php echo $content[9]; ?>" id="6"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Kewajiban jangka Pendek</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b>-</b></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Pendapatan Akan Diterima</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="7"></label><input name="7" type="text" value="<?php echo $content[10]; ?>" id="7"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Aktiva Lancar</td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b>
                        -
                    </b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  colspan="4">KEWAJIBAN JANGKA PANJANG</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Bank</td>
		<td align="RIGHT" ><label for="18"></label><input name="18" type="text" value="<?php echo $content[27]; ?>" id="18"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  colspan="5">INVESTASI JANGKA PANJANG</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Hutang Jangka Panjang Lainnya</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="19"></label><input name="19" type="text" value="<?php echo $content[28]; ?>" id="19"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Penyertaan Pada Koperasi</td>
		<td align="RIGHT" ><label for="8"></label><input name="8" type="text" value="<?php echo $content[11]; ?>" id="8"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Kewajiban Jangka Panjang</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b>
                        -</b></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Penyertaan Pada Non-Koperasi</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="9"></label><input name="9" type="text" value="<?php echo $content[12]; ?>" id="9"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Investasi Jangka Panjang</td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b>-</b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  colspan="4">EKUITAS</td>
	</tr>
	<tr>
		<td HEIGHT="19" align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Simpanan Wajib</td>
		<td align="RIGHT" >-</td>
	</tr>
	<tr>
		<td HEIGHT="19"  colspan="5">AKTIVA TETAP</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Simpanan Pokok</td>
		<td align="RIGHT" >-</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Tanah/Hak Atas Tanah</td>
		<td align="RIGHT" >-</td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Modal Penyetaraan Partisipasi Anggota</td>
		<td align="RIGHT" ><label for="20"></label><input name="20" type="text" value="<?php echo $content[31]; ?>" id="20"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Bangunan</td>
		<td align="RIGHT" ></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Modal Penyertaan</td>
		<td align="RIGHT" ><label for="21"></label><input name="21" type="text" value="<?php echo $content[32]; ?>" id="21"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Mesin</td>
		<td align="RIGHT" >-</td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Modal Sumbangan</td>
		<td align="RIGHT" ><label for="22"></label><input name="22" type="text" value="<?php echo $content[33]; ?>" id="22"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Inventaris</td>
		<td align="RIGHT" >-</td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >Cadangan</td>
		<td align="RIGHT" ><label for="23"></label><input name="23" type="text" value="<?php echo $content[34]; ?>" id="23"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Akumulasi Penyusutan</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" >-</td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td colspan=2  >SHU Belum Dibagi</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="24"></label><input name="24" type="text" value="<?php echo $content[35]; ?>" id="24"></td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Jumlah Aktiva Tetap</td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b>-</b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Ekuitas</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b>-</b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  colspan="5">AKTIVA LAIN-LAIN</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Aktiva tetap Dalam Konstruksi</td>
		<td align="RIGHT" ><label for="10"></label><input name="10" type="text" value="<?php echo $content[18]; ?>" id="10"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td colspan=2  >Beban Ditangguhkan</td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><label for="11"></label><input name="11" type="text" value="<?php echo $content[19]; ?>" id="11"></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >Jumlah Aktiva Lain-Lain</td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b>-</b></td>
		<td align="RIGHT" >&nbsp;</td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td HEIGHT="19" align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td align="CENTER" >&nbsp;</td>
		<td  >&nbsp;</td>
		<td style="border-left: 3px solid #000000"  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
		<td  >&nbsp;</td>
	</tr>
	<tr>
		<td colspan=3 HEIGHT="19"  ><b>JUMLAH AKTIVA</b></td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b>-</b></td>
		<td align="RIGHT" ><b>&nbsp;</b></td>
		<td style="border-left: 3px solid #000000" align="RIGHT" >&nbsp;</td>
		<td colspan=3  ><b>JUMLAH KEWAJIBAN &amp; EKUITAS</b></td>
		<td style="border-bottom: 1px solid #000000" align="RIGHT" ><b>-</b></td>
	</tr>
</table>
    <hr>
 <button type="submit" class="btn btn-success" id="tombol" >Update</button>
 <button type="reset" class="btn">Reset</button>   
</form>
<script>
var $s = jQuery.noConflict();           
$s(document).ready(function(){
    
 $s('#form_neraca').validate({
	    rules: {
              year1:{required:true},
	      1:{number:true},
              2:{number:true},
              3:{number:true},
              4:{number:true},
              5:{number:true},
              6:{number:true},
              7:{number:true},
              8:{number:true},
              9:{number:true},
              10:{number:true},
              12:{number:true},
              13:{number:true},
              14:{number:true},
              15:{number:true},
              16:{number:true},
              17:{number:true},
              18:{number:true},
              19:{number:true},
              20:{number:true},
              21:{number:true},
              22:{number:true},
              23:{number:true},
              24:{number:true}
	    },
            submitHandler: function() { 
                
                if(confirm("Yakin Melakukan Perubahan ? Seluruh Sistem Akan Terpengaruh.,"))
        {
            var year = $s("#year1").attr("value");
            var a1 = $s("#1").attr("value");
            var a2 = $s("#2").attr("value");
            var a3 = $s("#3").attr("value");
            var a4 = $s("#4").attr("value");
            var a5 = $s("#5").attr("value");
            var a6 = $s("#6").attr("value");
            var a7 = $s("#7").attr("value");
            var a8 = $s("#8").attr("value");
            var a9 = $s("#9").attr("value");
            var a10 = $s("#10").attr("value");
            var a11 = $s("#11").attr("value");
            var a12 = $s("#12").attr("value");
            var a13 = $s("#13").attr("value");
            var a14 = $s("#14").attr("value");
            var a15 = $s("#15").attr("value");
            var a16 = $s("#16").attr("value");
            var a17 = $s("#17").attr("value");
            var a18 = $s("#18").attr("value");
            var a19 = $s("#19").attr("value");
            var a20 = $s("#20").attr("value");
            var a21 = $s("#21").attr("value");
            var a22 = $s("#22").attr("value");
            var a23 = $s("#23").attr("value");
            var a24 = $s("#24").attr("value");
                    $s.ajax({
                        type: "GET", 
                        url: "<?php echo site_path; ?>neraca/update_neraca.php", 
                        data: "data=" + "karep:"+a1 +":"+ a2+":"+a3+":"+a4+":"+a5+":"+a6+":"+a7+":"+a8+":"+a9+":"+a10+":"+a11+":"+a12+":"+a13+":"+a14+":"+a15+":"+a16+":"+a17+":"+a18+":"+a19+":"+a20
                        +":"+a21+":"+a22+":"+a23+":"+a24,
                        complete: function(data){
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                            
                        }
                    });
        }
                    return false;
                }
});
});	
</script>