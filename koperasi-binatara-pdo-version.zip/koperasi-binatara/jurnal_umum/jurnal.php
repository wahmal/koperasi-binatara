<style type="text/css" title="currentStyle">
    @import "<?php echo site_path; ?>data_tables/media/css/demo_page.css";
    @import "<?php echo site_path; ?>data_tables/media/css/demo_table.css";
    @import "<?php echo site_path; ?>data_tables/table_tools/media/css/TableTools.css";
</style>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/media/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/table_tools/media/js/TableTools.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/table_tools/media/js/TableTools.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/table_tools/media/js/ZeroClipboard.js"></script>

<script type="text/javascript" charset="utf-8">
    var $j = jQuery.noConflict();
    $j(document).ready(function() {
            var oTable = $j('#example').dataTable( {
                    
                    "bProcessing": true,
                    "bServerSide": true,
                    "bAutoWidth": false,
                    "bDestroy" : true,
                    "bSort": false,
                    "bFilter":false,
                    "sAjaxSource": "<?php echo site_path; ?>jurnal_umum/jurnal_json.php",
                    "sPaginationType": "full_numbers",
                    "aoColumns": [ 
                        {"sClass": "center"},
                        {"sClass": "center"},
                        {"sClass": "left"},
                        {"sClass": "right"},
                        {"sClass": "right"}
                    ],
                    "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
                    "sDom": 'T<"clear"><"H"lfr>t<"F"ip>',
                    "oTableTools": {
			"sSwfPath": "<?php echo site_path; ?>data_tables/table_tools/media/swf/copy_csv_xls_pdf.swf",
                        "aButtons": [
				"xls",
				{
					"sExtends": "pdf",
					"sPdfOrientation": "landscape",
					"sPdfMessage": "Jurnal Umum"
				},
				"print" ]
                    }
     
            } );
            } );
</script>
<legend>Jurnal Umum</legend>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
                        <th>Kd Transaksi</th>
			<th>Tanggal</th>
			<th>Keterangan</th>
                        <th>Debet</th>
                        <th>Kredit</th>
		</tr>
	</thead>
<?php
$array1=array();
$array2=array();
$i=0;

// finish getting rows from the main query
$main_query=  $query->read("jurnal_umum","order by tgl asc","distinct(kd_transaksi) as kd_transaksi","obj");
//print_r($main_query);
foreach ($main_query as $row) 
{
    //echo $row->kd_transaksi;
    $x=0;
    $result1= $query->read("jurnal_umum","where kd_transaksi='".$row->kd_transaksi."'","sum(debit) as saldo","obj");
    //print_r($result1);
    foreach ($result1 as $data1) {
        $saldo=$data1->saldo;
    }

    $result2=  $query->read("jurnal_umum","where kd_transaksi='".$row->kd_transaksi."'","","obj");
    $banyak_data=  count($result2);
    foreach ($result2 as $data) {
        
        //debet
        $debet=$data->debit;
        if($debet!=0){
                $array1[]=$data->debit;;
            }
        
        ///kredit
        $kredit=$data->kredit;
        if($kredit!=0){
                $array2[]=$data->kredit;
            }
        
        //saldo
        if($banyak_data-$x==1){
            $z=$saldo;
            $conf=substr($row->kd_transaksi, 0,1);
            if(($conf=='D')||($conf=='E')||($conf=='F')||($conf=='G')||($conf=='L')){
                $mbuh=$i-$saldo;
                $z=$mbuh;
            }else{
                $mbuh=$i+$saldo;
                $z=$mbuh;
            }
        
        }
        $response['aaData'][] = $row;
        $i=$z+0;  
        $x++;
    }
            
     
}
?>
        <tfoot>
            <tr>
                <td colspan="3" class="center"><strong>TOTAL</strong></td>
                <td class="right"><strong><?php echo 'Rp '.number_format(array_sum($array1),0,'.','.'); ?></strong></td>
                <td class="right"><strong><?php echo 'Rp '.number_format(array_sum($array2),0,'.','.'); ?></strong></td>
                <!--<td class="right"><strong><?php echo 'Rp '.number_format($i,0,'.','.'); ?></strong></td>-->
                
            </tr>
        </tfoot>

</table>