config file on
-atribut/basic.php
-atribut/datatables_setting.php
-.htaccess