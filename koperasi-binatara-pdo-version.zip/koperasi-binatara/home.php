<?php 
session_start();

 if(empty($_SESSION)){
    include 'index.php';
 }else{
    include 'atribut/basic.php';
    include 'call_bootstrap.php';
 ?>

<html>
    <head>
        <link href='<?php echo site_path ?>atribut/images/simbol.png' rel='shortcut icon' type='image/x-icon'/>
        <title>Binatara</title>
        <script>
        function logout(){
            if(confirm("Anda Yakin ingin Keluar ?")){
                return true;
            }else{
                return false;
            }
        }
        </script>
        <style>
        label.valid {
        width: 24px;
        height: 24px;
        background: url("<?php echo site_path ?>bootstrap/img/valid.png") center center no-repeat;
        display: inline-block;
        text-indent: -9999px;
            }
        label.error {
        font-weight: bold;
        color: red;
        padding: 0px;
        margin: 0px;
        }
        #admin{font-weight: bold;padding-top: 0px;padding-bottom:0px;margin-top: 5px;margin-bottom:0px;}
        body{background-color: #ffffff;}
        #example_info{margin-top:10px;}
        .nama{color:#5FbF5F;}
        .nama_error{color:red;}
        .right{text-align: right;}
        .left{align: left;}
        .center{align: center;}
        option.nunggak{color:red;}
        .red{color:red;}
        .green{color:#5FbF5F;}
        .orange{color:#FF9000}
        .blue{color:#0050FF}
        .brown{color:#601A00}
        #ToolTables_example_0 span{cursor:progress;}
        td span{padding-left: 30px;}
        .nav li{padding: 0px;}
        
        </style>
    </head>
    <body>
        
<div class="container" style="width:900;">
            <div id="navbarExample" class="navbar navbar-inner" style="width:auto;">
             
                <div class="container" style="width:auto;height:10px;">
                   <a class="brand" href="#">Binatara</a>
                  <ul class="nav" style="width:auto;height:10px;">
                    <!--<a class="brand" href="#">Kooperasi</a>-->
                    <li class="<?php if(empty($_GET['nav'])){echo 'active';}?>"><a  href="<?php echo site_path ?>home/"><i class="icon-home"></i>&nbsp;Home</a></li>
                    <!--SIMPAN PINJAM-->
                    <li class="dropdown <?php if(($_GET['nav']==md5('anggota'))||($_GET['nav']==md5('simpanan_wajib'))||($_GET['nav']==md5('simpanan_sukarela'))||($_GET['nav']==md5('jangka_pendek'))||($_GET['nav']==md5('jangka_panjang'))||($_GET['nav']==md5('elektrik'))||($_GET['nav']==md5('sebrak'))||($_GET['nav']==md5('aktiva'))||($_GET['nav']==md5('jenis_aktiva_tetap'))||($_GET['nav']==md5('aktiva'))){echo 'active';}?>">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-file"></i> Simpan - Pinjam <b class="caret"></b></a>
                      <ul class="dropdown-menu">
                        <li><a  href="<?php echo site_path ?>home/<?php echo md5('anggota'); ?>">Daftar Anggota</a></li>
                        <a class="divider"></a>
                          <li class="dropdown-submenu">
                            <a tabhome="-1" href="#">Simpanan</a>
                            <ul class="dropdown-menu">
                              
                              <li><a  href="<?php echo site_path ?>home/<?php echo md5('simpanan_wajib'); ?>">Wajib</a></li>
                              <li><a  href="<?php echo site_path ?>home/<?php echo md5('simpanan_sukarela'); ?>">Sukarela</a></li>
                            </ul>
                          </li>
                          <li class="dropdown-submenu">
                            <a tabhome="-1" href="#">Pinjaman</a>
                            <ul class="dropdown-menu">
                              <li><a  href="<?php echo site_path ?>home/<?php echo md5('jangka_pendek'); ?>">Jangka Pendek</a></li>
                              <li><a  href="<?php echo site_path ?>home/<?php echo md5('jangka_panjang'); ?>">Jangka Panjang</a></li>
                              <li><a  href="<?php echo site_path ?>home/<?php echo md5('elektronik'); ?>">Elektronik</a></li>
                              <li><a  href="<?php echo site_path ?>home/<?php echo md5('sebrak'); ?>">Sebrak</a></li>
                            </ul>
                          </li>
                          <a class="divider"></a>
                          <li><a  href="<?php echo site_path ?>home/<?php echo md5('aktiva'); ?>">Aktiva Tetap</a></li>
                          <!--
                          <li><a  href="<?php //echo site_path ?>home/<?php // echo md5('jenis_aktiva_tetap'); ?>">Jenis Aktiva</a></li>
                          <a class="divider"></a>
                          <li><a  href="<?php //echo site_path ?>home/<?php // echo md5('ekuitas'); ?>">Ekuitas</a></li>
                          <a class="divider"></a>
                          <li><a  href="<?php //echo site_path ?>home/<?php //echo md5('hutang'); ?>">Hutang</a></li>-->
                          <a class="divider"></a>
                          <li class="dropdown-submenu">
                            <a tabhome="-1" href="#">Lain- Lain</a>
                            <ul class="dropdown-menu">
                              <li><a  href="<?php echo site_path ?>home/<?php echo md5('set_neraca'); ?>">Neraca</a></li>
                              <li><a  href="<?php echo site_path ?>home/<?php echo md5('set_shu'); ?>">Sisa Hasil Usaha</a></li>
                            </ul>
                          </li>
                      </ul>
                    </li>
                    
                    <li class="dropdown <?php if(($_GET['nav']==md5('daftar_piutang'))||($_GET['nav']==md5('daftar_bunga'))||($_GET['nav']==md5('jurnal_umum'))||($_GET['nav']==md5('buku_besar'))||($_GET['nav']==md5('daftar_simpanan_pokok'))||($_GET['nav']==md5('daftar_simpanan_wajib'))||($_GET['nav']==md5('daftar_simpanan_sukarela'))){echo 'active';}?>" >
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-print"></i> Laporan <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                          <li class="dropdown-submenu">
                            <a tabhome="-1" href="#">Daftar Simpanan</a>
                            <ul class="dropdown-menu">
                              <li><a  href="<?php echo site_path ?>home/<?php echo md5('daftar_simpanan_pokok'); ?>">Pokok</a></li>
                              <li><a  href="<?php echo site_path ?>home/<?php echo md5('daftar_simpanan_wajib'); ?>">Wajib</a></li>
                              <li><a  href="<?php echo site_path ?>home/<?php echo md5('daftar_simpanan_sukarela'); ?>">Sukarela</a></li>
                            </ul>
                          </li>
                          <li class="divider"></li>
                        <li><a  href="<?php echo site_path ?>home/<?php echo md5('daftar_piutang'); ?>">Daftar Piutang</a></li>
                        <li><a href="<?php echo site_path ?>home/<?php echo md5('daftar_bunga'); ?>">Daftar Bunga</a></li>
                        <li><a href="<?php echo site_path ?>home/<?php echo md5('jurnal_umum'); ?>">Jurnal Umum</a></li>
                        <li><a href="<?php echo site_path ?>home/<?php echo md5('buku_besar'); ?>">Buku Besar</a></li>
                        <li><a href="<?php echo site_path ?>home/<?php echo md5('neraca'); ?>">Neraca</a></li>
                        <li><a href="<?php echo site_path ?>home/<?php echo md5('hasil_usaha'); ?>">SHU</a></li>
                      </ul>
                    </li>
                    <li class="<?php if($_GET['nav']==md5('setting')){echo'active';}?>"><a  href="<?php echo site_path ?>home/<?php echo md5('setting'); ?>"><i class="icon-wrench"></i> Pengaturan</a></li>
                    
                    </ul>
                    
                    <form class="navbar-form pull-right" action="<?php echo site_path ?>logout/" onSubmit="return logout();">
                        <table border="0">
                            <tr>
                                <td><span id="admin" class="nav"><!--Hi <?php echo $_SESSION['user'];?> !  --></span></td>
                                <td><button type="submit" class="btn btn-danger" id="logout" >Log Out </button></td>
                            </tr>
                        </table>
                        
                      </form>
                 </div>
         
    </div>
    <?php
    if(!empty($_GET['nav'])){
    $token=$_GET['nav'];
    }else{
        $token='home';
    }
    switch ($token){
        case 'home':include'main.php';break;
        case md5('anggota'):include'anggota/daftar_anggota.php';break;

        case md5('simpanan_wajib'):include'simpanan_wajib/daftar_simpanan.php';break;
        case md5('simpanan_sukarela'):include'simpanan_sukarela/daftar_simpanan.php';break;
        
        case md5('jenis_aktiva_tetap'):include'aktiva_tetap/jenis_aktiva_tetap.php';break;
        case md5('aktiva'):include'aktiva_tetap/aktiva_tetap.php';break;
        //PINJAMAN
        case md5('jangka_pendek'):include'jangka_pendek/daftar_pinjaman.php';break;
        case md5('angsuran_jangka_pendek'):include'jangka_pendek/daftar_angsuran.php';break;
        
        case md5('jangka_panjang'):include'jangka_panjang/daftar_pinjaman.php';break;
        case md5('angsuran_jangka_panjang'):include'jangka_panjang/daftar_angsuran.php';break;
        
        case md5('elektronik'):include'elektronik/daftar_pinjaman.php';break;
        case md5('angsuran_elektronik'):include'elektronik/daftar_angsuran.php';break;
        
        case md5('sebrak'):include'sebrak/daftar_pinjaman.php';break;
        case md5('angsuran_sebrak'):include'sebrak/daftar_angsuran.php';break;
        //SETTING
        case md5('setting'):include'setting/setting.php';break;
        //EKUITAS
        case md5('ekuitas'):include'ekuitas/ekuitas.php';break;
        //LAPORAN
        case md5('daftar_simpanan_pokok'):include'anggota/daftar_simpanan_pokok.php';break;
        case md5('daftar_simpanan_wajib'):include'simpanan_wajib/daftar_simpanan_wajib.php';break;
        case md5('daftar_simpanan_sukarela'):include'simpanan_sukarela/daftar_simpanan_sukarela.php';break;
        case md5('daftar_piutang'):include'piutang/daftar_piutang.php';break;
        case md5('daftar_bunga'):include'bunga/daftar_bunga.php';break;
        case md5('jurnal_umum'):include'jurnal_umum/jurnal.php';break;
        case md5('buku_besar'):include'buku_besar/buku_besar.php';break;
        case md5('neraca'):include'neraca/neraca.php';break;
        case md5('hasil_usaha'):include'SHU/shu.php';break;
        case md5('hutang'):include'hutang/hutang.php';break;
        
        case md5('set_neraca'):include'neraca/set_neraca.php';break;
        case md5('set_shu'):include'SHU/set_shu.php';break;
    
    }
    ?>
    
    
    

</div>
<div class="container" style="width:900;">
<hr>
<footer>
<span>&copy; Binatara <?php echo date('Y');?></span><span class="pull-right">Developed by : <a href="http://www.facebook.com/wahyu.malakian?ref=tn_tnmn" target="_new">Someone</a></span>
</footer>
<div class="wait">loading..,</div>
<style>
    .wait{
            width:100%;
            height:100%;
            position:fixed;
            position:absolute;
            top:0px;
            right:0px;
            bottom:0px;
            left:0px;
            z-index:999999;
            background:#FFFFFF url("<?php echo site_path ?>atribut/images/loading.gif") no-repeat center;
            color:transparent;
            text-indent:-99999px;
            opacity:0.6;
            filter:alpha(opacity=60);
          }
</style>
<script>
    var $j = jQuery.noConflict();
        $j(window).bind("load", function() {
        $j('.wait').fadeOut();
        });
</script>

</div>        
</body>
</html>
<!--
-validasi kas
-jurnal tanpa saldo
-SHU labarugi non anggota
-->
<?php } ?>