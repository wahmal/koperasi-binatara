
<div class="row-fluid">
    <div class="span7">
<div id="myCarousel" class="carousel slide" style="width:500px;">
  <!-- Carousel items -->
  <div class="carousel-inner" style="width:500px;">

<?php
$i=0;
$carousel=$query->read('carousel','order by order_id asc');
foreach($carousel as $row){
    if($i==0){
        echo'<div class="active item"><img src="'.site_path.'img/'.$row['img'].'">';
        if(!empty($row['ket'])){
            echo'<div class="carousel-caption">
                  <p>'.$row['ket'].'</p>
                </div>';}
           echo' </div>';
        

    }else{
        
        echo'<div class="item"><img src="'.site_path.'img/'.$row['img'].'">';
        if(!empty($row['ket'])){
                echo'<div class="carousel-caption">
                  <p>'.$row['ket'].'</p>
                </div>';}
            echo'</div>';
    }
    $i++;
}
?>
  </div>
  <!-- Carousel nav -->
  <a class="carousel-control left" href="#myCarousel" data-slide="prev">&lsaquo;</a>
  <a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a>
</div>

</div>
  <div class="span5">
      <div >
    <h3 align="center">Selamat Datang di Sistem Informasi Koperasi Binatara</h3>
    <hr>
    <p>Sebelum mulai bekerja, pastikan tanggal di komputer anda sesuai dengan tanggal saat ini agar tidak terjadi 
    kekeliruan dalam mengolah data..,</p>
</div>
  </div>
</div>