
<!--DATA TABLES-->
<legend>Kartu Piutang</legend>
<style type="text/css" title="currentStyle">
    @import "data_tables/media/css/demo_page.css";
    @import "data_tables/media/css/demo_table.css";
    #example_info{margin-top:10px;}
    .nama{color:#5FbF5F;}
    .right{text-align: right;}
.left{text-align: left;}
.center{text-align: center;}
</style>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.jeditable.js"></script>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.dataTables.editable.js"></script>
<script type="text/javascript" charset="utf-8">
    var $j = jQuery.noConflict();
    $j(document).ready(function() {
            var oTable = $j('#example').dataTable( {
                    
                    "bProcessing": true,
                    "bServerSide": true,
                    "bAutoWidth": false,
                     "sScrollX": "100%",
		"sScrollXInner": "120%",
		"bScrollCollapse": true,
                    "sAjaxSource": "elektronik/angsuran_json.php?",
                    "sPaginationType": "full_numbers",
                    "aoColumns": [ 
                        {"sClass": "center"},
                        {"sClass": "center"},
                        {"sClass": "right"},
                        {"sClass": "right"},
                        {"sClass": "center"},
                        {"sClass": "right"},
                        {"sClass": "right"},
                        {"sClass": "center"}
                    ],
                    "fnServerData": function ( sSource, aoData, fnCallback ) {
			aoData.push( { "name": "id_pinjaman", "value": $j("#id_pinjaman").val() } );
			$j.getJSON( sSource, aoData, function (json) { 
				fnCallback(json)
			} )}
            } );
            } );
</script>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
			<th rowspan="2">Kode</th>
			<th rowspan="2">Tanggal</th>
                        <th rowspan="2">Pinjaman</th>
                        <th colspan="3">Angsuran</th>
                        <th rowspan="2">Saldo Pinjaman</th>
                        <th rowspan="2">Ket.</th>
		</tr>
                <tr width="50px">
                    <th>Pokok</th><th>Bunga</th><th>Total Angsuran</th>
                </tr>
	</thead>

</table>