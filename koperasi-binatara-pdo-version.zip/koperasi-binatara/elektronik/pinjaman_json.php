<?php
/*
 * Script:    DataTables server-side script for PHP and MySQL
 * Copyright: 2012 - John Becker, Beckersoft, Inc.
 * Copyright: 2010 - Allan Jardine
 * License:   GPL v2 or BSD (3-point)
 */
include('../atribut/datatables_setting.php');
  
class TableData {
 
    private $_db;
    protected $con;

    public function __construct() {

        global $conn;
        $this->con =& $conn;
        try {
            $this->_db = new PDO('mysql:host='.$this->con['host'].';dbname='.$this->con['database'], $this->con['user'], $this->con['passwd'], array(PDO::ATTR_PERSISTENT => true));
        } catch (PDOException $e) {
            error_log("Failed to connect to database: ".$e->getMessage());
        }       
        
    }
    public function read($table, $where = "", $fieldName = "",$type="array") {
          $arrResult = array();
          $fieldStr = "";
          if (empty($fieldName) ) {
            $fieldStr = "*  ";
          }
          elseif (is_array($fieldName) ){
            foreach ($fieldName as $field) {
              $fieldStr .= $field.", ";
            }
          }
          else {  
              $fieldStr .= $fieldName.", ";
          }
          $fields = substr($fieldStr, 0, -2);

        //echo
          $sql = "SELECT ".$fields." FROM ".$table." ".$where;
          //echo $sql;
          $query = $this->_db->query($sql);

          if($type=='array'){
            while($data = $query->fetch(PDO::FETCH_ASSOC)){
                array_push($arrResult, $data);
            }
          }
          if($type=='obj'){
            while($data = $query->fetch(PDO::FETCH_OBJ)){
                array_push($arrResult, $data);
            }
          }
          return $arrResult;
    }
    public function get($table, $index_column, $columns, $alias, $join=null) {
        // Paging
        $sLimit = "";
        if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' ) {
            $sLimit = "LIMIT ".intval( $_GET['iDisplayStart'] ).", ".intval( $_GET['iDisplayLength'] );
        }
        
        // Ordering
        $sOrder = "";
        if ( isset( $_GET['iSortCol_0'] ) ) {
            $sOrder = "ORDER BY  ";
            for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ ) {
                if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" ) {
                    $sortDir = (strcasecmp($_GET['sSortDir_'.$i], 'ASC') == 0) ? 'ASC' : 'DESC';
                    $sOrder .= "".$columns[ intval( $_GET['iSortCol_'.$i] ) ]." ". $sortDir .", ";
                }
            }
            
            $sOrder = substr_replace( $sOrder, "", -2 );
            if ( $sOrder == "ORDER BY" ) {
                $sOrder = "";
            }
        }
        
        /* 
         * Filtering
         * NOTE this does not match the built-in DataTables filtering which does it
         * word by word on any field. It's possible to do here, but concerned about efficiency
         * on very large tables, and MySQL's regex functionality is very limited
         */
        $sWhere = "";
        if ( isset($_GET['sSearch']) && $_GET['sSearch'] != "" ) {
            $sWhere = "WHERE (";
            for ( $i=0 ; $i<count($columns) ; $i++ ) {
                if ( isset($_GET['bSearchable_'.$i]) && $_GET['bSearchable_'.$i] == "true" ) {
                    $sWhere .= "`".$columns[$i]."` LIKE :search OR ";
                }
            }
            $sWhere = substr_replace( $sWhere, "", -3 );
            $sWhere .= ')';
        }
        
        // Individual column filtering
        for ( $i=0 ; $i<count($columns) ; $i++ ) {
            if ( isset($_GET['bSearchable_'.$i]) && $_GET['bSearchable_'.$i] == "true" && $_GET['sSearch_'.$i] != '' ) {
                if ( $sWhere == "" ) {
                    $sWhere = "WHERE ";
                }
                else {
                    $sWhere .= " AND ";
                }
                $sWhere .= "`".$columns[$i]."` LIKE :search".$i." ";
            }
        }
        
        // SQL queries get data to display
        $sQuery = "SELECT SQL_CALC_FOUND_ROWS ".str_replace(" , ", " ", implode(", ", $columns))." FROM ".$table." ".$join." ".$sWhere." ".$sOrder." ".$sLimit;

        //echo $sQuery;
        $statement = $this->_db->prepare($sQuery);
        
        // Bind parameters
        if ( isset($_GET['sSearch']) && $_GET['sSearch'] != "" ) {
            $statement->bindValue(':search', '%'.$_GET['sSearch'].'%', PDO::PARAM_STR);
        }
        for ( $i=0 ; $i<count($columns) ; $i++ ) {
            if ( isset($_GET['bSearchable_'.$i]) && $_GET['bSearchable_'.$i] == "true" && $_GET['sSearch_'.$i] != '' ) {
                $statement->bindValue(':search'.$i, '%'.$_GET['sSearch_'.$i].'%', PDO::PARAM_STR);
            }
        }
        $statement->execute();
        $rResult = $statement->fetchAll();
        
        $iFilteredTotal = current($this->_db->query('SELECT FOUND_ROWS()')->fetch());
        
        // Get total number of rows in table
        $sQuery = "SELECT COUNT(".$index_column.") FROM ".$table."";
        //echo $sQuery;
        $iTotal = current($this->_db->query($sQuery)->fetch());
        
        // Output
        $output = array(
            "sEcho" => intval($_GET['sEcho']),
            "iTotalRecords" => $iTotal,
            "iTotalDisplayRecords" => $iFilteredTotal,
            "aaData" => array()
        );
        

        //get config
 



        // Return array of values
        $columns=$alias;
        foreach($rResult as $aRow) {

            //set date n hidden id
            $row[0]=null;
            $row[1]=$aRow[1];

            $banyak= $this->read("angsuran_elektronik","where kd_elektronik='".$aRow[0]."'","besar_angsuran","obj");

            $cek=  $this->read("angsuran_elektronik","where kd_elektronik='".$aRow[0]."'","sum(besar_angsuran) as besar_angsuran","obj");
            $total_angsuran=$cek[0]->besar_angsuran;

            $row[4]='Rp '.number_format($total_angsuran,0,'.','.');
            //status pembayaran
            if(empty($banyak)){
                $row[5]="<span class='red'>Belum di Angsur</span>";
            }else{
                if($total_angsuran<$aRow[3]){
                    $row[5]="<span class='orange'>Belum lunas</span>";
                }elseif($total_angsuran==$aRow[3]){
                    $row[5]="<span class='green'>Lunas</span>";
                }elseif($total_angsuran>$aRow[3]){
                    $row[5]="<span class='blue'>Lebih Bayar</span>";
                }else{
                    $row[5]="<span class='brown'>Tidak diketahui</span>";
                }
            }
            //cicilan
            $cicilan=$aRow[2];
            $row[2]=$aRow[2]." x";
            //edit delete
            if(empty($banyak)){
                $row[6] ="<a title='ANNGSURAN' href='".site_path."home/".md5('angsuran_elektronik')."/".md5($aRow[0])."'>Angsuran</a>
                &nbsp;|&nbsp;<a title='DELETE' class='delbutton' href='#'id='".$aRow[0]."'><i class='icon-search icon-trash'></i></a>
                &nbsp;&nbsp;&nbsp;<a class='editbutton' title='EDIT' kd_pinjam='".md5($aRow[0])."'tgl_pinjam='".$aRow[1]."' 
                cicilan='".$cicilan."' besar_pinjaman='".$aRow[3]."'href='#'><i class='icon-search icon-edit'></i></a>";
            }else{
                $row[6] ="<a title='ANNGSURAN' href='".site_path."home/".md5('angsuran_elektronik')."/".md5($aRow[0])."'>Angsuran</a>
                &nbsp;|&nbsp;<a title='DELETE' class='delbutton' href='#'id='".$aRow[0]."'><i class='icon-trash'></i></a>
                &nbsp;&nbsp;&nbsp;<a href='#' class='disabled' onClick='return falsebutton()' ><i class='icon-edit'></i></a>";
            }
            $row[3]='Rp '.number_format($aRow[3],0,'.','.');
            $output['aaData'][] = $row;
        }
        
        echo json_encode( $output );
    }
}
header('Pragma: no-cache');
header('Cache-Control: no-store, no-cache, must-revalidate');
// Create instance of TableData class
$table_data = new TableData();
// Get the data





 if(isset($_GET['id_anggota'])){
    $joins = "JOIN anggota b ON a.id_anggota = b.id_anggota where a.id_anggota='".$_GET['id_anggota']."'";
 }else{
    $joins = "JOIN anggota b ON a.id_anggota = b.id_anggota";
 } 

$table_data->get(
    'p_elektronik a', 
    'a.kd_elektronik', 
    array("a.kd_elektronik","a.tgl_pinjam","a.cicilan","a.besar_pinjaman"),
    array("kd_elektronik","tgl_pinjam","cicilan","besar_pinjaman"),
    $joins
    );

//KHUSUS QUERY JOIN ` gw hapus
/*
 * Alternatively, you may want to use the same class for several differnt tables for different pages.
 * By adding something similar to the following to your .htaccess file you can control this a little more...
 *
 * RewriteRule ^pagename/data/?$ data.php?_page=PAGENAME [L,NC,QSA]
 *
 
switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        if (isset($_REQUEST['_page'])) {
            if($_REQUEST['_page'] === 'PAGENAME') {
                $table_data->get('table_name', 'index_column', array('column1', 'column2', 'columnN'));
            }
        }
        break;
    default:
        header('HTTP/1.1 400 Bad Request');
}
*/
?>