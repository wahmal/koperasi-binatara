var $s = jQuery.noConflict();           
$s(document).ready(function(){
    
        
$s('.delbutton').live("click", function() {
        var id = $s(this).attr("id");
        var dataString = 'id='+ id ;
        var parent = $s(this).parent();
        if(confirm("Yakin Menghapus Pinjaman Ini ? Data angsuran akan ikut terhapus..,"))
        {
        $s.ajax({
           type: "POST",
           url: "elektronik/delete.php",
           data: dataString,
           cache: false,

           beforeSend: function()
           {
           parent.animate({'backgroundColor':'#fb6c6c'},300).animate({ opacity: 0.35 }, "slow");
           }, 
           success: function()
           {
               parent.slideUp('slow', function() {$s(this).remove();});
                    $("#terhapus").bind("show", function() {
                    $("#terhapus a.btn").click(function(e) {
                        console.log("button pressed: "+$(this).html());
                        $("#terhapus").modal('hide');
                    });
                    });
                    $("#terhapus").bind("hide", function() {
                    $("#terhapus a.btn").unbind();
                    });
                    $("#terhapus").modal({
                    "backdrop"  : "static",
                    "keyboard"  : true,
                    "show"      : true    
                    });
                    
                    var id_anggota = $s("#id_anggota").val(); 
                    $s.ajax({ 
                        url: "elektronik/data_pinjaman.php", 
                        data: "id_anggota="+id_anggota, 
                        cache: false, 
                        success: function(msg){ 
                            $("#data").html(msg); 
                        } 
                    }); 
                    
          }
          
          });
          }
	  return false;
});
    

$s('#form_angsuran').validate({
	    rules: {
	      tgl: {
	        required: true
	      },
	      besar_angsuran: {
                number:true,
	        required: true
	      },
	      bunga: {
                number:true,
	        required: true
	      },
	      bayar: {
                number:true,
	        required: true
	      },
	      total: {
                number:true,
	        required: true
	      },
	      kembalian: {
                  min:0,
                number:true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
                var id_angsuran = $s("#id_angsuran").attr("value");
                id_anggota  = $s("#id_anggota").attr("value");
                id_pinjaman  = $s("#id_pinjaman").attr("value");
                tgl  = $s("#tgl").attr("value");
                besar_angsuran  = $s("#besar_angsuran").attr("value");
                bunga = $s("#bunga").attr("value");
                  

                
                if(id_angsuran==""){
                    $s.ajax({
                        type: "GET", 
                        url: "elektronik/simpan_angsuran.php", 
                        data: "id_pinjaman=" + id_pinjaman + "&besar_angsuran=" + besar_angsuran + "&tgl=" + tgl +"&bunga="+bunga,
                        complete: function(data){
                            $s("#tgl").val('');
                            $s("#bayar").val('');
                            $s("#kembalian").val('');
                            $s('#data2').load('elektronik/data_angsuran.php');
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                                location.reload();
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                            
                        }
                    });
                    
                    return false;
                    
                }else{
                    $s.ajax({
                        type: "GET", 
                        url: "elektronik/update.php", 
                        data: "id_anggota=" + id_anggota + "&byr=" + byr + "&tgl=" + tgl + "&kd_elektronik=" + kd_elektronik + "&cicilan=" + cicilan,
                        complete: function(data){
                            //$s("#id_pinjaman").val('');
                            $s("#tgl").val('');
                            $s("#byr").val('');
                            $s("#kd_elektronik").val('');
                            $s("#cicilan").val('');
                            $s('#data').load('elektronik/data_pinjaman.php');
                            //konfirmasi
                            $("#modalUpdate").bind("show", function() {
                            $("#modalUpdate a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#modalUpdate").modal('hide');
                            });
                            });
                            $("#modalUpdate").bind("hide", function() {
                            $("#modalUpdate a.btn").unbind();
                            });
                            $("#modalUpdate").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true   
                            });
                            var id_anggota = $s("#id_anggota").val();  
                            $s.ajax({ 
                                url: "elektronik/data_pinjaman.php", 
                                data: "id_anggota="+id_anggota, 
                                cache: false, 
                                success: function(msg){ 
                                    $("#data").html(msg); 
                                } 
                            }); 
                        }
                    });
                    return false;
                }
    }  
});
});
        

		