<?php
$id=$_POST['id'];
include '../atribut/basic.php';


$res=$query->read("p_elektronik","where kd_elektronik='".$id."'","kd_transaksi","obj");
foreach ($res as $row) {
    $kd_transaksi=$row->kd_transaksi;
}

$res2=$query->read("angsuran_elektronik","where kd_elektronik='".$id."' limit 1","kd_transaksi","obj");
foreach ($res2 as $row1) {
    $kd_transaksi1=$row1->kd_transaksi;
}

$delete=$query->delete("jurnal_umum","kd_transaksi",array($kd_transaksi));
$delete1=$query->delete("jurnal_umum","kd_transaksi",array($kd_transaksi1));
$delete2=$query->delete("angsuran_elektronik","kd_elektronik",array($id));
$delete3=$query->delete("p_elektronik","kd_elektronik",array($id));




?>