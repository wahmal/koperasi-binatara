
<style>
    #form_lunas{display:none;}
    #status{position: relative;color:#5FbF5F;margin: 20px auto;}
</style>


<!--MODAL-->
<div id="myModal" class="modal hide fade">
    <div class="modal-body">Data Berhasil Tersimpan !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="modalUpdate" class="modal hide fade">
    <div class="modal-body">Data Telah Berhasil di Update !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="terhapus" class="modal hide fade">
    <div class="modal-body">Data Telah Terhapus !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>


<?php
include'setting.php';

if(!empty($_GET['id_pinjaman'])){
   $id_pinjaman=$_GET['id_pinjaman'];
    //data anggota, pinjaman dan angsuran
    $result= $query->read(
        "anggota a",
        "JOIN p_elektronik b ON a.id_anggota=b.id_anggota where md5(b.kd_elektronik)='".$id_pinjaman."'",
        "a.id_anggota as id_anggota, a.nama as nama,b.tgl_pinjam as tgl_pinjam, b.cicilan as cicilan, b.besar_pinjaman as besar_pinjaman");

        foreach ($result as $row) {
            $tgl_pinjam=$row['tgl_pinjam'];
            $id_anggota=$row['id_anggota'];
            $nama=$row['nama'];
            $cicilan=$row['cicilan'];
            
            $pinjam=$row['besar_pinjaman'];
            $besar_pinjaman='Rp '.number_format($row['besar_pinjaman'],0,'.','.');
            $angsuran=$row['besar_pinjaman']/$cicilan;
            
        }
        
        
        $bunga=($bunga_jangka_elektronik*$angsuran)/100;
        $total=$bunga+$angsuran;
        
    //status lunas    
    $cek_lunas=$query->read("angsuran_elektronik","where md5(kd_elektronik)='".$id_pinjaman."'","sum(besar_angsuran) as total_angsuran","obj");
        foreach ($cek_lunas as $row1) {
            $jtatus=$row1->total_angsuran;
        }
        if($jtatus==$pinjam){
            $disabled='form_lunas';
            $msg='LUNAS';
        }else{
            $disabled='form_angsuran'; 
            $msg='';
        }
        $sisa=$pinjam-$jtatus;

     //cek pelunasan
     $cek_cicil=$query->read("angsuran_elektronik","where md5(kd_elektronik)='".$id_pinjaman."'");
     $pelunasan=  count($cek_cicil);
     $jumlah_cicilan=$cicilan-$pelunasan;
}
?>
<legend>Form Angsuran - Pinjaman Elektronik </legend>
<div class="row">
    <div class="span5">
        <table cellpadding="2">
            <tr>
                <td>Nama</td><td> : </td><td><?php echo $nama; ?></td>
            </tr>
            <tr>
                <td>Id Anggota</td><td> : </td><td><?php echo $id_anggota; ?></td>
            </tr>
            <tr>
                <td>Tanggal Pinjam</td><td> : </td><td><?php echo $tgl_pinjam; ?></td>
            </tr>
            <tr>
                <td>Cicilan</td><td> : </td><td><?php echo $cicilan." x"; ?></td>
            </tr>
            <tr>
                <td>Besar Pinjaman</td><td> : </td><td><?php echo $besar_pinjaman; ?></td>
            </tr>
        </table>
    </div>
    <div class="span4">
        <h1 id="status"><?php echo $msg;?></h1>
    </div>
</div>
<div id="data1">
<form action="#" method="post" id="<?php echo $disabled; ?>" class="form-horizontal">
<div class="form-actions" style="padding-left:0px;padding-bottom:0px;margin-bottom: 0px;margin-left: 0px">
        <table border="0">
            <tr>
                <td>
                    <input type="hidden" name="id_angsuran" id="id_angsuran" value="">
                    <input type="hidden" name="id_pinjaman" id="id_pinjaman" value="<?php echo $id_pinjaman;?>">
                    
                    <div class="control-group">
                      <label class="control-label" for="telepon">Angsuran / Bulan :</label>
                      <div class="controls">
                        <input type="text" name="besar_angsuran" id="besar_angsuran" value="<?php echo $angsuran; ?>" readonly="true">
                      </div>
                  </div>  
                </td>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="tgl">Tanggal Bayar :</label>
                      <div class="controls">
                        <div class="input-append date" id="datepicker" data-date="<?php echo date("Y-m-d");?>" data-date-format="yyyy-mm-dd">
                            <span class="add-on"><i class="icon-th"></i></span>
                            <input class="span2" size="16" type="text" id="tgl" name="tgl" placeholder="yyyy-mm-dd" readonly="true" value="">
                        </div>
                      </div>
                    </div>
                    
                   
               </td>
            </tr>
            <tr>
                <td>
                   <div class="control-group">
                      <label class="control-label" for="bunga">Bunga <?php echo $bunga_elektronik." %";?> :</label>
                      <div class="controls">
                        <input type="text" name="bunga" id="bunga" value="<?php echo $bunga; ?>" readonly="true">
                      </div>
                  </div>   
                    
                </td>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="bayar">Bayar :</label>
                      <div class="controls">
                        <input type="text" name="bayar" id="bayar">
                      </div>
                  </div>  
                    
                     
               </td>
            </tr>
            <tr>
                <td>
                   <div class="control-group">
                      <label class="control-label" for="total">Total :</label>
                      <div class="controls">
                        <input type="text" name="total" id="total" value="<?php echo $total; ?>" readonly="true">
                      </div>
                  </div>  
                </td>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="kembalian">Kembalian :</label>
                      <div class="controls">
                        <input type="text" name="kembalian" id="kembalian" readonly="true">
                      </div>
                  </div> 
               </td>
            </tr>
            <tr>
                <td>
                    <?php if($jumlah_cicilan>1){?>
                  <div class="control-group">
                        <label class="checkbox" style="margin-left:180px;">
                        <input type="checkbox" id="chk"> Pelunasan
                        </label>
                    </div> 
                    <?php }else{echo '&nbsp;';}?>
                </td>
                <td>
                    &nbsp;
                </td>
            </tr>
        </table>   
    </div>
    <div style="background:#FFF;margin-left: 0px;padding-top: 5px;">
<button type="submit" class="btn btn-success">Angsur</button>
<button type="reset" class="btn">Reset</button>
    </div>
</form>
</div>
<script>
$("#bayar").keyup( function(){
    bayar = $("#bayar").attr("value");
     total = $("#total").attr("value");
    kembali = bayar - total;
    $("#kembalian").val(kembali);
});

$(":checkbox").click(function(){
    var $this = $(this); 
    if ($this.is(':checked')) {
        lunas=<?php echo $sisa;?>;
        bunga_lunas=<?php echo ($bunga_elektronik*$sisa)/100;?>;
        
        $("#besar_angsuran").val(lunas);
        $("#bunga").val(bunga_lunas);
        $("#total").val(bunga_lunas+lunas);
    } else {
        $("#form_angsuran")[0].reset();
    }    
});
</script>
<script src="<?php echo site_path; ?>bootstrap/datepicker/tanggal.js"></script>
<!--DATA TABLES-->
<legend>Kartu Piutang</legend>
<style type="text/css" title="currentStyle">
    @import "<?php echo site_path; ?>data_tables/media/css/demo_page.css";
    @import "<?php echo site_path; ?>data_tables/media/css/demo_table.css";
    #example_info{margin-top:10px;}
    .nama{color:#5FbF5F;}
    .right{text-align: right;}
.left{text-align: left;}
.center{text-align: center;}
</style>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/media/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/media/js/jquery.dataTables.min.js"></script>
<script src="<?php echo site_path; ?>bootstrap/js/validate/jquery.validate.min.js"></script>
<script type="text/javascript" charset="utf-8">
    var $j = jQuery.noConflict();
    $j(document).ready(function() {
            var oTable = $j('#example').dataTable( {
                    
                    "bProcessing": true,
                    "bServerSide": true,
                    "bAutoWidth": false,
                     "sScrollX": "100%",
		"sScrollXInner": "120%",
		"bScrollCollapse": true,
                    "sAjaxSource": "<?php echo site_path; ?>elektronik/angsuran_json.php?",
                    "sPaginationType": "full_numbers",
                    "aoColumns": [ 
                        {"sClass": "center"},
                        {"sClass": "center"},
                        {"sClass": "right"},
                        {"sClass": "right"},
                        {"sClass": "center"},
                        {"sClass": "right"},
                        {"sClass": "right"},
                        {"sClass": "center"},
                        {"sClass": "center"}
                    ],
                    "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
                    "fnServerData": function ( sSource, aoData, fnCallback ) {
			aoData.push( { "name": "id_pinjaman", "value": $j("#id_pinjaman").val() } );
			$j.getJSON( sSource, aoData, function (json) { 
				fnCallback(json)
			} )}
            } );
    
$j('.delete_angsuran').live("click", function() {
        var id_cuk = $j(this).attr("id");
        if(confirm("Yakin Menghapus Pinjaman Ini ? Data angsuran akan ikut terhapus..,"))
        {
            
        $j.getJSON ('<?php echo site_path ?>elektronik/delete_angsuran.php',{id:id_cuk}, function (json) {
                    $("#terhapus").bind("show", function() {
                    $("#terhapus a.btn").click(function(e) {
                        console.log("button pressed: "+$(this).html());
                        $("#terhapus").modal('hide');
                        location.reload();
                    });
                    });
                    $("#terhapus").bind("hide", function() {
                    $("#terhapus a.btn").unbind();
                    });
                    $("#terhapus").modal({
                    "backdrop"  : "static",
                    "keyboard"  : true,
                    "show"      : true    
                    });
                
	}); 
          }
	  return false;
});
    

$j('#form_angsuran').validate({
	    rules: {
	      tgl: {
	        required: true
	      },
	      besar_angsuran: {
                number:true,
	        required: true
	      },
	      bunga: {
                number:true,
	        required: true
	      },
	      bayar: {
                number:true,
	        required: true
	      },
	      total: {
                number:true,
	        required: true
	      },
	      kembalian: {
                  min:0,
                number:true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
                var id_angsuran = $j("#id_angsuran").attr("value");
                id_anggota  = $j("#id_anggota").attr("value");
                id_pinjaman  = $j("#id_pinjaman").attr("value");
                tgl  = $j("#tgl").attr("value");
                besar_angsuran  = $j("#besar_angsuran").attr("value");
                bunga = $j("#bunga").attr("value");
                
                $j.getJSON ('<?php echo site_path ?>elektronik/simpan_angsuran.php',{
                    id_pinjaman:id_pinjaman,
                    besar_angsuran:besar_angsuran,
                    tgl:tgl,
                    bunga:bunga
                }, function (json) {
                    $j("#tgl").val('');
                    $j("#bayar").val('');
                    $j("#kembalian").val('');
                    $("#myModal").bind("show", function() {
                    $("#myModal a.btn").click(function(e) {
                        console.log("button pressed: "+$(this).html());
                        $("#myModal").modal('hide');
                        location.reload();
                    });
                    });
                    $("#myModal").bind("hide", function() {
                    $("#myModal a.btn").unbind();
                    });
                    $("#myModal").modal({
                    "backdrop"  : "static",
                    "keyboard"  : true,
                    "show"      : true  
                    });
                     
                }); 
                
                }        
                
});
        		
});
</script>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
			<th rowspan="2">Kode</th>
			<th rowspan="2">Tanggal</th>
                        <th rowspan="2">Pinjaman</th>
                        <th colspan="3">Angsuran</th>
                        <th rowspan="2">Saldo Pinjaman</th>
                        <th rowspan="2">Ket.</th>
                        <th rowspan="2">Pilihan</th>
		</tr>
                <tr width="50px">
                    <th>Pokok</th><th>Bunga</th><th>Total Angsuran</th>
                </tr>
	</thead>

</table>