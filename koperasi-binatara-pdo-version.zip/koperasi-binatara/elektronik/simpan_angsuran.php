<?php 
include '../atribut/basic.php';
include '../atribut/kd_transaksi_angsuran_elektronik.php';
$id_pinjaman=$_GET['id_pinjaman'];
$tgl=$_GET['tgl'];
$besar_angsuran=$_GET['besar_angsuran'];
$bunga=$_GET['bunga'];

$sql= $query->read("p_elektronik","where md5(kd_elektronik)='".$id_pinjaman."'","kd_elektronik, besar_pinjaman","obj");
foreach ($sql as $row) {
    $kode=$row->kd_elektronik;
    $besar_pinjaman=$row->besar_pinjaman;
}

$total=$besar_angsuran+$bunga;
$insert1=$query->create("angsuran_elektronik",array(null,$kode,$tgl,$besar_angsuran,$bunga,$kd_transaksi));
$insert2=$query->create("jurnal_umum",array(null,$tgl,'Kas',$total,null,$kd_transaksi,'',$kode,'',''));
$insert3=$query->create("jurnal_umum",array(null,$tgl,'Angsuran Pinjaman Elektronik',null,$besar_angsuran,$kd_transaksi,'',$kode,'',''));
$insert4=$query->create("jurnal_umum",array(null,$tgl,'Bunga',null,$bunga,$kd_transaksi,'',$kode,'',''));


$cek_lunas=$query->read("angsuran_elektronik","where md5(kd_elektronik)='".$id_pinjaman."'","sum(besar_angsuran) as total_angsuran","obj");
foreach ($cek_lunas as $row1) {
        if($besar_pinjaman==$row1->total_angsuran){
            $data=array('cek'=>'TRUE');
            echo json_encode($data);
        }else{
            $data=array('cek'=>'FALSE');
            echo json_encode($data);                       
        } 
 

        }





?>

