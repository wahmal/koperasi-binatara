<select name="cicilan" id="cicilan" class="input-small">
    <option value="" align="center">-PILIH-</option>
    <?php
    $cicil=$_GET['cicil'];
    for($i=1;$i<=10;$i++){
        if($i==$cicil){
            echo"<option value=".$i." selected>".$i." x</option>";    
        }else{
            echo"<option value=".$i.">".$i." x</option>";
        }

    }
    ?>
</select>