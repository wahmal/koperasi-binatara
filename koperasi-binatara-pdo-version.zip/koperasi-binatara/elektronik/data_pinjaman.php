
<?php
include'../atribut/basic.php';
$id_anggota=$_GET['id'];
if($_GET['fungsi']=='data_anggota'){
    $row= $query->read("anggota","where id_anggota='".$id_anggota."'");
    echo json_encode($row[0]);    
}else{
	$row= $query->read("p_elektronik ","where id_anggota='".$id_anggota."'");
    echo json_encode($row[0]);
}
?>