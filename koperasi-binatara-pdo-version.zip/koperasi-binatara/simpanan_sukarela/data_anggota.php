<?php
include'../atribut/basic.php';
$explode=explode('&',$_GET['id'] );
$id_anggota=$explode[0];
$row=$query->read("anggota","where id_anggota='".$id_anggota."'");
echo json_encode($row[0]);
?>