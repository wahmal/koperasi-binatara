
<!--DATA TABLES CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo site_path; ?>data_tables/media/css/demo_table.css">
<link rel="stylesheet" type="text/css" href="<?php echo site_path; ?>data_tables/media/css/demo_page.css">


<!--MODAL-->
<div id="myModal" class="modal hide fade">
    <div class="modal-body">Data Berhasil Tersimpan !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="modalUpdate" class="modal hide fade">
    <div class="modal-body">Data Telah Berhasil di Update !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="terhapus" class="modal hide fade">
    <div class="modal-body">Data Telah Terhapus !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>



<legend id="form">Simpanan Sukarela</legend>
<form action="#" method="post" id="form_sukarela" class="form-horizontal">
<div class="form-actions" style="padding-left:0px;padding-bottom:0px;margin-bottom: 0px;margin-left: 0px">
        <table border="0">
            <tr>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="name">Nama / Id Anggota :</label>
                      <div class="controls">
                        <input type="hidden" id="kd_sukarela" value="">
                        <select name="nama_anggota" id="nama_anggota" >
                            <option value="" align="center">-PILIH-</option>
                            <?php
                            $anggota=  $query->read("anggota",'order by nama asc',array('id_anggota','tgl_daftar','nama'),'obj');
                            foreach($anggota as $data ){

                                $row=$query->read("simpanan_sukarela","where id_anggota='".$data->id_anggota."'","date_add(tgl_byr, interval 1 month) as month","obj");

                                        if($data->id_anggota==$id_anggota){
                                            echo"<option value='".$data->id_anggota."&nama=".$data->nama."' selected>".$data->nama." - ".$data->id_anggota."</option>";
                                        }else{
                                            if(!empty($row)){
                                                echo"<option value='".$data->id_anggota."&nama=".$data->nama."'>".$data->nama." - ".$data->id_anggota."</option>";
                                            }else{
                                                    echo"<option value='".$data->id_anggota."&nama=".$data->nama."' class='nunggak' >".$data->nama." - ".$data->id_anggota."</option>";
                                            }                                     

                                        }
                            }
                            ?>
                        </select>
                      </div>
                    </div>
                </td>
                <td>
                    <div class="control-group">
                      <label class="control-label" for="tgl">Tanggal Bayar :</label>
                      <div class="controls">
                        <div class="input-append date" id="datepicker" data-date="<?php echo date("Y-m-d");?>" data-date-format="yyyy-mm-dd">
                            <span class="add-on"><i class="icon-th"></i></span>
                            <input class="span2" size="16" type="text" id="tgl" name="tgl" placeholder="yyyy-mm-dd" readonly="true" value="">
                        </div>
                      </div>
                    </div>
               </td>
            </tr>
            <tr>
                <td>
                  <div class="control-group">
                      <label class="control-label" for="telepon">Besar Simpanan :</label>
                      <div class="controls">
                        <input type="text" name="byr" id="byr" value="">
                      </div>
                  </div>  
                </td>
                <td>&nbsp;</td>
            </tr>
        </table>   
    </div>
    <div style="background:#FFF;margin-left: 0px;padding-top: 5px;">
<button type="submit" class="btn btn-success" id="tombol">Save</button>
<button type="reset" class="btn">Reset</button>
    </div>
</form>
<script src="<?php echo site_path; ?>bootstrap/datepicker/tanggal.js"></script>

<legend>Daftar Simpanan Sukarela - <span class="nama"></span></legend>
<input type="hidden" id="paket">
<script type="text/javascript" language="javascript" src="<?php echo site_path;?>data_tables/media/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path;?>data_tables/media/js/jquery.dataTables.min.js"></script>
<script src="<?php echo site_path; ?>bootstrap/js/validate/jquery.validate.min.js"></script>
<script type="text/javascript" charset="utf-8">
    var $j = jQuery.noConflict();
    $j(document).ready(function() {
            var oTable = $j('#example').dataTable( {
                    
                    "bProcessing": true,
                    "bServerSide": true,
                    "bAutoWidth": false,
                    "bDestroy" : true,
                    "sAjaxSource": "<?php echo site_path;?>simpanan_sukarela/simpanan_json.php?",
                    "sPaginationType": "full_numbers",
                    "aoColumns": [ 
                        {"sClass": "center"},
                        {"sClass": "center"},
                        {"sClass": "right"},
                        {"sClass": "center"}
                    ],
                    "fnServerData": function ( sSource, aoData, fnCallback ) {
			/* Add some extra data to the sender */
			aoData.push( { "name": "id_anggota", "value": $j("#paket").val() } );
			$j.getJSON( sSource, aoData, function (json) { 
				/* Do whatever additional processing you want on the callback, then tell DataTables */
				fnCallback(json)
			} )}
            } );
            
var htmlobjek; 
  $j("#nama_anggota").change(function(){ 
      $j("#form").html("Simpanan Sukarela");
      $j("#tombol").html("Save");
      var id_anggota = $j("#nama_anggota").val(); 
            $j.getJSON ('<?php echo site_path ?>simpanan_sukarela/data_anggota.php',{id:id_anggota}, function (json) {
                $j("#paket").val(id_anggota);
                $j(".nama").html(json.nama);
                oTable.fnDraw();
	    }); 
  }); 
          
$j('.editbutton').live("click", function() {
        var id = $j(this).attr("id");
         simpanan= $j(this).attr("simpanan");
         tgl= $j(this).attr("tgl");
        
        $j("#form").html("Edit Simpanan Sukarela");
        $j("#tombol").html("Update");
        $j("#kd_sukarela").val(id);
        $j("#tgl").val(tgl);
        $j("#byr").val(simpanan);
        return false;
});
        
$j('.delbutton').live("click", function() {
        var id = $j(this).attr("id");
        var dataString = 'id='+ id ;
        var parent = $j(this).parent();
        if(confirm("Yakin Menghapus Data Ini ? Data yang telah terhapus tidak dapat dikembalikan..,"))
        {
        $j.ajax({
           type: "GET",
           url: "<?php echo site_path; ?>simpanan_sukarela/delete.php",
           data: dataString,
           cache: false,
           success: function()
           {
                   $j("#tgl").val('');
                   $j("#kd_sukarela").val('');
                   $j("#byr").val('');
                    $("#terhapus").bind("show", function() {
                    $("#terhapus a.btn").click(function(e) {
                        console.log("button pressed: "+$(this).html());
                        $("#terhapus").modal('hide');
                    });
                    });
                    $("#terhapus").bind("hide", function() {
                    $("#terhapus a.btn").unbind();
                    });
                    $("#terhapus").modal({
                    "backdrop"  : "static",
                    "keyboard"  : true,
                    "show"      : true    
                    });
                    oTable.fnDraw();
          }
          });
          }
	  return false;
});
    

$j('#form_sukarela').validate({
	    rules: {
	      nama_anggota: {
	        required: true
	      },
	      tgl: {
	        required: true
	      },
	      byr: {
                number:true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
                var id_anggota = $j("#nama_anggota").attr("value");
                tgl  = $j("#tgl").attr("value");
                byr  = $j("#byr").attr("value");
                kd_sukarela  =$j("#kd_sukarela").attr("value");
                
                if(kd_sukarela==""){
                    $j.ajax({
                        type: "GET", 
                        url: "<?php echo site_path; ?>simpanan_sukarela/simpan.php", 
                        data: "id_anggota=" + id_anggota + "&byr=" + byr + "&tgl=" + tgl,
                        complete: function(data){
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                $j("#tgl").val('');
                                $j("#kd_sukarela").val('');
                                $j("#byr").val('');
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                            $j("#form").html("Simpanan Sukarela");
                            $j("#tombol").html("Save");
                            oTable.fnDraw();
                        }
                    });
                    return false;
                }else{
                    $j.ajax({
                        type: "GET", 
                        url: "<?php echo site_path; ?>simpanan_sukarela/update.php", 
                        data: "id_anggota=" + id_anggota + "&byr=" + byr + "&tgl=" + tgl + "&kd_sukarela=" + kd_sukarela,
                        complete: function(data){
                            //$j("#nama_anggota").val('');
                           
                            //konfirmasi
                            $("#modalUpdate").bind("show", function() {
                            $("#modalUpdate a.btn").click(function(e) {
                                
                                console.log("button pressed: "+$(this).html());
                                $("#modalUpdate").modal('hide');
                            });
                            });
                            $("#modalUpdate").bind("hide", function() {
                            $("#modalUpdate a.btn").unbind();
                            });
                            $("#modalUpdate").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true   
                            });
                            $j("#form").html("Simpanan Sukarela");
                            $j("#tombol").html("Save");
                            $j("#tgl").val('');
                            $j("#kd_sukarela").val('');
                            $j("#byr").val('');
                            oTable.fnDraw();
                        }
                    });
                    return false;
                }
    }  
});

});
</script>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
			<th width="20%">Kode Pembayaran</th>
			<th>Tanggal Simpan</th>
                        <th>Besar Simpanan</th>
                        <th>Pilihan</th>
		</tr>
	</thead>

</table>