<?php
include '../atribut/basic.php';
$id_anggota=$_GET['id_anggota'];
$tgl=$_GET['tgl'];
$byr=$_GET['byr'];
$kd_sukarela=$_GET['kd_sukarela'];


//print_r($_GET);
//echo $id_anggota;
$sukarela=$query->read("simpanan_sukarela","where id_anggota='".$id_anggota."'",'kd_transaksi');
    $kd_transaksi=$sukarela[0]['kd_transaksi'];



//update data simpanan
$data=$query->read("jurnal_umum ","where kd_transaksi='".$kd_transaksi."' order by id_jurnal asc","id_jurnal",'obj');
$query->update('simpanan_sukarela',"md5(kd_sukarela)='".$kd_sukarela."'",array('tgl_byr',$tgl,'besar_simpanan',$byr));

//update jurnal
foreach($data as $row){
    $id_jurnal[]=$row->id_jurnal;
}


$query->update('jurnal_umum',"id_jurnal='".$id_jurnal[0]."'",array('tgl',$tgl,'debit',$byr));
$query->update('jurnal_umum',"id_jurnal='".$id_jurnal[1]."'",array('tgl',$tgl,'kredit',$byr));
	

?>
