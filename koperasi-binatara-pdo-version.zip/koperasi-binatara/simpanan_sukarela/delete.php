<?php
$id=$_GET['id'];
include '../atribut/basic.php';




$sukarela=$query->read("simpanan_sukarela","where kd_sukarela='".$id."'","","obj");

$kd_transaksi=$sukarela[0]->kd_transaksi;
echo $kd_transaksi;

if($query->delete('jurnal_umum','kd_transaksi',array($kd_transaksi))){

	$query->delete('simpanan_sukarela','kd_sukarela',array($id));

}else{
	echo'false';
}
?>