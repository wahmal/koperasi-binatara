<style type="text/css" title="currentStyle">
    @import "<?php echo site_path; ?>data_tables/media/css/demo_page.css";
    @import "<?php echo site_path; ?>data_tables/media/css/demo_table.css";
    @import "<?php echo site_path; ?>data_tables/table_tools/media/css/TableTools.css";
</style>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/media/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/table_tools/media/js/TableTools.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/table_tools/media/js/TableTools.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/table_tools/media/js/ZeroClipboard.js"></script>

<script type="text/javascript" charset="utf-8">
    var $j = jQuery.noConflict();
    $j(document).ready(function() {
            var oTable = $j('#example').dataTable( {
                    
                    "bProcessing": true,
                    "bServerSide": true,
                    "bAutoWidth": false,
                    "bDestroy" : true,
                    "bSort": false,
                    "bSearch":false,
                    "sAjaxSource": "<?php echo site_path; ?>buku_besar/buku_besar_json.php",
                    "sPaginationType": "full_numbers",
                    "aoColumns": [ 
                        {"sClass": "center"},
                        {"sClass": "center"},
                        {"sClass": "left"},
                        {"sClass": "right"},
                        {"sClass": "right"},
                        {"sClass": "right"}
                    ],
                    "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] },{"bSort":'asc',"aTargets":[1]}],
                    "sDom": 'T<"clear"><"H"lfr>t<"F"ip>',
                    "oTableTools": {
			"sSwfPath": "<?php echo site_path; ?>data_tables/table_tools/media/swf/copy_csv_xls_pdf.swf",
                        "aButtons": [
				"xls",
				{
					"sExtends": "pdf",
					"sPdfOrientation": "landscape",
					"sPdfMessage": "Buku Besar Kas"
				},
				"print" ]
                    }
     
            } );
            } );
</script>
<legend>Buku Besar</legend>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
                        <th>Kd Transaksi</th>
			<th>Tanggal</th>
			<th>Keterangan</th>
                        <th>Debet</th>
                        <th>Kredit</th>
                        <th>Saldo</th>
		</tr>
	</thead>
<?php
require_once "cek_kas.php";
?>
        <tfoot>
            <tr>
                <td colspan="3" class="center"><strong>TOTAL</strong></td>
                <td class="right"><strong><?php echo 'Rp '.number_format(array_sum($array1),0,'.','.'); ?></strong></td>
                <td class="right"><strong><?php echo 'Rp '.number_format(array_sum($array2),0,'.','.'); ?></strong></td>
                <td class="right"><strong><?php echo 'Rp '.number_format($i,0,'.','.'); ?></strong></td>
                
            </tr>
        </tfoot>        

</table>