<?php
session_start();
include'../atribut/basic.php';
if(isset($_GET['user'])&&isset($_GET['pass'])){
$user=$_GET['user'];
$pass=$_GET['pass'];
}
//user
$cek1=  $query->read("admin","where username='".$user."'");
$action1=  count($cek1);
//pass
$cek2= $query->read("admin","where password=md5('".$pass."')");
$action2=  count($cek2);
//user&pass
$cek3=  $query->read("admin","where username='".$user."' and password='".md5($pass)."'");
$action3=   count($cek3);

if(empty($action1)){
    echo '0';
}elseif(empty($action2)){
    echo '1';
}elseif(empty($action3)){
    echo '2';
}else{
    $_SESSION['user']=$user;
    $_SESSION['pass']=$pass;
    $_SESSION['site']='http://localhost/koperasi/';
    echo '3';
}
?>
