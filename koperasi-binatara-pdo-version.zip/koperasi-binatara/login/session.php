<?php
$cek=$query->read("admin","where username='".$_SESSION['user']."' and password=md5('".$_SESSION['pass']."')");
if(empty($cek)){
      header( 'Location: '.site_path ) ;
}
?>
