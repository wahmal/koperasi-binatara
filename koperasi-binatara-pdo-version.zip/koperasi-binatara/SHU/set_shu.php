<script src="<?php echo site_path; ?>bootstrap/js/validate/jquery-1.7.1.min.js"></script>
<script src="<?php echo site_path; ?>bootstrap/js/validate/jquery.validate.min.js"></script>
<?php
$content=array();
$i=0;
$sql=$query->read("shu_pembanding","where id in (4,5,6,7,8,9,11) order by id asc","content","obj");  
foreach($sql as $row){
$content[$i]=$row->content;
$i++;
}
?>
<style>
#form_shu input{width:150px;height:20px;}
</style>
<!--MODAL-->
<div id="myModal" class="modal hide fade">
    <div class="modal-body">Data Telah di perbarui !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<legend>SHU Lain- Lain</legend>
<form id="form_shu">
<table CELLSPACING="0" COLS="4" BORDER="0" align="center" width="90%">
    <tr><td width="15">&nbsp;</td><td colspan="2"><td><td width="15">&nbsp;</td></tr>
	<tr>
		<td HEIGHT="19" align="LEFT" colspan="4"><b>PENDAPATAN DARI NON ANGGOTA</b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Penjualan</td>
		<td align="RIGHT" ><label for="b1"></label><input type="text" name="b1" id="b1" value="<?php echo $content[0]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Harga Pokok</td>
		<td align="RIGHT" ><label for="b2"></label><input type="text" name="b2" id="b2" value="<?php echo $content[1]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >
                    <?php
                        $explode=  explode('-', $content[6]);
                        if(empty($explode[0])){
                            $content[6]=$explode[1];
                    ?>
                            <input type="radio" style="margin:0px;width: 20;" name="lr" id="lr" value="0" >Laba / 
                            <input type="radio" style="margin:0px;width: 20;" name="lr" id="lr" value="1" checked>Rugi Kotor Dengan Non-Anggota 
                            <?php
                        }else{
                            ?>
                            <input type="radio" style="margin:0px;width: 20;" name="lr" id="lr" value="0" checked>Laba / 
                            <input type="radio" style="margin:0px;width: 20;" name="lr" id="lr" value="1" >Rugi Kotor Dengan Non-Anggota 
                            <?php } ?>
                </td>
		<td  align="RIGHT" ><label for="b7"></label><input type="text" name="b7" id="b7" value="<?php echo $content[6]; ?> "></td>
	</tr>        
	<tr>
		<td HEIGHT="19" align="CENTER" colspan="4"><br></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" colspan="4"><b>BEBAN OPERASI</b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Beban Usaha</td>
		<td  align="RIGHT" ><label for="b3"></label><input type="text" name="b3" id="b3" value="<?php echo $content[2]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Beban Perkoperasian</td>
		<td  align="RIGHT" ><label for="b4"></label><input type="text" name="b4" id="b4" value="<?php echo $content[3]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Pendapatan Dan Beban Lain-Lain</td>
		<td  align="RIGHT" >
                    <label for="b5"></label><input type="text" name="b5" id="b5" value="<?php echo $content[4]; ?>"></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Pendapatan Dan Beban Luar Biasa</td>
		<td  align="RIGHT" >
                    <label for="b6"></label><input type="text" name="b6" id="b6" value="<?php echo $content[5]; ?>">
                </td>
	</tr>
</table>
         <hr>
 <button type="submit" class="btn btn-success" id="tombol" >Update</button>
 <button type="reset" class="btn">Reset</button>   
    </form>

<script>
var $s = jQuery.noConflict();           
$s(document).ready(function(){
    
 $s('#form_shu').validate({
	    rules: {
              b1:{number:true},
	      b2:{number:true},
              b3:{number:true},
              b4:{number:true},
              b5:{number:true},
              b6:{number:true},
              b7:{number:true}
	    },
            submitHandler: function() { 
                
                if(confirm("Yakin Melakukan Perubahan ?"))
        {
            var b1 = $s("#b1").attr("value");
            var b2 = $s("#b2").attr("value");
            var b3 = $s("#b3").attr("value");
            var b4 = $s("#b4").attr("value");
            var b5 = $s("#b5").attr("value");
            var b6 = $s("#b6").attr("value");
            var b7 = $s("#b7").attr("value");
            var lr = $s("input[name=lr]:checked").val();
            if(lr=='1'){var b7='-'+b7;}
                    $s.ajax({
                        type: "GET", 
                        url: "<?php echo site_path ?>SHU/update_shu.php", 
                        data: "data="+b1 +":"+ b2+":"+b3+":"+b4+":"+b5+":"+b6+":"+b7,
                        complete: function(data){
                            $("#myModal").bind("show", function() {
                            $("#myModal a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#myModal").modal('hide');
                            });
                            });
                            $("#myModal").bind("hide", function() {
                            $("#myModal a.btn").unbind();
                            });
                            $("#myModal").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                            
                        }
                    });
        }
                    return false;
                }
});
});	
</script>