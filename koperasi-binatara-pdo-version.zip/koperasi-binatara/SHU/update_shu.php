<?php
include '../atribut/basic.php';
include '../setting.php';
$data=explode(':',$_GET['data']);
$x=0;
for($i=4; $i<=9; $i++){

    if(empty($data[$x])){$data[$x]=0;}

$update=$query->update("shu_pembanding","id='".$i."'",array("content",$data[$x]));    
if(!$update){
	
}
$x++;

}
$update=$query->update("shu_pembanding","id='".$i."'",array("content",$data[6]));    
?>
