<?php include 'SHU/hitung_shu.php'; ?>

<?php
$shu=array();
$i=0;
$query=  $query->read("shu_pembanding","order by id asc","content_pembanding","obj");
foreach ($query as $row){
$shu[$i]=$row->content_pembanding;
$i++;
}
?>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.dataTables.min.js"></script>
<script>
var $j = jQuery.noConflict();
   $j(document).ready(function() {
    $j('a.print-preview').printPreview();
});
</script>




<table CELLSPACING="0" COLS="4" BORDER="0" align="center" width="80%">

	<tr>
		<td colspan=6 HEIGHT="19" align="CENTER" ><b>KOPERASI BINATARA</b></td>
	</tr>
	<tr>
		<td colspan=6 HEIGHT="19" align="CENTER" ><b>PERHITUNGAN HASIL USAHA</b></td>
	</tr>
	<tr>
		<td colspan=6 HEIGHT="19" align="CENTER" ><b>Untuk Tahun Yang Berkahir 31 Desember <?php echo $shu[0];?> dan <?php echo date("Y");?></b></td>
	</tr>
	<tr>
		<td STYLE="border-top: 1px solid #000000" colspan=6 HEIGHT="9" align="CENTER" ><br></td>
	</tr>
	<tr>
		<td colspan=3 HEIGHT="10" align="CENTER" ><br></td>
		<td align="CENTER" width="100"><b><?php echo $shu[0]; ?></b></td>
                <td width="10">&nbsp;</td>
                <td align="CENTER" width="100"><b><?php echo date('Y'); ?></b></td>
        </tr>
	<tr>
		<td HEIGHT="19" align="LEFT" colspan="6"><b>PARTISIPASI ANGGOTA</b></td>

	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" width="30"><br></td>
		<td colspan=2 align="LEFT" >Partisipasi Bruto Anggota</td>
                <td align="RIGHT" ><?php echo (number_format($shu[1],0,'.','.'));?></td>
                <td></td><td align="RIGHT"><?php echo (number_format($partisipasi_bruto,0,'.','.'));?></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Beban Pokok</td>
		<td STYLE="border-bottom: 1px solid #000000" align="RIGHT" >(<?php echo (number_format($shu[2],0,'.','.'));?>)</td>
                <td></td><td STYLE="border-bottom: 1px solid #000000" align="RIGHT">(<?php echo (number_format($total_piutang,0,'.','.'));?>)</td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Partisipasi Neto Anggota</td>
		<td STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo (number_format($shu[11],0,'.','.'));?></b></td>
                <td></td><td STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT"><b><?php echo (number_format($total_bunga,0,'.','.'));?></b></td>
	</tr>
	<tr>
		<td HEIGHT="19" colspan="6"><br></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" colspan="6"><b>PENDAPATAN DARI NON ANGGOTA</b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Penjualan</td>
		<td align="RIGHT" ><?php echo (number_format($shu[3],0,'.','.'));?></td>
                <td></td><td align="RIGHT"><?php echo (number_format($content[0],0,'.','.'));?></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Harga Pokok</td>
		<td align="RIGHT" >(<?php echo (number_format($shu[4],0,'.','.'));?>)</td>
                <td></td><td align="right">(<?php echo (number_format($content[1],0,'.','.'));?>)</td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Laba (Rugi) Kotor Dengan Non-Anggota</td>
		<td STYLE="border-bottom: 1px solid #000000" align="RIGHT" ><?php $explode1=explode('-',$shu[10]); if(!empty($explode1[0])) {echo (number_format($shu[10],0,'.','.')); }else{echo '('.(number_format($explode1[1],0,'.','.')).')';}?></td>
                <td></td><td STYLE="border-bottom: 1px solid #000000" align="RIGHT"><?php $explode2=explode('-',$content[6]); if(!empty($explode2[0])) {echo (number_format($content[6],0,'.','.')); }else{echo '('.(number_format($explode2[1],0,'.','.')).')';}?></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" width="20"><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Kotor</td>
		<td STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b><?php echo (number_format($shu[12],0,'.','.'));?></b></td>
                <td></td><td STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT"><b><?php echo (number_format($shu_kotor,0,'.','.'));?></b></td>
        </tr>
	<tr>
		<td HEIGHT="19" align="CENTER" colspan="6"><br></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" colspan="6"><b>BEBAN OPERASI</b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Beban Usaha</td>
		<td STYLE="border-bottom: 1px solid #000000" align="RIGHT" >(<?php echo (number_format($shu[5],0,'.','.'));?>)</td>
                <td></td><td STYLE="border-bottom: 1px solid #000000" align="RIGHT"><?php echo (number_format($content[2],0,'.','.'));?></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" ><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Koperasi</td>
		<td align="RIGHT" ><b><?php echo (number_format($shu[13],0,'.','.'));?></b></td>
                <td></td><td align="RIGHT"><b><?php echo (number_format($shu_koperasi,0,'.','.'));?></b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Beban Perkoperasian</td>
		<td STYLE="border-bottom: 1px solid #000000" align="RIGHT" >(<?php echo (number_format($shu[6],0,'.','.'));?>)</td>
                <td></td><td STYLE="border-bottom: 1px solid #000000" align="RIGHT">(<?php echo (number_format($content[3],0,'.','.'));?>)</td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" ><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Setelah Perkoperasian</td>
		<td align="RIGHT" ><b><?php echo (number_format($shu[14],0,'.','.'));?></b></td>
                <td></td><td align="RIGHT"><b><?php echo (number_format($shu_koperasi_s,0,'.','.'));?></b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Pendapatan Dan Beban Lain-Lain</td>
		<td STYLE="border-bottom: 1px solid #000000" align="RIGHT" >(<?php echo (number_format($shu[7],0,'.','.'));?>)</td>
                <td></td><td STYLE="border-bottom: 1px solid #000000" align="RIGHT">(<?php echo (number_format($content[4],0,'.','.'));?>)</td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" ><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Sebelum Pos-Pos Luar Biasa</td>
		<td align="RIGHT" ><b><?php echo (number_format($shu[15],0,'.','.'));?></b></td>
                <td></td><td align="RIGHT"><b><?php echo (number_format($shu_pos,0,'.','.'));?></b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Pendapatan Dan Beban Luar Biasa</td>
		<td STYLE="border-bottom: 1px solid #000000" align="RIGHT" >(<?php echo (number_format($shu[8],0,'.','.'));?>)</td>
                <td></td><td STYLE="border-bottom: 1px solid #000000" align="RIGHT">(<?php echo (number_format($content[5],0,'.','.'));?>)</td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" ><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Sebelum Pajak</td>
		<td align="RIGHT" ><b><?php echo (number_format($shu[16],0,'.','.'));?></b></td>
                <td></td><td align="right"><b><?php echo (number_format($shu_pajak,0,'.','.'));?></b></td>
	</tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td colspan=2 align="LEFT" >Pajak Penghasilan</td>        
		<td STYLE="border-bottom: 1px solid #000000" align="RIGHT" >(<?php echo (number_format($shu[9],0,'.','.'));?>)</td>
                <td></td><td STYLE="border-bottom: 1px solid #000000" align="RIGHT">(<?php echo (number_format($pajak,0,'.','.'));?>)</td>
        </tr>
	<tr>
		<td HEIGHT="19" align="LEFT" ><br></td>
		<td align="LEFT" ><br></td>
		<td align="LEFT" >Sisa Hasil Usaha Setelah Pajak</td>
		<td STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT" ><b>
                   <?php echo (number_format($shu[17],0,'.','.'));?> </b>
                </td>
                <td></td><td STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="RIGHT"><b><?php echo (number_format($shu_pajak_s,0,'.','.'));?></b></td>
	</tr>
</table>