<?php
 include 'setting.php';
//TOTAL PIUTANG
$piutang=array();
$main_query=  $query->read("anggota","order by nama","id_anggota","obj");
foreach ($main_query as $row) {
    //jangka panjang
    $piutang1=  $query->read("p_jangka_panjang","where id_anggota='".$row->id_anggota."'","kd_panjang, besar_pinjaman","obj");
    foreach ($piutang1 as $row1) {
         $kd_panjang=$row1->kd_panjang;
            $angsuran1=  $query->read("angsuran_jangka_panjang","where kd_panjang='".$kd_panjang."'","","obj");
            foreach ($angsuran1 as $result1) {
                if($result1->besar_angsuran<$row1->besar_pinjaman){
                    $piutang[]=$row1->besar_pinjaman-$result1->besar_angsuran;
                }
            }
     }

     //jangka pendek
     $piutang2=  $query->read("p_jangka_pendek","where id_anggota='".$row->id_anggota."'","kd_pendek, besar_pinjaman","obj");
     foreach ($piutang2 as $row2) {
        $kd_pendek=$row2->kd_pendek;
            $angsuran2=  $query->read("angsuran_jangka_pendek","where kd_pendek='".$kd_pendek."'","sum(besar_angsuran) as besar_angsuran","obj");
                foreach ($angsuran2 as $result2) {
                if($result2->besar_angsuran<$row2->besar_pinjaman){
                    $piutang[]=$row2->besar_pinjaman-$result2->besar_angsuran;
                }
            } 
     }

     //elektronik
     $piutang3=  $query->read("p_elektronik","where id_anggota='".$row->id_anggota."'","kd_elektronik, besar_pinjaman","obj");
     foreach ($piutang3 as $row3) {
        $kd_elektronik=$row3->kd_elektronik;
            $angsuran3=  $query->read("angsuran_elektronik","where kd_elektronik='".$kd_elektronik."'","sum(besar_angsuran) as besar_angsuran","obj");
            foreach ($angsuran3 as $result3) { 
                if($result3->besar_angsuran<$row3->besar_pinjaman){
                    $piutang[]=$row3->besar_pinjaman-$result3->besar_angsuran;
                }
            }
     }

     //sebrak
     $piutang4=  $query->read("p_sebrak","where id_anggota='".$row->id_anggota."'","kd_sebrak, besar_pinjaman","obj");
        foreach ($piutang4 as $row4) {
        $kd_sebrak=$row4->kd_sebrak;
            $angsuran4=  $query->read("angsuran_sebrak","where kd_sebrak='".$kd_sebrak."'","sum(besar_angsuran) as besar_angsuran","obj");
            foreach ($angsuran4 as $result4) { 
                if($result4->besar_angsuran<$row4->besar_pinjaman){
                    $piutang[]=$row4->besar_pinjaman-$result4->besar_angsuran;
                }
            }
     }
}

$total_piutang=array_sum($piutang);

//TOTAL BUNGA
$bunga=array();
$main_query=  $query->read("anggota","order by nama","id_anggota","obj");
//print_r($main_query);
foreach ($main_query as $row)
{
    //jangka panjang
    $bunga1=  $query->read("p_jangka_panjang","where id_anggota='".$row->id_anggota."'","kd_panjang","obj");
     foreach ($bunga1 as $row1){
         $kd_panjang=$row1->kd_panjang;
            $angsuran1=  $query->read("angsuran_jangka_panjang","where kd_panjang='".$kd_panjang."'","sum(bunga) as bunga","obj");
            foreach ($angsuran1 as $result1){
                    $bunga[]=$result1->bunga;
            }
        
     }

     //jangka pendek
     $bunga2=  $query->read("p_jangka_pendek","where id_anggota='".$row->id_anggota."'","kd_pendek","obj");
     foreach ($bunga2 as $row2){
        $kd_pendek=$row2->kd_pendek;
        $angsuran2=  $query->read("angsuran_jangka_pendek","where kd_pendek='".$kd_pendek."'","sum(bunga) as bunga","obj");
            foreach ($angsuran2 as $result2){
                    $bunga[]=$result2->bunga;
            } 
     }

     //elektronik
     $bunga3=  $query->read("p_elektronik","where id_anggota='".$row->id_anggota."'","kd_elektronik","obj");
     foreach ($bunga3 as $row3){
        $kd_elektronik=$row3->kd_elektronik;
        $angsuran3=  $query->read("angsuran_elektronik","where kd_elektronik='".$kd_elektronik."'","sum(bunga) as bunga","obj");
            foreach ($angsuran3 as $result3){
                    $bunga[]=$result3->bunga;
            }
     }

     //sebrak
     $bunga4=  $query->read("p_sebrak","where id_anggota='".$row->id_anggota."'","kd_sebrak","obj");
     foreach ($bunga4 as $row4){
        $kd_sebrak=$row4->kd_sebrak;
        $angsuran4=  $query->read("angsuran_sebrak","where kd_sebrak='".$kd_sebrak."'","sum(bunga) as bunga","obj");
            foreach ($angsuran4 as $result4){      
                    $bunga[]=$result4->bunga;
            }
     }
}
$total_bunga=array_sum($bunga);

$partisipasi_bruto=$total_bunga+$total_piutang;
//PAJAK PENGHASILAN
$pajak=($total_bunga*$pajak_penghasilan)/100;
//SHU LAIN-LAIN
$content=array();
$sql=  $query->read("shu_pembanding","where id in (4,5,6,7,8,9,11)","content","obj");
foreach ($sql as $row){  
    $content[]=$row->content;
}
//SISA HASIL USAHA KOTOR
$shu_kotor=($content[0]-$content[1])+($content[6]+$total_bunga);
//SHU KOPERASI
$shu_koperasi=$shu_kotor-$content[2];
//SHU SETELAH PERKOPERASIAN
$shu_koperasi_s=$shu_koperasi-$content[3];
//SHU SEBELUM POS LUR BIASA
$shu_pos=$shu_koperasi_s-$content[4];
//SHU SEBELUM PAJAK
$shu_pajak=$shu_pos-$content[5];
//pajak
$pajak=($shu_pajak*$pajak_penghasilan)/100;
//SHU SETELAH PAJAK
$shu_pajak_s=$shu_pajak-$pajak;

?>