<?php include 'atribut/basic.php';?>
<?php include 'call_bootstrap.php';?>

<html>
    <head>
        <link href='<?php echo site_path ?>atribut/images/simbol.png' rel='shortcut icon' type='image/x-icon'/>
        <title>Binatara</title>
        <link rel="stylesheet" href="<?php echo site_path ?>atribut/style.css">

    </head>
    <body onLoad="return focus();">

<div id="modal0" class="modal hide fade">
    <div class="modal-body">Username Salah !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="modal1" class="modal hide fade">
    <div class="modal-body">Password Salah !! !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="modal2" class="modal hide fade">
    <div class="modal-body">Username dan Password Tidak Cocok !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="modal3" class="modal hide fade">
    <div class="modal-body">Login Sukses !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
        
        
<div class="container" style="width:900;">
            <div id="navbarExample" class="navbar navbar-static">
              <div class="navbar-inner">
                <div class="container" style="width:auto;height:10px;">
                  <a class="brand" href="#">Binatara</a>
                  
                    <form class="navbar-form pull-right" action="#" id="form_login">
                        <input type="text" class="input-medium" id="user" placeholder="Username">
                        <input type="password" class="input-medium" id="pass" placeholder="Password">
                        <button type="submit" class="btn" id="login">Log in</button>
                      </form>
                 </div>
              </div>
    </div>
    
<div class="row-fluid">
    <div class="span7">
<div id="myCarousel" class="carousel slide" style="width:500px;">
  <!-- Carousel items -->
  <div class="carousel-inner" style="width:500px;">

<?php
$i=0;
$carousel=$query->read('carousel','order by order_id asc');
foreach($carousel as $row){
    if($i==0){
        echo'<div class="active item"><img src="'.site_path.'img/'.$row['img'].'">';
        if(!empty($row['ket'])){
            echo'<div class="carousel-caption">
                  <p>'.$row['ket'].'</p>
                </div>';}
           echo' </div>';
        

    }else{
        
        echo'<div class="item"><img src="'.site_path.'img/'.$row['img'].'">';
        if(!empty($row['ket'])){
                echo'<div class="carousel-caption">
                  <p>'.$row['ket'].'</p>
                </div>';}
            echo'</div>';
    }
    $i++;
}
?>
  </div>
  <!-- Carousel nav -->
  <a class="carousel-control left" href="#myCarousel" data-slide="prev">&lsaquo;</a>
  <a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a>
</div>

<script type="text/javascript" language="javascript" src="<?php echo site_path ?>data_tables/media/js/jquery.dataTables.min.js"></script>
</div>
  <div class="span5">
    <h2 align="center">Sistem Informasi Koperasi Binatara</h2>
    <hr>
    Silahkan Login Untuk Menggunakan Aplikasi Ini..,
  </div>
</div>
    

</div>
<div class="container" style="width:900;">
<script>
$(document).ready(function() { 
 
 $('#login').click(function() {  
                var user=$("#user").val();
                var pass=$("#pass").val();
 
		$.post("<?php echo site_path ?>login/cek_login.php?user="+user+"&pass="+pass, {
 
		}, function(response){
 
		if(response==0)
		{
			$("#modal0").bind("show", function() {
                            $("#modal0 a.btn").click(function(e) {
                                $('#user').focus();
                                console.log("button pressed: "+$(this).html());
                                $("#modal0").modal('hide');
                            });
                            });
                            $("#modal0").bind("hide", function() {
                            $("#modal0 a.btn").unbind();
                            });
                            $("#modal0").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
		}else if(response==1){
			$("#modal1").bind("show", function() {
                            $("#modal1 a.btn").click(function(e) {
                                $('#pass').focus();
                                console.log("button pressed: "+$(this).html());
                                $("#modal1").modal('hide');
                            });
                            });
                            $("#modal1").bind("hide", function() {
                            $("#modal1 a.btn").unbind();
                            });
                            $("#modal1").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                }else if(response==2){
			$("#modal2").bind("show", function() {
                            $("#modal2 a.btn").click(function(e) {
                                $('#pass').focus();
                                console.log("button pressed: "+$(this).html());
                                $("#modal2").modal('hide');
                            });
                            });
                            $("#modal2").bind("hide", function() {
                            $("#modal2 a.btn").unbind();
                            });
                            $("#modal2").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                }else{
			$("#modal3").bind("show", function() {
                            $("#modal3 a").focus();
                            $("#modal3 a.btn").click(function(e) {
                                window.location.replace("<?php echo site_path ?>home/");
                                console.log("button pressed: "+$(this).html());
                                $("#modal3").modal('hide');
                            });
                            });
                            $("#modal3").bind("hide", function() {
                            $("#modal3 a.btn").unbind();
                            });
                            $("#modal3").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                }
 
 
	});
 
	return false;
 });
 
});
</script>
<script>
    function focus(){
        form_login.user.focus();
    }
</script>
<hr>
<footer>
<span>&copy; Binatara <?php echo date('Y');?></span><span class="pull-right">Developed by : <a href="http://www.facebook.com/wahyu.malakian?ref=tn_tnmn" target="_new">Someone</a></span>
</footer>
</div>       
</body>
</html>