<!--DATA TABLES-->
<legend>Daftar Hutang</legend>
<style type="text/css" title="currentStyle">
    @import "data_tables/media/css/demo_page.css";
    @import "data_tables/media/css/demo_table.css";
</style>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.jeditable.js"></script>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="data_tables/media/js/jquery.dataTables.editable.js"></script>
<script type="text/javascript" charset="utf-8">
    var $j = jQuery.noConflict();
    $j(document).ready(function() {
            var oTable = $j('#example').dataTable( {
                    
                    "bProcessing": true,
                    "bServerSide": true,
                    "bAutoWidth": false,
                    "bDestory": true,
                    "bRetrieve": true,
                    "sScrollX": "100%",
                    "sScrollXInner": "120%",
                    "bScrollCollapse": true,
                    "sAjaxSource": "hutang/hutang_json.php",
                    "sPaginationType": "full_numbers",
                    "aoColumns": [ 
                        {"sClass": "center"},
                         {"sClass": "center"},
                        {"sClass": "left"},
                        {"sClass": "center"},
                        {"sClass": "left"},
                        {"sClass": "right"},
                        {"sClass": "center"},
                        {"sClass": "right"},
                        {"sClass": "center"},
                    ],
                    "aoColumnDefs": [
            { "bVisible": false, "aTargets": [0] }
        ]
            } );
            } );
</script>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
			<th>Kd Hutang</th>
                        <th>Kreditur</th>
			<th>Tanggal</th>
                        <th>Jenis Pinjaman</th>
                        <th>Cicilan</th>			
			<th>Total</th>
                        <th>Status</th>
                        <th>Angsura</th>
                        <th>Pilihan</th>
		</tr>
	</thead>

</table>