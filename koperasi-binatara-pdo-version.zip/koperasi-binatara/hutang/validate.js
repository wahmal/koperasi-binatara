var $s = jQuery.noConflict();           
$s(document).ready(function(){
    
    $s('#input').live("click", function() {
        $("#myModal").bind("show", function() {
        $s("#myModal a.close").click(function(e) {
            console.log("button pressed: "+$(this).html());
            $("#myModal").modal('hide');
        });
        });
        $("#myModal").bind("hide", function() {
        $("#myModal a.close").unbind();
        });
        $("#myModal").modal({
        "backdrop"  : "static",
        "keyboard"  : true,
        "show"      : true  
        });
        });
        
    $s('#form_hutang').validate({
	    rules: {
	      kreditur: {
	        minlength: 3,
	        required: true
	      },
              tgl: {
	        required: true
	      },
              cicilan: {
	        number: true,
	        required: true
	      },
              pinjaman: {
	        number: true,
	        required: true
	      }
	    },
	    highlight: function(label) {
	    	$(label).closest('.control-group').addClass('error');
	    },
	    success: function(label) {
	    	label
	    		.text('OK!').addClass('valid')
	    		.closest('.control-group').addClass('success');
	    },
            submitHandler: function() { 
                jenis_aktiva  = $s("#jenis_aktiva").attr("value");        
                    $s.ajax({
                        type: "GET", 
                        url: "aktiva_tetap/simpan_jenis_aktiva.php", 
                        data: "jenis_aktiva=" + jenis_aktiva,
                        complete: function(data){
                            $("#myModal").modal('hide');
                            $s("#jenis_aktiva").val('');
                            $s('#data').load('aktiva_tetap/data_aktiva_tetap.php');
                            $("#simpan").bind("show", function() {
                            $("#simpan a.btn").click(function(e) {
                                console.log("button pressed: "+$(this).html());
                                $("#simpan").modal('hide');
                            });
                            });
                            $("#simpan").bind("hide", function() {
                            $("#simpan a.btn").unbind();
                            });
                            $("#simpan").modal({
                            "backdrop"  : "static",
                            "keyboard"  : true,
                            "show"      : true  
                            });
                        }
                    });
                    return false;
                
            }
            });
            


});