<?php
require_once "../atribut/connect.php";



$columns = array
(
    "kd_hutang","tanggal","jenis","kreditur","cicilan","total"
    
);
 
$table = "hutang";
$joins = "s";

// filtering
$sql_where = "";
if ($_GET['sSearch'] != "")
{
    $sql_where = "WHERE ";
    foreach ($columns as $column)
    {
        $sql_where .= $column . " LIKE '%" . mysql_real_escape_string( $_GET['sSearch'] ) . "%' OR ";
    }
    $sql_where = substr($sql_where, 0, -3);
}
 
// ordering
$sql_order = "";
if ( isset( $_GET['iSortCol_0'] ) )
{
    $sql_order = "ORDER BY  ";
    for ( $i = 0; $i < mysql_real_escape_string( $_GET['iSortingCols'] ); $i++ )
    {
        $sql_order .= $columns[$_GET['iSortCol_' . $i]] . " " . mysql_real_escape_string( $_GET['sSortDir_' . $i] ) . ", ";
    }
    $sql_order = substr_replace( $sql_order, "", -2 );
}
 
// paging
$sql_limit = "";
if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
{
    $sql_limit = "LIMIT " . mysql_real_escape_string( $_GET['iDisplayStart'] ) . ", " . mysql_real_escape_string( $_GET['iDisplayLength'] );
}
 
$main_query = mysql_query("SELECT SQL_CALC_FOUND_ROWS " . implode(", ", $columns) . " FROM {$table} {$joins} {$sql_where} {$sql_order} {$sql_limit}")
    or die(mysql_error());
 
// get the number of filtered rows
$filtered_rows_query = mysql_query("SELECT FOUND_ROWS()")
    or die(mysql_error());
$row = mysql_fetch_array($filtered_rows_query);
$response['iTotalDisplayRecords'] = $row[0];
 
// get the number of rows in total
$total_query = mysql_query("SELECT COUNT(kd_hutang) FROM {$table}")
    or die(mysql_error());
$row = mysql_fetch_array($total_query);
$response['iTotalRecords'] = $row[0];
 
// send back the number requested
$response['sEcho'] = intval($_GET['sEcho']);
 
$response['aaData'] = array();
 
// finish getting rows from the main query
while ($row = mysql_fetch_row($main_query))
{
 $response['aaData'][] = $row;
}
 
header('Cache-Control: no-cache');
header('Pragma: no-cache');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Content-type: application/json');
echo json_encode($response);
 
?>