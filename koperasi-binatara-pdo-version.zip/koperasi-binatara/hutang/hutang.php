

<!--DATA TABLES CSS-->
<link rel="stylesheet" type="text/css" href="data_tables/media/css/demo_table.css">
<link rel="stylesheet" type="text/css" href="data_tables/media/css/demo_page.css">


<!--MODAL-->
<div id="save" class="modal hide fade">
    <div class="modal-body">Data Berhasil Tersimpan !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="update" class="modal hide fade">
    <div class="modal-body">Data Telah Berhasil di Update !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>
<div id="delete" class="modal hide fade">
    <div class="modal-body">Data Telah Terhapus !!</div>
    <div class="modal-footer"><a href="#" class="btn primary">OK</a></div>
</div>



<button class="btn btn-success" id="input"><i class="icon-plus icon-white"></i> Tambah Hutang</button>
<form action="#" method="post" id="form_hutang" class="form-horizontal">
<div id="myModal" class="modal hide fade">
    <div class="modal-header">
        <strong>Form Hutang</strong> 
        <a href="#" class="close"><i class="icon-remove"></i></a>
    </div>
    <div class="modal-body">  
        <input type="hidden" id="kd_hutang">
        <div class="control-group">
          <label class="control-label" for="kreditur">Nama Kreditur :</label>
          <div class="controls">
            <input type="text" name="kreditur" id="kreditur">
          </div>
        </div>
        <div class="control-group">
          <label class="control-label" for="tgl">Tanggal Pinjam :</label>
          <div class="controls">
            <div class="input-append date" id="datepicker" data-date="<?php echo date("Y-m-d");?>" data-date-format="yyyy-mm-dd">
                <span class="add-on"><i class="icon-th"></i></span>
                <input class="span2" size="16" type="text" id="tgl" name="tgl" placeholder="yyyy-mm-dd" readonly="true" value="">
            </div>
          </div>
        </div>
        <div class="control-group">
          <label class="control-label" for="cicilan">Cicilan :</label>
          <div class="controls"> 
            <input type="text" name="cicilan" id="cicilan"> <span>Bulan</span>
          </div>
        </div>
        <div class="control-group">
          <label class="control-label" for="pinjaman">Total Pinjaman :</label>
          <div class="controls"> 
            <input type="text" name="pinjaman" id="pinjaman">
          </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-success" id="tombol">Save</button>
        <button type="reset" class="btn">Reset</button>
    </div>
</div>
</form>
<script src="bootstrap/datepicker/tanggal.js"></script>
<!--VALIDATE FORM-->
<script src="bootstrap/js/validate/jquery-1.7.1.min.js"></script>
<script src="bootstrap/js/validate/jquery.validate.min.js"></script>
<script src="bootstrap/js/validate/jquery.validate.js"></script>
<script src="hutang/validate.js"></script>


<div id="data">
<?php include'hutang/data_hutang.php'; ?>
</div>
