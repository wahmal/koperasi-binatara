<style type="text/css" title="currentStyle">
    @import "<?php echo site_path; ?>data_tables/media/css/demo_page.css";
    @import "<?php echo site_path; ?>data_tables/media/css/demo_table.css";
    @import "<?php echo site_path; ?>data_tables/table_tools/media/css/TableTools.css";
    #example_info{margin-top:10px;}
    .nama{color:#5FbF5F;}
    .right{
  text-align: right;
}

.left{
  align: left;
}

.center{
  align: center;
}
</style>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/media/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/table_tools/media/js/TableTools.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/table_tools/media/js/TableTools.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo site_path; ?>data_tables/table_tools/media/js/ZeroClipboard.js"></script>
<script type="text/javascript" charset="utf-8">
    var $j = jQuery.noConflict();
    $j(document).ready(function() {
            var oTable = $j('#example').dataTable( {
                    
                    "bProcessing": true,
                    "bServerSide": true,
                    "bAutoWidth": false,
                    "bDestroy" : true,
                    "bFilter" : true,
                    "bSort": true,
                    "bInfo": true,
                    "bLengthChange": true,
                    "sAjaxSource": "<?php echo site_path; ?>piutang/piutang_json.php",
                    "sPaginationType": "full_numbers",
                    "aoColumns": [ 
                        {"sClass": "center"},
                        {"sClass": "left"},
                        {"sClass": "center"},
                        {"sClass": "left"},
                        {"sClass": "center"},
                        {"sClass": "center"},
                        {"sClass": "right"}
                    ],
                    "sDom": 'T<"clear"><"H"lfr>t<"F"ip>',
                    "oTableTools": {
			"sSwfPath": "<?php echo site_path; ?>data_tables/table_tools/media/swf/copy_csv_xls_pdf.swf",
                        "aButtons": [
				"xls",
				{
					"sExtends": "pdf",
					"sPdfOrientation": "landscape",
					"sPdfMessage": "Daftar Piutang"
				},
				"print" ]
                    }

                    
            } );
            } );
</script>
<legend>Daftar Piutang</legend>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
	<thead>
		<tr bgcolor="#c0c0c0">
			<th>Kode Anggota</th>
			<th>Nama</th>
                        <th>Pinjaman Ke-</th>
                        <th>Jenis Piutang</th>
                        <th>Tanggal  Pinjam</th>
                        <th>Cicilan</th>
                        <th>Piutang</th>
		</tr>
	</thead>
<?php
$array=array();
$main_query= $query->read("anggota","order by nama","id_anggota","obj");
foreach ($main_query as $row) {

    //jangka panjang
    $piutang1=  $query->read("p_jangka_panjang","where id_anggota='".$row->id_anggota."'","kd_panjang, besar_pinjaman","obj");
     foreach ($piutang1 as $row1) {
         $kd_panjang=$row1->kd_panjang;

            $angsuran1=$query->read("angsuran_jangka_panjang","where kd_panjang='".$kd_panjang."'","sum(besar_angsuran) as besar_angsuran","obj");
            foreach($angsuran1 as $result1){
                if($result1->besar_angsuran<$row1->besar_pinjaman){
                    $array[]=$row1->besar_pinjaman-$result1->besar_angsuran;
                }
            }
     }

     //jangka pendek
     $piutang2=  $query->read("p_jangka_pendek","where id_anggota='".$row->id_anggota."'","kd_pendek, besar_pinjaman","obj");
     foreach ($piutang2 as $row2) {
        $kd_pendek=$row2->kd_pendek;
            
            $angsuran2=$query->read("angsuran_jangka_pendek","where kd_pendek='".$kd_pendek."'","sum(besar_angsuran) as besar_angsuran","obj");
            foreach($angsuran2 as $result2){
                if($result2->besar_angsuran<$row2->besar_pinjaman){
                    $array[]=$row2->besar_pinjaman-$result2->besar_angsuran;
                }
            } 
     }

     //elektronik
     $piutang3=  $query->read("p_elektronik","where id_anggota='".$row->id_anggota."'","kd_elektronik, besar_pinjaman","obj");
     foreach ($piutang3 as $row3) {
        $kd_elektronik=$row3->kd_elektronik;

          $angsuran3=$query->read("angsuran_elektronik","where kd_elektronik='".$kd_elektronik."'","sum(besar_angsuran) as besar_angsuran","obj");
            foreach($angsuran3 as $result3){
                if($result3->besar_angsuran<$row3->besar_pinjaman){
                    $array[]=$row3->besar_pinjaman-$result3->besar_angsuran;
                }
            }
     }

     //sebrak
     $piutang4=  $query->read("p_sebrak","where id_anggota='".$row->id_anggota."'","kd_sebrak, besar_pinjaman","obj");
     foreach ($piutang4 as $row4) {
        $kd_sebrak=$row4->kd_sebrak;

          $angsuran4=$query->read("angsuran_sebrak","where kd_sebrak='".$kd_sebrak."'","sum(besar_angsuran) as besar_angsuran","obj");

           foreach($angsuran4 as $result4){
            
                if($result4->besar_angsuran<$row4->besar_pinjaman){
                    $array[]=$row4->besar_pinjaman-$result4->besar_angsuran;
                }
            }
     }
}
?>

        <tfoot>
            <tr><td colspan="6" class="center"><strong>TOTAL</strong></td><td class="right"><strong><?php echo 'Rp '.number_format(array_sum($array),0,'.','.'); ?></strong></td></tr>
        </tfoot>
</table>