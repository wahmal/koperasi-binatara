now = new Date();
var year = now.getFullYear();
var startDate = new Date(year-1,11,31);
var endDate = new Date(year+1,0,0);
$('#datepicker')
    .datepicker()
    .on('changeDate', function(ev){
         if(startDate.valueOf()>ev.date.valueOf()){
             $("#tgl").val('');
             alert("Tanggal Kurang Dari Periode Pembukuan");
              
         }
         if(endDate.valueOf()<ev.date.valueOf()){
             $("#tgl").val('');
             alert("Tanggal Melebihi Periode Pembukuan");
             
         }  
    });