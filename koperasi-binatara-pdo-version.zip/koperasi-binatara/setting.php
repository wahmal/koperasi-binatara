<?php
//include 'atribut/basic.php';
//simpanan_pokok
$setting=  $query->read("pengaturan","order by id_setting asc","","obj");
//print_r($setting);
foreach($setting as $row){
    //simpanan pokok
    if($row->id_setting==1){
        $id_setting_simpanan_pokok=$row->id_setting;
        $fungsi_simpanan_pokok=$row->fungsi;
        $setting_simpanan_pokok=$row->content;
    }
    //simpanan wajib
    elseif ($row->id_setting==2) {
        $id_setting_simpanan_wajib=$row->id_setting;
        $fungsi_simpanan_wajib=$row->fungsi;
        $setting_simpanan_wajib=$row->content;
    }
    //jangka panjang
    elseif($row->id_setting==3){
        $id_jangka_panjang=$row->id_setting;
        $jangka_panjang=$row->content;
    }elseif($row->id_setting==4){
        $id_cicilan_jangka_panjang=$row->id_setting;
        $cicilan_jangka_panjang=$row->content;
    }elseif($row->id_setting==5){
        $id_bunga_jangka_panjang=$row->id_setting;
        $bunga_jangka_panjang=$row->content;
    }
    //jangka pendek
    elseif($row->id_setting==6){
        $id_jangka_pendek=$row->id_setting;
        $jangka_pendek=$row->content;
    }elseif($row->id_setting==7){
        $id_cicilan_jangka_pendek=$row->id_setting;
        $cicilan_jangka_pendek=$row->content;
    }elseif($row->id_setting==8){
        $id_bunga_jangka_pendek=$row->id_setting;
        $bunga_jangka_pendek=$row->content;
    }
    //elektronik
    elseif($row->id_setting==9){
        $id_elektronik=$row->id_setting;
        $elektronik=$row->content;
    }elseif($row->id_setting==10){
        $id_cicilan_elektronik=$row->id_setting;
        $cicilan_elektronik=$row->content;
    }elseif($row->id_setting==11){
        $id_bunga_elektronik=$row->id_setting;
        $bunga_elektronik=$row->content;
    }
    //sebrak
    elseif($row->id_setting==12){
        $id_sebrak=$row->id_setting;
        $sebrak=$row->content;
    }elseif($row->id_setting==13){
        $id_cicilan_sebrak=$row->id_setting;
        $cicilan_sebrak=$row->content;
    }elseif($row->id_setting==14){
        $id_bunga_sebrak=$row->id_setting;
        $bunga_sebrak=$row->content;
    //SALDO AWAL
    }elseif($row->id_setting==15){
        $id_saldo_awal=$row->id_setting;
        $saldo_awal=$row->content;
    //PAJAK PENGHASILAN    
    }elseif($row->id_setting==16){
        $id_pajak_penghasilan=$row->id_setting;
        $pajak_penghasilan=$row->content;
    }
    //BATAS CICILAN JANGKA PENDEK
    elseif($row->id_setting==17){
        $id_cicilan_hutang_jangka_pendek=$row->id_setting;
        $cicilan_hutang_jangka_pendek=$row->content;
    }
    
}
?>
